/**
 * One-time setup after deploying the escrow program.
 *   ADMIN_KEYPAIR=~/.config/solana/id.json PROGRAM_ID=... TOKEN_MINT=... \
 *   HOUSE_WALLET=... AUTHORITY_PUBKEY=... npx tsx server/scripts/init-config.ts
 * Creates the house token account if needed and sets the fee to 2%.
 */
import { readFileSync } from "node:fs";
import { Connection, Keypair, PublicKey, Transaction, sendAndConfirmTransaction } from "@solana/web3.js";
import { getAssociatedTokenAddressSync, createAssociatedTokenAccountIdempotentInstruction } from "@solana/spl-token";
import { ixInitialize } from "@pot21/shared/escrow";
import { HOUSE_FEE_BPS } from "@pot21/shared";

const env = process.env;
const need = (k: string) => { if (!env[k]) throw new Error(`Missing env ${k}`); return env[k]!; };
const conn = new Connection(env.SOLANA_RPC ?? "https://api.devnet.solana.com", "confirmed");
const admin = Keypair.fromSecretKey(Uint8Array.from(JSON.parse(readFileSync(need("ADMIN_KEYPAIR").replace(/^~/, env.HOME ?? ""), "utf8"))));
const programId = new PublicKey(need("PROGRAM_ID"));
const mint = new PublicKey(need("TOKEN_MINT"));
const house = new PublicKey(need("HOUSE_WALLET"));
const houseToken = getAssociatedTokenAddressSync(mint, house, true);

const tx = new Transaction().add(
  createAssociatedTokenAccountIdempotentInstruction(admin.publicKey, houseToken, house, mint),
  ixInitialize({ programId, admin: admin.publicKey, mint, houseToken, authority: new PublicKey(need("AUTHORITY_PUBKEY")), feeBps: HOUSE_FEE_BPS }),
);
const sig = await sendAndConfirmTransaction(conn, tx, [admin]);
console.log(`Config initialised (fee ${HOUSE_FEE_BPS / 100}%). Signature: ${sig}`);
