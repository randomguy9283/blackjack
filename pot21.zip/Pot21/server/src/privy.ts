/**
 * Privy sign-in, server side.
 *
 * The browser signs in with X through Privy and sends us its Privy access
 * token. We:
 *   1. verify the token ourselves (ES256 JWT signed by Privy, checked
 *      against your app's verification key from the Privy dashboard), then
 *   2. look the user up with Privy's REST API to read their X username and
 *      the Solana wallet Privy created for them.
 *
 * Docs: https://docs.privy.io/authentication/user-authentication/access-tokens
 *       https://docs.privy.io/api-reference/users/get
 */
import { createPublicKey, verify, type KeyObject } from "node:crypto";

export interface PrivyConfig {
  appId: string;
  appSecret: string;
  /** "Verification key" from the Privy dashboard (PEM, ES256 public key). */
  verificationKey: string;
  apiBase?: string;
  /** Injected for tests. */
  fetch?: typeof fetch;
  now?: () => number;
}

export interface PrivyIdentity {
  /** Privy user id, e.g. did:privy:abc123 */
  did: string;
  /** X username without the @ */
  xUsername: string;
  /** Privy-created Solana wallet address */
  wallet: string;
}

const b64url = (s: string) => Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");

export class PrivyVerifier {
  private key: KeyObject;
  private fetchFn: typeof fetch;
  private now: () => number;
  private cache = new Map<string, { id: PrivyIdentity; at: number }>();

  constructor(private cfg: PrivyConfig) {
    // Dashboards sometimes show the key without line breaks; normalise it.
    let pem = cfg.verificationKey.trim().replace(/\\n/g, "\n");
    if (!pem.includes("\n")) {
      const body = pem.replace(/-----(BEGIN|END) PUBLIC KEY-----/g, "").replace(/\s+/g, "");
      pem = `-----BEGIN PUBLIC KEY-----\n${body.match(/.{1,64}/g)!.join("\n")}\n-----END PUBLIC KEY-----`;
    }
    this.key = createPublicKey(pem);
    this.fetchFn = cfg.fetch ?? fetch;
    this.now = cfg.now ?? Date.now;
  }

  /** Check the access token and return the Privy user id it belongs to. */
  verifyAccessToken(token: string): string {
    const parts = String(token).split(".");
    if (parts.length !== 3) throw new Error("Your sign-in token is malformed. Sign in again.");
    let header: { alg?: string }, claims: { iss?: string; aud?: string | string[]; sub?: string; exp?: number; nbf?: number };
    try {
      header = JSON.parse(b64url(parts[0]).toString("utf8"));
      claims = JSON.parse(b64url(parts[1]).toString("utf8"));
    } catch { throw new Error("Your sign-in token is malformed. Sign in again."); }
    if (header.alg !== "ES256") throw new Error("Unexpected sign-in token type.");
    const ok = verify("sha256", Buffer.from(`${parts[0]}.${parts[1]}`), { key: this.key, dsaEncoding: "ieee-p1363" }, b64url(parts[2]));
    if (!ok) throw new Error("Your sign-in token isn't valid. Sign in again.");
    const nowS = Math.floor(this.now() / 1000);
    const aud = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
    if (claims.iss !== "privy.io") throw new Error("Sign-in token wasn't issued by Privy.");
    if (!aud.includes(this.cfg.appId)) throw new Error("Sign-in token is for a different app.");
    if (!claims.exp || claims.exp < nowS - 30) throw new Error("Your sign-in expired. Sign in again.");
    if (claims.nbf && claims.nbf > nowS + 30) throw new Error("Sign-in token isn't valid yet.");
    if (!claims.sub?.startsWith("did:privy:")) throw new Error("Sign-in token has no user.");
    return claims.sub;
  }

  /** Fetch the user's X username and Privy Solana wallet. Cached for 10 minutes. */
  async identity(did: string): Promise<PrivyIdentity> {
    const hit = this.cache.get(did);
    if (hit && this.now() - hit.at < 10 * 60_000) return hit.id;
    const url = `${this.cfg.apiBase ?? "https://api.privy.io"}/v1/users/${encodeURIComponent(did)}`;
    const res = await this.fetchFn(url, {
      headers: {
        authorization: "Basic " + Buffer.from(`${this.cfg.appId}:${this.cfg.appSecret}`).toString("base64"),
        "privy-app-id": this.cfg.appId,
      },
    });
    if (!res.ok) throw new Error(`Couldn't load your Privy account (${res.status}). Try again in a moment.`);
    const user = await res.json() as { id: string; linked_accounts?: Record<string, unknown>[] };
    const accounts = user.linked_accounts ?? [];
    const x = accounts.find(a => a.type === "twitter_oauth") as { username?: string } | undefined;
    if (!x?.username) throw new Error("Your Privy account has no X account linked. Sign in with X.");
    const wallets = accounts.filter(a => a.type === "wallet" && a.chain_type === "solana") as { address: string; wallet_client_type?: string; connector_type?: string }[];
    // Prefer the wallet Privy created (embedded) over any external wallet the user linked.
    const embedded = wallets.find(w => w.wallet_client_type === "privy" || w.connector_type === "embedded") ?? null;
    if (!embedded) throw new Error("Your wallet is still being created. Try again in a few seconds.");
    const id = { did, xUsername: x.username, wallet: embedded.address };
    this.cache.set(did, { id, at: this.now() });
    return id;
  }

  async signIn(token: string) {
    return this.identity(this.verifyAccessToken(token));
  }
}

export function privyFromEnv(env: NodeJS.ProcessEnv): PrivyVerifier | null {
  const { PRIVY_APP_ID, PRIVY_APP_SECRET, PRIVY_VERIFICATION_KEY } = env;
  if (!PRIVY_APP_ID) return null;
  if (!PRIVY_APP_SECRET || !PRIVY_VERIFICATION_KEY) throw new Error("PRIVY_APP_ID is set, so PRIVY_APP_SECRET and PRIVY_VERIFICATION_KEY are needed too.");
  return new PrivyVerifier({ appId: PRIVY_APP_ID, appSecret: PRIVY_APP_SECRET, verificationKey: PRIVY_VERIFICATION_KEY, apiBase: env.PRIVY_API_BASE });
}
