/**
 * On-chain ledger backed by the pot21_escrow program.
 *
 * The server holds the program's `authority` key and uses it to open,
 * settle and cancel rounds. Players sign their own `join` (stake)
 * transactions in the browser; `deposit` here only checks that the stake
 * landed on chain before the game counts it.
 *
 * Needs: npm i @solana/web3.js @solana/spl-token
 * Env:   SOLANA_RPC, PROGRAM_ID, TOKEN_MINT, AUTHORITY_KEYPAIR (path to JSON
 *        secret key), HOUSE_WALLET (owner of the house token account),
 *        TOKEN_SYMBOL (optional), TOKEN_PROGRAM (optional, for Token-2022)
 */
import { readFileSync } from "node:fs";
import {
  Connection, Keypair, PublicKey, Transaction, sendAndConfirmTransaction, ComputeBudgetProgram,
} from "@solana/web3.js";
import { getAssociatedTokenAddressSync, createAssociatedTokenAccountIdempotentInstruction, getMint } from "@solana/spl-token";
import { transferFee, type Settlement } from "@pot21/shared";
import { ixOpenRound, ixSettle, ixCancel, pdas, decodeRound, TOKEN_PROGRAM_ID } from "@pot21/shared/escrow";
import type { Ledger, SeatWallet } from "./types.ts";

export class SolanaLedger implements Ledger {
  readonly mode = "solana" as const;
  readonly token: Ledger["token"];
  readonly chain: NonNullable<Ledger["chain"]>;
  onTx?: Ledger["onTx"];
  onBalance?: Ledger["onBalance"];

  private constructor(
    private conn: Connection,
    private programId: PublicKey,
    private mint: PublicKey,
    private authority: Keypair,
    private house: PublicKey,
    private tokenProgram: PublicKey,
    decimals: number,
    symbol: string,
    rpcUrl: string,
  ) {
    this.token = { symbol, decimals, mint: mint.toBase58() };
    this.chain = { rpcUrl, programId: programId.toBase58(), house: house.toBase58() };
  }

  static async fromEnv(env: NodeJS.ProcessEnv): Promise<SolanaLedger> {
    const need = (k: string) => { const v = env[k]; if (!v) throw new Error(`Missing env ${k}`); return v; };
    const rpc = env.SOLANA_RPC ?? "https://api.devnet.solana.com";
    const conn = new Connection(rpc, "confirmed");
    const mint = new PublicKey(need("TOKEN_MINT"));
    const tokenProgram = env.TOKEN_PROGRAM ? new PublicKey(env.TOKEN_PROGRAM) : TOKEN_PROGRAM_ID;
    const secret = JSON.parse(readFileSync(need("AUTHORITY_KEYPAIR"), "utf8"));
    const authority = Keypair.fromSecretKey(Uint8Array.from(secret));
    const info = await getMint(conn, mint, "confirmed", tokenProgram);
    return new SolanaLedger(conn, new PublicKey(need("PROGRAM_ID")), mint, authority, new PublicKey(need("HOUSE_WALLET")), tokenProgram, info.decimals, env.TOKEN_SYMBOL ?? "TOKEN", rpc);
  }

  private ata(owner: string | PublicKey) {
    return getAssociatedTokenAddressSync(this.mint, new PublicKey(owner), true, this.tokenProgram);
  }

  private async send(...ixs: Parameters<Transaction["add"]>) {
    const tx = new Transaction().add(ComputeBudgetProgram.setComputeUnitPrice({ microLamports: 5_000 }), ...ixs);
    return sendAndConfirmTransaction(this.conn, tx, [this.authority], { commitment: "confirmed" });
  }

  async balance(wallet: string) {
    try {
      const b = await this.conn.getTokenAccountBalance(this.ata(wallet));
      return BigInt(b.value.amount);
    } catch {
      return 0n; // no token account yet
    }
  }

  private seen = new Set<string>();

  /**
   * Confirm a player-signed transfer did what it claims: `from` lost
   * `amount`, `to` gained the net, the house gained the fee. Each signature
   * can only be recorded once.
   *
   * Note: the player holds both wallets' keys, so nothing on chain forces
   * deposit/withdraw fees. A player who transfers by hand skips them. Only
   * the pot fee is enforced by the escrow program.
   */
  private async confirmTransfer(signature: string | undefined, from: string, to: string, amount: bigint, feeBps: number) {
    if (!signature) throw new Error("Missing transaction signature.");
    if (this.seen.has(signature)) throw new Error("That transaction was already recorded.");
    const { fee, net } = transferFee(amount, feeBps);
    let tx = null;
    for (let i = 0; i < 10 && !tx; i++) {
      tx = await this.conn.getParsedTransaction(signature, { commitment: "confirmed", maxSupportedTransactionVersion: 0 });
      if (!tx) await new Promise(r => setTimeout(r, 800));
    }
    if (!tx) throw new Error("Couldn't find that transaction yet. It may still be confirming.");
    if (tx.meta?.err) throw new Error("That transaction failed on chain.");
    const mint = this.mint.toBase58();
    const delta = (owner: string) => {
      const sum = (list: typeof tx.meta.preTokenBalances) => (list ?? []).filter(b => b.owner === owner && b.mint === mint).reduce((a, b) => a + BigInt(b.uiTokenAmount.amount), 0n);
      return sum(tx!.meta!.postTokenBalances) - sum(tx!.meta!.preTokenBalances);
    };
    if (delta(from) > -amount) throw new Error("The transaction didn't move the expected amount.");
    if (delta(to) < net) throw new Error("The transaction didn't pay the expected amount.");
    if (fee > 0n && delta(this.house.toBase58()) < fee) throw new Error("The transaction is missing the house fee.");
    this.seen.add(signature);
    return { sig: signature, fee, net };
  }

  async transferIn(from: string, to: string, amount: bigint, feeBps: number, signature?: string) {
    const r = await this.confirmTransfer(signature, from, to, amount, feeBps);
    this.onTx?.(to, { kind: "in", label: "Deposit", amount: r.net.toString(), route: `Phantom ${short(from)} → you`, sig: r.sig, at: Date.now() });
    if (r.fee) this.onTx?.(to, { kind: "fee", label: `Deposit fee ${feeBps / 100}%`, amount: r.fee.toString(), route: "→ house", sig: r.sig, at: Date.now() });
    this.onBalance?.(to);
    return r;
  }

  async transferOut(from: string, to: string, amount: bigint, feeBps: number, signature?: string) {
    const r = await this.confirmTransfer(signature, from, to, amount, feeBps);
    this.onTx?.(from, { kind: "out", label: "Withdrawal", amount: amount.toString(), route: `You → Phantom ${short(to)}`, sig: r.sig, at: Date.now() });
    this.onBalance?.(from);
    return r;
  }

  async openRound(roundId: string, seats: number, stake: bigint) {
    const id = BigInt(roundId);
    await this.send(ixOpenRound({ programId: this.programId, mint: this.mint, roundId: id, authority: this.authority.publicKey, seats, stake, tokenProgram: this.tokenProgram }));
    return { escrow: pdas(this.programId, id).round.toBase58() };
  }

  async deposit(roundId: string, seat: number, wallet: string, stake: bigint, signature?: string) {
    if (signature) {
      const st = await this.conn.getSignatureStatus(signature, { searchTransactionHistory: true });
      if (st.value?.err) throw new Error("Your stake transaction failed on chain.");
    }
    const { round } = pdas(this.programId, BigInt(roundId));
    // The browser may report before the RPC node has caught up; retry briefly.
    for (let attempt = 0; attempt < 10; attempt++) {
      const acc = await this.conn.getAccountInfo(round, "confirmed");
      if (acc) {
        const r = decodeRound(acc.data);
        if (r.stake !== stake) throw new Error("On-chain stake doesn't match this table.");
        if (r.deposited & (1 << seat)) {
          if (r.players[seat].toBase58() !== wallet) throw new Error("That seat was staked by a different wallet.");
          this.onTx?.(wallet, { kind: "out", label: "Stake", amount: stake.toString(), route: `You → escrow ${short(round.toBase58())}`, sig: signature ?? "", at: Date.now() });
          this.onBalance?.(wallet);
          return { sig: signature ?? "" };
        }
      }
      await new Promise(r => setTimeout(r, 800));
    }
    throw new Error("Couldn't find your stake on chain yet. Try again in a few seconds.");
  }

  async settle(roundId: string, seats: SeatWallet[], s: Settlement) {
    const id = BigInt(roundId);
    const winners = s.payouts.map(p => p.seat);
    const winnerOwners = winners.map(seat => seats.find(x => x.seat === seat)!.wallet);
    const winnerTokens = winnerOwners.map(o => this.ata(o));
    const houseToken = this.ata(this.house);
    const sig = await this.send(
      // Make sure every payout account exists (no-op if it does).
      ...winnerOwners.map((o, i) => createAssociatedTokenAccountIdempotentInstruction(this.authority.publicKey, winnerTokens[i], new PublicKey(o), this.mint, this.tokenProgram)),
      ixSettle({ programId: this.programId, mint: this.mint, roundId: id, authority: this.authority.publicKey, houseToken, winners, winnerTokens, tokenProgram: this.tokenProgram }),
    );
    for (const sw of seats) this.onTx?.(sw.wallet, { kind: "fee", label: "House fee 2% (whole pot)", amount: s.fee.toString(), route: "Escrow → house", sig, at: Date.now() });
    for (const p of s.payouts) {
      const wlt = seats.find(x => x.seat === p.seat)!.wallet;
      this.onTx?.(wlt, { kind: "in", label: s.payouts.length > 1 ? "Pot share" : "Pot won", amount: p.amount.toString(), route: "Escrow → you", sig, at: Date.now() });
      this.onBalance?.(wlt);
    }
    return { sig };
  }

  async cancel(roundId: string, deposited: SeatWallet[], stake: bigint) {
    const id = BigInt(roundId);
    // Use the chain's record of who staked, not the server's, so a stake that
    // landed after the server gave up is still refunded.
    const acc = await this.conn.getAccountInfo(pdas(this.programId, id).round, "confirmed");
    if (!acc) return { sig: "" }; // round never opened or already closed
    const onChain = decodeRound(acc.data);
    void deposited;
    const sorted: SeatWallet[] = [];
    for (let seat = 0; seat < onChain.seats; seat++) {
      if (onChain.deposited & (1 << seat)) sorted.push({ seat, wallet: onChain.players[seat].toBase58() });
    }
    const refundTokens = sorted.map(d => this.ata(d.wallet));
    const sig = await this.send(
      ixCancel({ programId: this.programId, mint: this.mint, roundId: id, caller: this.authority.publicKey, rentReceiver: this.authority.publicKey, refundTokens, tokenProgram: this.tokenProgram }),
    );
    for (const d of sorted) {
      this.onTx?.(d.wallet, { kind: "in", label: "Stake refunded", amount: stake.toString(), route: "Escrow → you", sig, at: Date.now() });
      this.onBalance?.(d.wallet);
    }
    return { sig };
  }
}

const short = (a: string) => a.slice(0, 4) + "…" + a.slice(-4);
