import { randomBytes } from "node:crypto";
import { transferFee, type Settlement } from "@pot21/shared";
import type { Ledger, SeatWallet } from "./types.ts";
import { base58 } from "../util.ts";

/**
 * In-memory ledger for local play and tests. Behaves like the escrow
 * program: stakes sit in a per-round escrow until settle or cancel, and the
 * total supply is conserved (checked by `audit`).
 */
export class MockLedger implements Ledger {
  readonly mode = "mock" as const;
  readonly token = { symbol: "CHIP", decimals: 6, mint: null };
  readonly house = "House" + base58(randomBytes(28)).slice(0, 39);
  private balances = new Map<string, bigint>();
  private escrows = new Map<string, { address: string; seats: number; stake: bigint; held: bigint; paid: Set<number>; closed: boolean }>();
  private minted = 0n;
  onTx?: Ledger["onTx"];
  onBalance?: Ledger["onBalance"];

  private sig() { return base58(randomBytes(64)); }
  private bal(w: string) { return this.balances.get(w) ?? 0n; }
  private add(w: string, d: bigint) {
    const v = this.bal(w) + d;
    if (v < 0n) throw new Error("Not enough tokens in wallet for this stake.");
    this.balances.set(w, v);
    this.onBalance?.(w);
  }

  async balance(wallet: string) { return this.bal(wallet); }
  houseBalance() { return this.bal(this.house); }

  async faucet(wallet: string, amount: bigint) {
    this.minted += amount;
    this.add(wallet, amount);
    this.onTx?.(wallet, { kind: "in", label: "Demo top-up", amount: amount.toString(), route: "Faucet → you", sig: this.sig(), at: Date.now() });
  }

  /** Demo funds in a simulated Phantom wallet (no tx shown: it's outside the game wallet). */
  async mintTo(wallet: string, amount: bigint) {
    this.minted += amount;
    this.add(wallet, amount);
  }

  private move(from: string, to: string, amount: bigint, feeBps: number) {
    const { fee, net } = transferFee(amount, feeBps);
    if (this.bal(from) < amount) throw new Error("Not enough tokens for that amount.");
    this.add(from, -amount);
    this.add(this.house, fee);
    this.add(to, net);
    return { sig: this.sig(), fee, net };
  }

  async transferIn(from: string, to: string, amount: bigint, feeBps: number) {
    const r = this.move(from, to, amount, feeBps);
    this.onTx?.(to, { kind: "in", label: "Deposit", amount: r.net.toString(), route: `Phantom ${short(from)} → you`, sig: r.sig, at: Date.now() });
    if (r.fee) this.onTx?.(to, { kind: "fee", label: `Deposit fee ${feeBps / 100}%`, amount: r.fee.toString(), route: `→ house ${short(this.house)}`, sig: r.sig, at: Date.now() });
    return r;
  }

  async transferOut(from: string, to: string, amount: bigint, feeBps: number) {
    const r = this.move(from, to, amount, feeBps);
    this.onTx?.(from, { kind: "out", label: "Withdrawal", amount: amount.toString(), route: `You → Phantom ${short(to)}`, sig: r.sig, at: Date.now() });
    if (r.fee) this.onTx?.(from, { kind: "fee", label: `Withdrawal fee ${feeBps / 100}% (included)`, amount: r.fee.toString(), route: `→ house ${short(this.house)}`, sig: r.sig, at: Date.now() });
    return r;
  }

  async openRound(roundId: string, seats: number, stake: bigint) {
    if (this.escrows.has(roundId)) throw new Error("round already open");
    const address = "Escrw" + base58(randomBytes(28)).slice(0, 39);
    this.escrows.set(roundId, { address, seats, stake, held: 0n, paid: new Set(), closed: false });
    return { escrow: address };
  }

  private escrow(roundId: string) {
    const e = this.escrows.get(roundId);
    if (!e || e.closed) throw new Error("This round's escrow is closed.");
    return e;
  }

  async deposit(roundId: string, seat: number, wallet: string, stake: bigint) {
    const e = this.escrow(roundId);
    if (stake !== e.stake) throw new Error("stake mismatch");
    if (e.paid.has(seat)) throw new Error("Seat already staked.");
    this.add(wallet, -stake);
    e.held += stake;
    e.paid.add(seat);
    const sig = this.sig();
    this.onTx?.(wallet, { kind: "out", label: "Stake", amount: stake.toString(), route: `You → escrow ${short(e.address)}`, sig, at: Date.now() });
    return { sig };
  }

  async settle(roundId: string, seats: SeatWallet[], s: Settlement) {
    const e = this.escrow(roundId);
    if (e.paid.size !== e.seats) throw new Error("round not fully funded");
    if (s.total !== e.held) throw new Error("settlement total does not match escrow");
    const sig = this.sig();
    this.add(this.house, s.fee);
    for (const sw of seats) this.onTx?.(sw.wallet, { kind: "fee", label: "House fee 2% (whole pot)", amount: s.fee.toString(), route: `Escrow → house ${short(this.house)}`, sig, at: Date.now() });
    for (const p of s.payouts) {
      const w = seats.find(x => x.seat === p.seat)!.wallet;
      this.add(w, p.amount);
      this.onTx?.(w, { kind: "in", label: s.payouts.length > 1 ? "Pot share" : "Pot won", amount: p.amount.toString(), route: "Escrow → you", sig, at: Date.now() });
    }
    e.held = 0n;
    e.closed = true;
    return { sig };
  }

  async cancel(roundId: string, deposited: SeatWallet[], stake: bigint) {
    const e = this.escrow(roundId);
    const sig = this.sig();
    for (const d of deposited) {
      if (!e.paid.has(d.seat)) continue;
      this.add(d.wallet, stake);
      e.held -= stake;
      this.onTx?.(d.wallet, { kind: "in", label: "Stake refunded", amount: stake.toString(), route: "Escrow → you", sig, at: Date.now() });
    }
    if (e.held !== 0n) throw new Error("escrow not empty after refund");
    e.closed = true;
    return { sig };
  }

  /** Total tokens across wallets + escrows must equal what was minted. */
  audit() {
    let sum = 0n;
    for (const v of this.balances.values()) sum += v;
    for (const e of this.escrows.values()) sum += e.held;
    return { minted: this.minted, accounted: sum, ok: sum === this.minted };
  }
}

const short = (a: string) => a.slice(0, 4) + "…" + a.slice(-4);
