import type { LedgerMode, LedgerTx, SessionInfo, Settlement } from "@pot21/shared";

export interface SeatWallet { seat: number; wallet: string }

/**
 * Everything that moves tokens. The game never touches balances directly,
 * so swapping the mock for the on-chain escrow changes no game code.
 */
export interface Ledger {
  readonly mode: LedgerMode;
  readonly token: SessionInfo["token"];
  readonly chain?: SessionInfo["chain"];

  balance(wallet: string): Promise<bigint>;
  /** Demo tokens. Only the mock ledger supports this. */
  faucet?(wallet: string, amount: bigint): Promise<void>;

  /**
   * Deposit: linked wallet (Phantom) -> game wallet, house keeps feeBps.
   * Mock: moves the tokens. Solana: the player already signed and sent the
   * transfer; this confirms it on chain and records it.
   */
  transferIn(from: string, to: string, amount: bigint, feeBps: number, signature?: string): Promise<{ sig: string; fee: bigint; net: bigint }>;
  /** Withdrawal: game wallet -> linked wallet, house keeps feeBps. Same split of duties as transferIn. */
  transferOut(from: string, to: string, amount: bigint, feeBps: number, signature?: string): Promise<{ sig: string; fee: bigint; net: bigint }>;

  /** Create the escrow for a round. Returns the escrow address players pay into. */
  openRound(roundId: string, seats: number, stake: bigint): Promise<{ escrow: string }>;
  /**
   * Record a player's stake. Mock: moves the tokens. Solana: the player has
   * already signed the `join` transaction; this checks it landed on chain.
   */
  deposit(roundId: string, seat: number, wallet: string, stake: bigint, signature?: string): Promise<{ sig: string }>;
  /** Pay winners and the house fee out of escrow. */
  settle(roundId: string, seats: SeatWallet[], settlement: Settlement): Promise<{ sig: string }>;
  /** Refund every deposited stake in full (no fee) and close the escrow. */
  cancel(roundId: string, deposited: SeatWallet[], stake: bigint): Promise<{ sig: string }>;

  /** Called for every token movement that touches a player's wallet. */
  onTx?: (wallet: string, tx: LedgerTx) => void;
  /** Called when a wallet's balance may have changed. */
  onBalance?: (wallet: string) => void;
}
