import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { WebSocketServer } from "ws";
import { parseUnits } from "@pot21/shared";
import { Hub, type Conn } from "./hub.ts";
import { MockLedger } from "./ledger/mock.ts";
import type { Ledger } from "./ledger/types.ts";
import { privyFromEnv } from "./privy.ts";

const env = process.env;
const PORT = Number(env.PORT ?? 8787);
const LEDGER = (env.LEDGER ?? "mock") as "mock" | "solana";
const STATIC_DIR = resolve(fileURLToPath(new URL(".", import.meta.url)), "../../client/dist");
const log = (m: string) => console.log(`[pot21] ${m}`);

async function makeLedger(): Promise<Ledger> {
  if (LEDGER === "mock") return new MockLedger();
  const { SolanaLedger } = await import("./ledger/solana.ts");
  return SolanaLedger.fromEnv(env);
}

const ledger = await makeLedger();
const decimals = ledger.token.decimals;
const bps = (v: string | undefined, d: number) => {
  const n = v === undefined ? d : Number(v);
  if (!Number.isInteger(n) || n < 0 || n > 1000) throw new Error("Fee settings are basis points from 0 to 1000 (200 = 2%).");
  return n;
};
const privy = privyFromEnv(env);
// Handle-only login lets anyone claim any name. It's only for demo mode
// without Privy, or when explicitly enabled for testing.
const devLogin = (LEDGER === "mock" && !privy) || env.ALLOW_DEV_LOGIN === "1";
// Accounts and sign-ins are saved here so a restart doesn't sign everyone out.
const DATA_DIR = resolve(env.DATA_DIR ?? "data");
const hub = new Hub(ledger, {
  privy,
  accountsFile: join(DATA_DIR, "accounts.json"),
  allowBots: LEDGER === "mock",
  allowDevLogin: devLogin,
  depositFeeBps: bps(env.DEPOSIT_FEE_BPS, 200),
  withdrawFeeBps: bps(env.WITHDRAW_FEE_BPS, 200),
  demoPhantomBalance: LEDGER === "mock" ? parseUnits(env.DEMO_PHANTOM_BALANCE ?? "1000", decimals) : undefined,
  starterBalance: parseUnits(env.STARTER_BALANCE ?? "1000", decimals),
  minStake: parseUnits(env.MIN_STAKE ?? "1", decimals),
  maxStake: parseUnits(env.MAX_STAKE ?? "10000", decimals),
  log,
});
setInterval(() => hub.reap(), 30_000).unref();

const TYPES: Record<string, string> = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".map": "application/json" };

const server = createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", "http://x");
  if (url.pathname === "/healthz") { res.end("ok"); return; }
  if (url.pathname === "/api/info") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ mode: ledger.mode, token: ledger.token, bots: LEDGER === "mock", devLogin, privyAppId: privy ? env.PRIVY_APP_ID : null }));
    return;
  }
  let path = normalize(decodeURIComponent(url.pathname)).replace(/^([/\\])+/, "");
  if (!path || path.endsWith("/")) path += "index.html";
  const file = join(STATIC_DIR, path);
  if (!file.startsWith(STATIC_DIR)) { res.writeHead(403).end(); return; }
  try {
    const s = await stat(file);
    if (!s.isFile()) throw new Error();
    res.writeHead(200, { "content-type": TYPES[extname(file)] ?? "application/octet-stream", "cache-control": "no-cache" });
    res.end(await readFile(file));
  } catch {
    try { res.writeHead(200, { "content-type": TYPES[".html"] }).end(await readFile(join(STATIC_DIR, "index.html"))); }
    catch { res.writeHead(404).end("Client not built. Run: npm run build"); }
  }
});

const wss = new WebSocketServer({ server, path: "/ws", maxPayload: 16 * 1024 });
wss.on("connection", ws => {
  const conn: Conn = { userId: null, send: d => { if (ws.readyState === ws.OPEN) ws.send(d); } };
  hub.connect(conn);
  let alive = true;
  ws.on("pong", () => { alive = true; });
  const ping = setInterval(() => { if (!alive) return ws.terminate(); alive = false; ws.ping(); }, 25_000);
  ws.on("message", data => void hub.handle(conn, data.toString()));
  ws.on("close", () => { clearInterval(ping); hub.disconnect(conn); });
});

server.listen(PORT, () => {
  log(`listening on http://localhost:${PORT} (ledger: ${LEDGER}, X sign-in: ${privy ? "Privy" : "demo"})`);
  log(`accounts saved in ${DATA_DIR}`);
  if (LEDGER === "mock") log("demo tokens reset when the server restarts; accounts and sign-ins are kept");
});

for (const sig of ["SIGINT", "SIGTERM"] as const) process.on(sig, () => { hub.shutdown(); server.close(); process.exit(0); });
