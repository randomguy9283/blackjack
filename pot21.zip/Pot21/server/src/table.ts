import { randomBytes } from "node:crypto";
import {
  commitFor, shuffleDeck, handTotal, isNatural, isBust, winningSeats, computeSettlement, potPreview,
  TURN_MS, FUNDING_MS, type Card, type RoundPhase, type SeatStatus, type Settlement,
  type TableView, type TableSummary, type SeatView,
} from "@pot21/shared";
import type { Ledger } from "./ledger/types.ts";

export interface Player {
  userId: string;
  handle: string;
  wallet: string;
  isBot: boolean;
  clientSeed: string;
  connected: boolean;
  leaving: boolean;
  /** Bot strategy: hit below this total. */
  standOn?: number;
}

interface SeatState {
  player: Player;
  deposited: boolean;
  hand: Card[];
  status: SeatStatus;
  revealed: boolean;
  payout: bigint | null;
}

interface RoundState {
  id: string;
  phase: RoundPhase;
  serverSeed: string;
  commit: string;
  clientSeeds: string[];
  escrow: string | null;
  deck: Card[];
  next: number;
  order: number[];
  turnPos: number;
  turnEndsAt: number | null;
  fundingEndsAt: number | null;
  seats: SeatState[];
  settlement: Settlement | null;
  winners: number[] | null;
  allBust: boolean;
  settleSig: string | null;
  note: string;
}

export interface TableOptions {
  turnMs?: number;
  fundingMs?: number;
  nextHandMs?: number;
  botDelayMs?: number;
  log?: (msg: string) => void;
}

let roundCounter = BigInt(Date.now()) * 1000n;
/** Round ids are u64 on chain, so keep them numeric. */
export const nextRoundId = () => (++roundCounter).toString();

export class Table {
  readonly seated: (Player | null)[];
  readonly openedAt = Date.now();
  round: RoundState | null = null;
  private button = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private botTimers = new Set<ReturnType<typeof setTimeout>>();
  private busy = false;
  private closed = false;
  readonly turnMs: number;
  readonly fundingMs: number;
  readonly nextHandMs: number;
  readonly botDelayMs: number;
  private log: (m: string) => void;

  constructor(
    readonly id: string,
    readonly seats: number,
    readonly stake: bigint,
    private ledger: Ledger,
    private onChange: (t: Table) => void,
    opts: TableOptions = {},
  ) {
    this.seated = Array(seats).fill(null);
    this.turnMs = opts.turnMs ?? TURN_MS;
    this.fundingMs = opts.fundingMs ?? FUNDING_MS;
    this.nextHandMs = opts.nextHandMs ?? 6_000;
    this.botDelayMs = opts.botDelayMs ?? 700;
    this.log = opts.log ?? (() => {});
  }

  /* ---------------- seating ---------------- */

  get inRound() { return !!this.round && (this.round.phase === "funding" || this.round.phase === "playing" || this.round.phase === "settling"); }
  occupied() { return this.seated.filter(Boolean).length; }
  seatOf(userId: string) { return this.seated.findIndex(p => p?.userId === userId); }
  humans() { return this.seated.filter((p): p is Player => !!p && !p.isBot); }

  join(player: Player): number {
    if (this.closed) throw new Error("This table has closed.");
    if (this.seatOf(player.userId) >= 0) throw new Error("You're already at this table.");
    if (this.inRound) throw new Error("A hand is in progress. Join when it finishes.");
    const seat = this.seated.findIndex(s => s === null);
    if (seat < 0) throw new Error("This table is full.");
    this.seated[seat] = player;
    this.log(`${player.handle} sat at seat ${seat}`);
    this.maybeOpen();
    this.changed();
    return seat;
  }

  leave(userId: string) {
    const seat = this.seatOf(userId);
    if (seat < 0) return;
    const p = this.seated[seat]!;
    if (this.inRound) {
      p.leaving = true;
      const r = this.round!;
      if (r.phase === "playing" && r.order[r.turnPos] === seat) this.stand(seat, "stood");
    } else {
      this.seated[seat] = null;
    }
    this.changed();
  }

  setConnected(userId: string, connected: boolean) {
    const seat = this.seatOf(userId);
    if (seat < 0) return;
    this.seated[seat]!.connected = connected;
    this.changed();
  }

  /* ---------------- round lifecycle ---------------- */

  private maybeOpen() {
    if (this.inRound || this.busy || this.closed) return;
    if (this.occupied() < this.seats || this.humans().length === 0) return;
    void this.openRound();
  }

  private async openRound() {
    this.busy = true;
    const players = this.seated as Player[];
    const serverSeed = randomBytes(32).toString("hex");
    const id = nextRoundId();
    const { total, fee, net } = potPreview(this.stake, this.seats);
    const r: RoundState = {
      id, phase: "funding", serverSeed, commit: commitFor(serverSeed),
      clientSeeds: players.map(p => p.clientSeed), escrow: null, deck: [], next: 0,
      order: [], turnPos: -1, turnEndsAt: null, fundingEndsAt: Date.now() + this.fundingMs,
      seats: players.map(p => ({ player: p, deposited: false, hand: [], status: "waiting", revealed: false, payout: null })),
      settlement: { total, fee, net, payouts: [] }, winners: null, allBust: false, settleSig: null,
      note: "Table full. Stake to lock your seat.",
    };
    this.round = r;
    try {
      const { escrow } = await this.ledger.openRound(id, this.seats, this.stake);
      r.escrow = escrow;
    } catch (e) {
      this.log(`openRound failed: ${(e as Error).message}`);
      r.phase = "cancelled";
      r.note = "Couldn't open the escrow. Try again shortly.";
      this.busy = false;
      this.changed();
      return;
    }
    this.busy = false;
    this.schedule(this.fundingMs, () => this.fundingTimeout(id));
    r.seats.forEach((s, i) => { if (s.player.isBot) this.bot(() => this.deposit(s.player.userId, id).catch(e => this.log(`bot deposit: ${e.message}`))); void i; });
    this.changed();
  }

  async deposit(userId: string, roundId: string, signature?: string) {
    const r = this.round;
    if (!r || r.id !== roundId) throw new Error("That round is no longer open.");
    if (r.phase !== "funding" || !r.escrow) throw new Error("Stakes aren't open right now.");
    const seat = this.seatOf(userId);
    if (seat < 0) throw new Error("You're not seated at this table.");
    const s = r.seats[seat];
    if (s.deposited) throw new Error("You've already staked this hand.");
    await this.ledger.deposit(roundId, seat, s.player.wallet, this.stake, signature);
    if (this.round !== r || r.phase !== "funding") return; // round moved on while we waited
    s.deposited = true;
    s.status = "deposited";
    this.changed();
    if (r.seats.every(x => x.deposited)) this.startPlay();
  }

  private async fundingTimeout(roundId: string) {
    const r = this.round;
    if (!r || r.id !== roundId || r.phase !== "funding") return;
    const deposited = r.seats.flatMap((s, seat) => (s.deposited ? [{ seat, wallet: s.player.wallet }] : []));
    r.phase = "settling";
    this.changed();
    try {
      const { sig } = await this.ledger.cancel(r.id, deposited, this.stake);
      r.settleSig = sig;
    } catch (e) {
      this.log(`cancel failed: ${(e as Error).message}`);
    }
    r.phase = "cancelled";
    r.note = "Not everyone staked in time. Stakes refunded in full.";
    // Remove anyone who didn't stake.
    r.seats.forEach((s, i) => { if (!s.deposited) this.seated[i] = null; });
    this.afterRound();
  }

  private startPlay() {
    const r = this.round!;
    this.clearTimer();
    r.phase = "playing";
    r.fundingEndsAt = null;
    r.deck = shuffleDeck(r.serverSeed, r.id, r.clientSeeds);
    r.order = Array.from({ length: this.seats }, (_, i) => (this.button + i) % this.seats);
    // Two cards each, one at a time, starting left of the button.
    for (let pass = 0; pass < 2; pass++) for (const seat of r.order) r.seats[seat].hand.push(r.deck[r.next++]);
    for (const s of r.seats) s.status = isNatural(s.hand) ? "blackjack" : "playing";
    r.note = "Cards dealt.";
    r.turnPos = -1;
    this.advance();
  }

  private advance() {
    const r = this.round!;
    this.clearTimer();
    do { r.turnPos++; } while (r.turnPos < r.order.length && r.seats[r.order[r.turnPos]].status !== "playing");
    if (r.turnPos >= r.order.length) { r.turnEndsAt = null; void this.settle(); return; }
    const seat = r.order[r.turnPos];
    const s = r.seats[seat];
    s.revealed = true;
    r.turnEndsAt = Date.now() + this.turnMs;
    r.note = `${s.player.handle} to act.`;
    if (s.player.leaving) { this.stand(seat, "stood"); return; }
    this.schedule(this.turnMs, () => { if (this.round === r && r.order[r.turnPos] === seat) this.stand(seat, "timedout"); });
    if (s.player.isBot) this.bot(() => this.botAct(r, seat));
    this.changed();
  }

  act(userId: string, roundId: string, action: "hit" | "stand") {
    const r = this.round;
    if (!r || r.id !== roundId || r.phase !== "playing") throw new Error("There's no hand in play.");
    const seat = this.seatOf(userId);
    if (seat < 0 || r.order[r.turnPos] !== seat) throw new Error("It's not your turn.");
    if (action === "stand") return this.stand(seat, "stood");
    this.hit(seat);
  }

  private hit(seat: number) {
    const r = this.round!;
    const s = r.seats[seat];
    s.hand.push(r.deck[r.next++]);
    if (isBust(s.hand)) return this.stand(seat, "bust");
    if (handTotal(s.hand) === 21) return this.stand(seat, "stood");
    r.turnEndsAt = Date.now() + this.turnMs;
    this.clearTimer();
    this.schedule(this.turnMs, () => { if (this.round === r && r.order[r.turnPos] === seat) this.stand(seat, "timedout"); });
    if (s.player.isBot) this.bot(() => this.botAct(r, seat));
    this.changed();
  }

  private stand(seat: number, status: SeatStatus) {
    const r = this.round!;
    r.seats[seat].status = status;
    this.advance();
  }

  private async settle() {
    const r = this.round!;
    r.phase = "settling";
    r.note = "Settling the pot.";
    for (const s of r.seats) s.revealed = true;
    const { seats: winners, allBust } = winningSeats(r.seats.map(s => s.hand));
    const settlement = computeSettlement(this.stake, this.seats, winners);
    r.winners = allBust ? [] : winners;
    r.allBust = allBust;
    r.settlement = settlement;
    for (const p of settlement.payouts) r.seats[p.seat].payout = p.amount;
    this.changed();
    try {
      const { sig } = await this.ledger.settle(r.id, r.seats.map((s, seat) => ({ seat, wallet: s.player.wallet })), settlement);
      r.settleSig = sig;
      r.phase = "done";
      const names = winners.map(w => r.seats[w].player.handle);
      r.note = allBust ? "Everyone bust. Pot refunded evenly; the house fee was kept."
        : winners.length > 1 ? `${names.join(" & ")} split the pot.` : `${names[0]} takes the pot.`;
    } catch (e) {
      // Funds stay in escrow; the operator retries settle, or anyone can
      // call the program's timeout refund after its deadline.
      this.log(`settle failed for round ${r.id}: ${(e as Error).message}`);
      r.phase = "done";
      r.note = "Payout is delayed. Funds are safe in escrow and will be paid out.";
    }
    this.afterRound();
  }

  private afterRound() {
    this.clearTimer();
    this.button = (this.button + 1) % this.seats;
    this.seated.forEach((p, i) => { if (p && (p.leaving || (!p.isBot && !p.connected))) this.seated[i] = null; });
    // Seeds are mixed with the round id, so reusing a human's seed is safe; bots just pick new ones.
    for (const p of this.seated) if (p?.isBot) p.clientSeed = randomBytes(8).toString("hex");
    this.changed();
    this.schedule(this.nextHandMs, () => { this.round = null; this.changed(); this.maybeOpen(); });
  }

  /* ---------------- bots (mock mode only) ---------------- */

  private bot(fn: () => void) {
    const t = setTimeout(() => { this.botTimers.delete(t); if (!this.closed) fn(); }, this.botDelayMs);
    this.botTimers.add(t);
  }

  private botAct(r: RoundState, seat: number) {
    if (this.round !== r || r.phase !== "playing" || r.order[r.turnPos] !== seat) return;
    const s = r.seats[seat];
    if (handTotal(s.hand) < (s.player.standOn ?? 17)) this.hit(seat);
    else this.stand(seat, "stood");
  }

  /* ---------------- views ---------------- */

  view(userId: string | null): TableView {
    const r = this.round;
    const you = userId ? this.seatOf(userId) : -1;
    const seated: (SeatView | null)[] = this.seated.map((p, seat) => {
      if (!p) return null;
      const s = r?.seats[seat];
      const own = seat === you;
      const showAll = !!s && (own || s.revealed || r!.phase === "done");
      const cards = s ? s.hand.map((c, i) => (showAll || i > 0 ? c : null)) : [];
      return {
        seat, handle: p.handle, wallet: p.wallet, isBot: p.isBot, connected: p.connected,
        cards, total: s && showAll && s.hand.length ? handTotal(s.hand) : null,
        status: s?.status ?? "waiting", payout: s?.payout?.toString() ?? null,
      };
    });
    const st = r?.settlement;
    const reveal = r && (r.phase === "done" || r.phase === "cancelled");
    return {
      id: this.id, seats: this.seats, stake: this.stake.toString(), seated,
      yourSeat: you >= 0 ? you : null,
      round: r && {
        id: r.id, phase: r.phase, commit: r.commit, serverSeed: reveal ? r.serverSeed : null,
        clientSeeds: r.clientSeeds, escrow: r.escrow, fundingEndsAt: r.fundingEndsAt,
        order: r.order,
        turnSeat: r.phase === "playing" ? r.order[r.turnPos] ?? null : null, turnEndsAt: r.turnEndsAt,
        total: (st?.total ?? 0n).toString(), fee: (st?.fee ?? 0n).toString(), net: (st?.net ?? 0n).toString(),
        winners: r.winners, allBust: r.allBust, settleSig: r.settleSig, note: r.note,
      },
    };
  }

  summary(): TableSummary {
    return {
      id: this.id, seats: this.seats, stake: this.stake.toString(), occupied: this.occupied(),
      phase: this.inRound ? this.round!.phase : "open", openedAt: this.openedAt,
      players: this.seated.filter((p): p is Player => !!p).map(p => ({ handle: p.handle, isBot: p.isBot })),
    };
  }

  /** Has a free seat and isn't mid-hand. */
  get waiting() {
    return !this.inRound && this.occupied() < this.seats && this.humans().length > 0;
  }

  /* ---------------- plumbing ---------------- */

  private schedule(ms: number, fn: () => void) {
    this.clearTimer();
    this.timer = setTimeout(() => { this.timer = null; if (!this.closed) fn(); }, ms);
  }
  private clearTimer() { if (this.timer) clearTimeout(this.timer); this.timer = null; }
  private changed() { if (!this.closed) this.onChange(this); }

  close() {
    this.closed = true;
    this.clearTimer();
    for (const t of this.botTimers) clearTimeout(t);
    this.botTimers.clear();
  }
}
