import { randomBytes } from "node:crypto";
import {
  MIN_SEATS, MAX_SEATS, HOUSE_FEE_BPS, parseUnits, isSolanaAddress,
  type ClientMsg, type Events, type EventType, type Requests, type RequestType, type SessionInfo,
} from "@pot21/shared";
import type { Ledger } from "./ledger/types.ts";
import { Auth, type User } from "./auth.ts";
import type { MockLedger } from "./ledger/mock.ts";
import type { PrivyVerifier } from "./privy.ts";
import { Table, type TableOptions } from "./table.ts";

export interface Conn {
  send(data: string): void;
  userId: string | null;
}

export interface HubOptions {
  allowBots: boolean;
  /** Handle-only login. Fine for demo mode; never with real tokens. */
  allowDevLogin?: boolean;
  /** Fee on deposits and withdrawals, in basis points (200 = 2%). */
  depositFeeBps?: number;
  withdrawFeeBps?: number;
  /** Demo mode: tokens placed in a newly connected Phantom wallet so there's something to deposit. */
  demoPhantomBalance?: bigint;
  /** Where accounts and sign-ins are saved. Omit to keep them in memory only. */
  accountsFile?: string | null;
  /** Privy sign-in. When set, "Sign in with X" goes through Privy. */
  privy?: PrivyVerifier | null;
  starterBalance: bigint;
  minStake: bigint;
  maxStake: bigint;
  table?: TableOptions;
  log?: (m: string) => void;
}

const BOT_NAMES = ["solsharp", "degen_dana", "hitonsoft17", "moonmarlo", "acesmaria", "lamportlou", "burntchips", "vegasvik", "ridgeback", "splitkings"];

type Handler<K extends RequestType> = (conn: Conn, p: Requests[K]["req"]) => Promise<Requests[K]["res"]> | Requests[K]["res"];

export class Hub {
  readonly auth: Auth;
  readonly tables = new Map<string, Table>();
  private conns = new Map<string, Set<Conn>>();
  private all = new Set<Conn>();
  private log: (m: string) => void;

  constructor(readonly ledger: Ledger, private opts: HubOptions) {
    this.auth = new Auth({ file: opts.accountsFile ?? null });
    this.log = opts.log ?? (() => {});
    ledger.onTx = (wallet, tx) => this.toWallet(wallet, "wallet:tx", tx);
    ledger.onBalance = wallet => void this.pushBalance(wallet);
  }

  /* ---------------- connections ---------------- */

  connect(conn: Conn) { this.all.add(conn); }

  disconnect(conn: Conn) {
    this.all.delete(conn);
    if (!conn.userId) return;
    const set = this.conns.get(conn.userId);
    set?.delete(conn);
    if (set && set.size === 0) {
      this.conns.delete(conn.userId);
      this.tableOf(conn.userId)?.setConnected(conn.userId, false);
    }
  }

  async handle(conn: Conn, raw: string) {
    let msg: ClientMsg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (typeof msg?.id !== "number" || typeof msg.type !== "string") return;
    const h = (this.handlers as Record<string, Handler<any>>)[msg.type];
    try {
      if (!h) throw new Error(`Unknown request "${msg.type}".`);
      if (msg.type !== "auth" && msg.type !== "auth:challenge" && !conn.userId) throw new Error("Log in first.");
      const result = await h(conn, msg.payload ?? {});
      conn.send(JSON.stringify({ id: msg.id, ok: true, result }));
    } catch (e) {
      conn.send(JSON.stringify({ id: msg.id, ok: false, error: (e as Error).message }));
    }
  }

  /* ---------------- requests ---------------- */

  private handlers: { [K in RequestType]: Handler<K> } = {
    "auth:challenge": (_conn, p) => ({ message: this.auth.challenge(String(p.wallet ?? "")) }),

    auth: async (conn, p) => {
      let user: User | null = null, token = p.sessionToken ?? "", isNew = false, starter = false;
      if (p.sessionToken) user = this.auth.resume(p.sessionToken);
      if (!user && p.privyToken) {
        if (!this.opts.privy) throw new Error("X sign-in isn't set up on this server.");
        const r = this.auth.loginPrivy(await this.opts.privy.signIn(String(p.privyToken)));
        user = r.user; token = r.token; isNew = r.isNew;
        starter = isNew;
      } else if (!user && p.phantom) {
        const gameWallet = this.ledger.mode === "solana" ? p.wallet : undefined;
        if (this.ledger.mode === "solana" && !gameWallet) throw new Error("Your browser didn't send a game wallet.");
        const r = await this.auth.loginPhantom(String(p.phantom.wallet), String(p.phantom.signature), gameWallet);
        user = r.user; token = r.token; isNew = r.isNew;
        if (isNew && this.ledger.mode === "mock" && this.opts.demoPhantomBalance) await (this.ledger as MockLedger).mintTo(user.linked!, this.opts.demoPhantomBalance);
      } else if (!user) {
        if (!p.handle) throw new Error("Your session expired. Sign in again.");
        if (!this.opts.allowDevLogin) throw new Error("Sign in with Phantom.");
        if (p.wallet && this.ledger.mode !== "solana") throw new Error("Bring-your-own wallet is only for solana mode.");
        if (p.wallet && !isSolanaAddress(p.wallet)) throw new Error("That isn't a Solana address.");
        const r = this.auth.loginDev(p.handle, p.wallet);
        user = r.user; token = r.token; isNew = r.isNew;
        starter = isNew;
      }
      conn.userId = user.id;
      if (!this.conns.has(user.id)) this.conns.set(user.id, new Set());
      this.conns.get(user.id)!.add(conn);
      // Demo starter tokens, after the connection is registered so the player sees the transaction.
      if (starter && this.ledger.faucet) await this.ledger.faucet(user.wallet, this.opts.starterBalance);
      const t = this.tableOf(user.id);
      t?.setConnected(user.id, true);
      queueMicrotask(() => {
        conn.send(JSON.stringify({ event: "table:state", data: t ? t.view(user!.id) : null }));
        conn.send(JSON.stringify({ event: "lobby:update", data: this.lobby() }));
        void this.pushBalance(user!.wallet);
        if (user!.linked) void this.pushBalance(user!.linked);
      });
      return { session: this.session(user), sessionToken: token };
    },

    "auth:logout": (conn, p) => {
      this.auth.endSession(String(p.sessionToken ?? ""));
      const t = this.tableOf(conn.userId!);
      if (t) { t.leave(conn.userId!); this.reapTable(t); }
      return {};
    },

    "lobby:list": () => ({ tables: this.lobby() }),

    "table:create": async (conn, p) => {
      const seats = Math.floor(Number(p.seats));
      const bots = Math.floor(Number(p.bots ?? 0));
      const table = await this.openTable(conn.userId!, seats, this.stakeOf(p.stake), bots, this.checkSeed(p.clientSeed));
      return { tableId: table.id };
    },

    "table:quick": async (conn, p) => {
      const uid = conn.userId!;
      if (this.tableOf(uid)) throw new Error("Leave your current table first.");
      const stake = this.stakeOf(p.stake);
      const seed = this.checkSeed(p.clientSeed);
      const user = this.userById(uid);
      if ((await this.ledger.balance(user.wallet)) < stake) throw new Error("Your game wallet doesn't hold enough for this stake. Deposit first.");
      // Prefer the table closest to starting, then the one waiting longest.
      const match = [...this.tables.values()]
        .filter(t => t.waiting && t.stake === stake)
        .sort((a, b) => (b.occupied() / b.seats - a.occupied() / a.seats) || a.openedAt - b.openedAt)[0];
      if (match) {
        match.join({ userId: uid, handle: user.handle, wallet: user.wallet, isBot: false, clientSeed: seed, connected: true, leaving: false });
        this.broadcastLobby();
        return { tableId: match.id, joined: true };
      }
      const table = await this.openTable(uid, Math.floor(Number(p.seats ?? 2)), stake, 0, seed);
      return { tableId: table.id, joined: false };
    },

    "table:join": async (conn, p) => {
      const uid = conn.userId!;
      const user = this.userById(uid);
      const t = this.tables.get(p.tableId);
      if (!t) throw new Error("That table no longer exists.");
      if (this.tableOf(uid) && this.tableOf(uid) !== t) throw new Error("Leave your current table first.");
      const bal = await this.ledger.balance(user.wallet);
      if (bal < t.stake) throw new Error("Your game wallet doesn't hold enough for this stake. Deposit first.");
      const seed = this.checkSeed(p.clientSeed);
      t.join({ userId: uid, handle: user.handle, wallet: user.wallet, isBot: false, clientSeed: seed, connected: true, leaving: false });
      this.broadcastLobby();
      return {};
    },

    "table:leave": conn => {
      const uid = conn.userId!;
      const t = this.tableOf(uid);
      if (!t) return {};
      t.leave(uid);
      this.toUser(uid, "table:state", null);
      this.reapTable(t);
      this.broadcastLobby();
      return {};
    },

    "round:deposit": async (conn, p) => {
      const t = this.tableOf(conn.userId!);
      if (!t) throw new Error("You're not at a table.");
      await t.deposit(conn.userId!, p.roundId, p.signature);
      return {};
    },

    "round:action": (conn, p) => {
      const t = this.tableOf(conn.userId!);
      if (!t) throw new Error("You're not at a table.");
      if (p.action !== "hit" && p.action !== "stand") throw new Error("Unknown action.");
      t.act(conn.userId!, p.roundId, p.action);
      return {};
    },

    "wallet:deposit": async (conn, p) => {
      const u = this.userById(conn.userId!);
      if (!u.linked) throw new Error("Sign in with Phantom to deposit.");
      const amount = this.amount(p.amount);
      if (this.ledger.mode === "solana" && !p.signature) throw new Error("Approve the deposit in Phantom first.");
      await this.ledger.transferIn(u.linked, u.wallet, amount, this.fees.depositBps, p.signature);
      return {};
    },

    "wallet:withdraw": async (conn, p) => {
      const u = this.userById(conn.userId!);
      if (!u.linked) throw new Error("Sign in with Phantom to withdraw.");
      const amount = this.amount(p.amount);
      if (this.ledger.mode === "solana" && !p.signature) throw new Error("The withdrawal wasn't signed.");
      await this.ledger.transferOut(u.wallet, u.linked, amount, this.fees.withdrawBps, p.signature);
      return {};
    },

    "wallet:link": async (conn, p) => {
      const before = this.userById(conn.userId!).linked;
      const user = await this.auth.linkPhantom(conn.userId!, String(p.wallet ?? ""), String(p.signature ?? ""));
      if (!before && this.ledger.mode === "mock" && this.opts.demoPhantomBalance) await (this.ledger as MockLedger).mintTo(user.linked!, this.opts.demoPhantomBalance);
      void this.pushBalance(user.linked!);
      return { session: this.session(user) };
    },

    "wallet:faucet": async conn => {
      if (!this.ledger.faucet) throw new Error("Top-ups are only available in demo mode.");
      const u = this.userById(conn.userId!);
      const bal = await this.ledger.balance(u.wallet);
      if (bal > this.opts.starterBalance * 5n) throw new Error("You already have plenty of demo tokens.");
      await this.ledger.faucet(u.wallet, this.opts.starterBalance / 2n);
      return {};
    },
  };

  /* ---------------- helpers ---------------- */

  private stakeOf(raw: unknown): bigint {
    let stake: bigint;
    try { stake = parseUnits(String(raw), this.ledger.token.decimals); } catch { throw new Error("Enter a stake like 25 or 2.5."); }
    if (stake < this.opts.minStake || stake > this.opts.maxStake) throw new Error("Stake is outside this site's limits.");
    return stake;
  }

  private async openTable(uid: string, seats: number, stake: bigint, bots: number, seed: string): Promise<Table> {
    if (this.tableOf(uid)) throw new Error("Leave your current table first.");
    if (!(seats >= MIN_SEATS && seats <= MAX_SEATS)) throw new Error(`Tables have ${MIN_SEATS}–${MAX_SEATS} seats.`);
    if (bots && !this.opts.allowBots) throw new Error("Bots are only available in demo mode.");
    if (bots < 0 || bots > seats - 1) throw new Error("Too many bots for that table.");
    const user = this.userById(uid);
    if ((await this.ledger.balance(user.wallet)) < stake) throw new Error("Your game wallet doesn't hold enough for this stake. Deposit first.");

    const id = randomBytes(4).toString("hex");
    const table = new Table(id, seats, stake, this.ledger, t => this.broadcastTable(t), { ...this.opts.table, log: this.log });
    this.tables.set(id, table);
    table.join({ userId: uid, handle: user.handle, wallet: user.wallet, isBot: false, clientSeed: seed, connected: true, leaving: false });
    const names = [...BOT_NAMES].sort(() => Math.random() - 0.5);
    for (let i = 0; i < bots; i++) {
      const { user: bot } = this.auth.loginDev(`${names[i]}_bot`.slice(0, 15));
      this.auth.markEphemeral(bot.id);
      await this.ledger.faucet?.(bot.wallet, stake * 1000n);
      table.join({ userId: bot.id, handle: bot.handle, wallet: bot.wallet, isBot: true, clientSeed: randomBytes(8).toString("hex"), connected: true, leaving: false, standOn: 16 + (i % 3) });
    }
    this.broadcastLobby();
    return table;
  }

  get fees() {
    return { potBps: HOUSE_FEE_BPS, depositBps: this.opts.depositFeeBps ?? HOUSE_FEE_BPS, withdrawBps: this.opts.withdrawFeeBps ?? HOUSE_FEE_BPS };
  }

  private amount(raw: unknown): bigint {
    let v: bigint;
    try { v = parseUnits(String(raw ?? ""), this.ledger.token.decimals); } catch { throw new Error("Enter an amount like 100 or 12.5."); }
    if (v <= 0n) throw new Error("Enter an amount above zero.");
    return v;
  }

  private checkSeed(raw: unknown): string {
    const seed = String(raw ?? "");
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(seed)) throw new Error("Client seed must be 8–64 letters, numbers, - or _.");
    return seed;
  }

  private userById(id: string): User {
    const u = this.auth.get(id);
    if (!u) throw new Error("Unknown user.");
    return u;
  }

  private session(user: User): SessionInfo {
    return { userId: user.id, handle: user.handle, wallet: user.wallet, login: user.login, linked: user.linked, fees: this.fees, mode: this.ledger.mode, token: this.ledger.token, chain: this.ledger.chain };
  }

  tableOf(userId: string): Table | undefined {
    for (const t of this.tables.values()) if (t.seatOf(userId) >= 0) return t;
    return undefined;
  }

  lobby() { return [...this.tables.values()].filter(t => t.humans().length > 0).map(t => t.summary()); }

  private reapTable(t: Table) {
    if (t.humans().length === 0 && !t.inRound) { t.close(); this.tables.delete(t.id); }
  }

  private broadcastTable(t: Table) {
    for (const p of t.seated) if (p && !p.isBot) this.toUser(p.userId, "table:state", t.view(p.userId));
    this.broadcastLobby();
  }

  private lastLobby = "";
  private broadcastLobby() {
    const data = JSON.stringify({ event: "lobby:update", data: this.lobby() });
    if (data === this.lastLobby) return;
    this.lastLobby = data;
    for (const c of this.all) if (c.userId) c.send(data);
  }

  private async pushBalance(wallet: string) {
    const balance = (await this.ledger.balance(wallet)).toString();
    for (const [uid] of this.conns) {
      const u = this.userById(uid);
      if (u.wallet === wallet) this.toUser(uid, "wallet:balance", { balance });
      if (u.linked === wallet && this.ledger.mode === "mock") this.toUser(uid, "wallet:linked", { balance });
    }
  }

  private toWallet<E extends EventType>(wallet: string, event: E, data: Events[E]) {
    for (const [uid] of this.conns) {
      const u = this.userById(uid);
      if (u.wallet === wallet) this.toUser(uid, event, data);
    }
  }

  private toUser<E extends EventType>(userId: string, event: E, data: Events[E]) {
    const s = JSON.stringify({ event, data });
    for (const c of this.conns.get(userId) ?? []) c.send(s);
  }

  /** Close tables nobody human is sitting at. Called on a timer. */
  reap() { for (const t of [...this.tables.values()]) this.reapTable(t); this.broadcastLobby(); }

  shutdown() {
    for (const t of this.tables.values()) t.close();
    this.auth.flush();
  }
}
