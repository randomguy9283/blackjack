import { randomBytes, createHash } from "node:crypto";
import { readFileSync, writeFileSync, renameSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { base58, base58Decode, isSolanaAddress, signInMessage } from "@pot21/shared";
import { verifyEd25519 } from "./sig.ts";

export interface User {
  id: string;
  handle: string;
  /** Game wallet: holds the player's tokens on the site, pays stakes, receives winnings. */
  wallet: string;
  /** Phantom wallet linked for deposits and withdrawals. */
  linked: string | null;
  login: "privy" | "phantom" | "dev";
}

const CHALLENGE_MS = 5 * 60_000;
/** Signed-in sessions last 30 days from the last visit. */
export const SESSION_MS = 30 * 24 * 60 * 60_000;

/** Session tokens are stored hashed, so a copy of the data file can't be used to sign in. */
const hashToken = (t: string) => createHash("sha256").update(t).digest("base64url");

interface SavedData {
  version: 1;
  users: { key: string; user: User }[];
  sessions: { hash: string; userId: string; expires: number }[];
}

/**
 * Users and sessions.
 *
 * PHANTOM (now): the browser asks for a challenge, the player signs it in
 * Phantom (free, no transaction), and the server checks the signature.
 * The account is keyed by that Phantom address.
 *
 * DEV LOGIN: any X handle, for local testing only. Disabled in solana mode
 * unless ALLOW_DEV_LOGIN=1.
 *
 * PRIVY: the main sign-in. privy.ts verifies the access token and reads the
 * player's X handle and Privy-created Solana wallet; loginPrivy keys the
 * account by Privy user id and uses that wallet as the game wallet.
 */
export class Auth {
  private byKey = new Map<string, User>(); // "x:<handle>", "sol:<address>" or "privy:<did>"
  private sessions = new Map<string, { userId: string; expires: number }>(); // hashed token -> session
  private byId = new Map<string, User>();
  private challenges = new Map<string, { message: string; expires: number }>();
  /** Accounts that aren't saved (practice bots). */
  private ephemeral = new Set<string>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private file: string | null;
  private now: () => number;

  /**
   * `file`: where accounts and sessions are saved (JSON). Without it,
   * everything lives in memory only (tests, preview).
   */
  constructor(opts: { file?: string | null; makeWallet?: () => string; now?: () => number } = {}) {
    this.file = opts.file ?? null;
    if (opts.makeWallet) this.makeWallet = opts.makeWallet;
    this.now = opts.now ?? Date.now;
    this.load();
  }
  private makeWallet: () => string = () => base58(randomBytes(32));

  private load() {
    if (!this.file) return;
    let data: SavedData;
    try { data = JSON.parse(readFileSync(this.file, "utf8")); }
    catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return; // first run
      throw new Error(`Couldn't read the accounts file ${this.file}: ${(e as Error).message}`);
    }
    for (const { key, user } of data.users ?? []) { this.byKey.set(key, user); this.byId.set(user.id, user); }
    const now = this.now();
    for (const s of data.sessions ?? []) if (s.expires > now && this.byId.has(s.userId)) this.sessions.set(s.hash, { userId: s.userId, expires: s.expires });
  }

  /** Write changes to disk shortly after they happen (batched). */
  private changed() {
    if (!this.file || this.saveTimer) return;
    this.saveTimer = setTimeout(() => { this.saveTimer = null; this.flush(); }, 250);
    this.saveTimer.unref?.();
  }

  /** Save now. Writes to a temp file then renames, so a crash never leaves a half-written file. */
  flush() {
    if (!this.file) return;
    if (this.saveTimer) { clearTimeout(this.saveTimer); this.saveTimer = null; }
    const now = this.now();
    const data: SavedData = {
      version: 1,
      users: [...this.byKey].filter(([, u]) => !this.ephemeral.has(u.id)).map(([key, user]) => ({ key, user })),
      sessions: [...this.sessions].filter(([, s]) => s.expires > now && !this.ephemeral.has(s.userId)).map(([hash, s]) => ({ hash, ...s })),
    };
    mkdirSync(dirname(this.file), { recursive: true });
    const tmp = this.file + ".tmp";
    writeFileSync(tmp, JSON.stringify(data));
    renameSync(tmp, this.file);
  }

  private create(key: string, handle: string, wallet: string, linked: string | null, login: User["login"]): User {
    const user: User = { id: randomBytes(8).toString("hex"), handle, wallet, linked, login };
    this.byKey.set(key, user);
    this.byId.set(user.id, user);
    this.changed();
    return user;
  }

  private session(user: User) {
    const token = randomBytes(24).toString("base64url");
    this.sessions.set(hashToken(token), { userId: user.id, expires: this.now() + SESSION_MS });
    this.changed();
    return token;
  }

  /** Practice bots: usable now, never saved. */
  markEphemeral(userId: string) { this.ephemeral.add(userId); }

  /** Sign out: the token stops working immediately. */
  endSession(token: string) {
    if (this.sessions.delete(hashToken(token))) this.changed();
  }

  /** `wallet` lets a devnet tester bring their own browser wallet (solana mode only). */
  loginDev(rawHandle: string, wallet?: string): { user: User; token: string; isNew: boolean } {
    const handle = normaliseHandle(rawHandle);
    const key = "x:" + handle.toLowerCase();
    let user = this.byKey.get(key);
    const isNew = !user;
    if (!user) user = this.create(key, handle, wallet ?? this.makeWallet(), null, "dev");
    else if (wallet && user.wallet !== wallet) throw new Error("That handle is linked to a different wallet.");
    return { user, token: this.session(user), isNew };
  }

  challenge(wallet: string): string {
    if (!isSolanaAddress(wallet)) throw new Error("That isn't a Solana wallet address.");
    const message = signInMessage(wallet, randomBytes(12).toString("hex"), new Date().toISOString());
    this.challenges.set(wallet, { message, expires: Date.now() + CHALLENGE_MS });
    return message;
  }

  /**
   * Finish Phantom sign-in. `gameWallet` is supplied by the browser in
   * solana mode (it holds that wallet's key); otherwise the server makes one.
   */
  /** Check a signed challenge from a wallet (one use, five minutes). */
  private async checkSignature(wallet: string, signatureB58: string) {
    const ch = this.challenges.get(wallet);
    if (!ch || ch.expires < Date.now()) throw new Error("Request expired. Try connecting again.");
    this.challenges.delete(wallet);
    let sig: Uint8Array;
    try { sig = base58Decode(signatureB58); } catch { throw new Error("That signature isn't valid."); }
    const ok = await verifyEd25519(base58Decode(wallet), new TextEncoder().encode(ch.message), sig);
    if (!ok) throw new Error("Phantom's signature didn't match. Try connecting again.");
  }

  /**
   * Finish Phantom sign-in. `gameWallet` is supplied by the browser in
   * solana mode (it holds that wallet's key); otherwise the server makes one.
   */
  async loginPhantom(wallet: string, signatureB58: string, gameWallet?: string): Promise<{ user: User; token: string; isNew: boolean }> {
    await this.checkSignature(wallet, signatureB58);
    if (gameWallet !== undefined && !isSolanaAddress(gameWallet)) throw new Error("Game wallet address is invalid.");
    if (gameWallet === wallet) throw new Error("The game wallet must be separate from your Phantom wallet.");
    const key = "sol:" + wallet;
    let user = this.byKey.get(key);
    const isNew = !user;
    if (!user) user = this.create(key, short(wallet), gameWallet ?? this.makeWallet(), wallet, "phantom");
    else if (gameWallet && user.wallet !== gameWallet) {
      throw new Error("Your game wallet is stored in a different browser. Sign in there, or restore its backup key in this one.");
    }
    return { user, token: this.session(user), isNew };
  }

  /**
   * Sign in with a verified Privy identity. The account is keyed by the
   * Privy user id; the X handle is refreshed each time in case it changed.
   * The game wallet is the Solana wallet Privy created for the player.
   */
  loginPrivy(id: { did: string; xUsername: string; wallet: string }): { user: User; token: string; isNew: boolean } {
    const key = "privy:" + id.did;
    let user = this.byKey.get(key);
    const isNew = !user;
    if (!user) user = this.create(key, "@" + id.xUsername, id.wallet, null, "privy");
    else if (user.handle !== "@" + id.xUsername || user.wallet !== id.wallet) {
      user.handle = "@" + id.xUsername; user.wallet = id.wallet;
      this.changed();
    }
    return { user, token: this.session(user), isNew };
  }

  /** Link a Phantom wallet to an existing account for deposits and withdrawals. */
  async linkPhantom(userId: string, wallet: string, signatureB58: string): Promise<User> {
    const user = this.byId.get(userId);
    if (!user) throw new Error("Unknown user.");
    await this.checkSignature(wallet, signatureB58);
    if (wallet === user.wallet) throw new Error("That's your game wallet. Connect the Phantom wallet you'll deposit from.");
    for (const u of this.byId.values()) if (u !== user && u.linked === wallet) throw new Error("That Phantom wallet is already linked to another account.");
    user.linked = wallet;
    this.changed();
    return user;
  }

  get(id: string): User | undefined { return this.byId.get(id); }

  /** Resume a saved sign-in. Each visit extends it by another 30 days. */
  resume(token: string): User | null {
    const h = hashToken(token);
    const s = this.sessions.get(h);
    if (!s) return null;
    if (s.expires <= this.now()) { this.sessions.delete(h); this.changed(); return null; }
    s.expires = this.now() + SESSION_MS;
    this.changed();
    return this.byId.get(s.userId) ?? null;
  }
}

const short = (a: string) => a.slice(0, 4) + "…" + a.slice(-4);

export function normaliseHandle(raw: string): string {
  const h = raw.trim().replace(/^@+/, "");
  if (!/^[A-Za-z0-9_]{1,15}$/.test(h)) throw new Error("X handles are 1–15 letters, numbers or underscores.");
  return "@" + h;
}
