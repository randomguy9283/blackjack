import { describe, it, afterEach } from "node:test";
import assert from "node:assert/strict";
import { shuffleDeck, verifyCommit, verifyRound, handTotal, type TableView, type ServerMsg } from "@pot21/shared";
import { MockLedger } from "../src/ledger/mock.ts";
import { Table, type Player } from "../src/table.ts";
import { Hub, type Conn } from "../src/hub.ts";

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
async function until(cond: () => boolean, ms = 3000) {
  const end = Date.now() + ms;
  while (!cond()) { if (Date.now() > end) throw new Error("timed out waiting"); await sleep(5); }
}
const FAST = { turnMs: 150, fundingMs: 200, nextHandMs: 60, botDelayMs: 5 };
const STAKE = 25_000_000n;
const player = (id: string, isBot = false): Player => ({ userId: id, handle: "@" + id, wallet: "W" + id, isBot, clientSeed: "seed-" + id + "-xx", connected: true, leaving: false, standOn: 17 });

let open: Table[] = [];
afterEach(() => { open.forEach(t => t.close()); open = []; });

async function setup(seats: number, bots: number) {
  const ledger = new MockLedger();
  const t = new Table("t1", seats, STAKE, ledger, () => {}, FAST);
  open.push(t);
  const humans: Player[] = [];
  for (let i = 0; i < seats - bots; i++) { const p = player("h" + i); humans.push(p); await ledger.faucet(p.wallet, 1000_000_000n); }
  for (let i = 0; i < bots; i++) { const p = player("b" + i, true); await ledger.faucet(p.wallet, 1000_000_000n); t.join(p); }
  for (const h of humans) t.join(h);
  return { ledger, t, humans };
}

describe("table round", () => {
  it("plays a full hand, takes exactly 2% and conserves tokens", async () => {
    const { ledger, t, humans } = await setup(4, 3);
    await until(() => t.round?.phase === "funding" && !!t.round.escrow);
    const r = t.round!;
    await t.deposit(humans[0].userId, r.id);
    await until(() => r.phase === "playing" || r.phase === "settling" || r.phase === "done");
    // The human acts whenever it's their turn: stand.
    await until(() => {
      if (r.phase === "playing" && r.order[r.turnPos] === 3) t.act(humans[0].userId, r.id, "stand");
      return r.phase === "done";
    });
    assert.equal(ledger.houseBalance(), 2_000_000n); // 2% of 100
    assert.ok(ledger.audit().ok);
    const paid = r.seats.reduce((a, s) => a + (s.payout ?? 0n), 0n);
    assert.equal(paid, 98_000_000n);
    // Provably fair: the revealed seed matches the commit and reproduces the deal.
    assert.ok(verifyCommit(r.serverSeed, r.commit));
    const deck = shuffleDeck(r.serverSeed, r.id, r.clientSeeds);
    assert.deepEqual(r.seats[r.order[0]].hand[0], deck[0]);
    assert.deepEqual(r.seats[r.order[1]].hand[0], deck[1]);
    const args = { serverSeed: r.serverSeed, commit: r.commit, roundId: r.id, clientSeeds: r.clientSeeds, order: r.order, hands: r.seats.map(s => s.hand) };
    assert.deepEqual(verifyRound(args), { ok: true });
    const tampered = structuredClone(args.hands); tampered[0][0] = { r: tampered[0][0].r === "A" ? "K" : "A", s: "S" };
    assert.equal(verifyRound({ ...args, hands: tampered }).ok, false);
  });

  it("refunds everyone in full when someone doesn't stake in time", async () => {
    const { ledger, t, humans } = await setup(3, 1);
    await until(() => t.round?.phase === "funding" && !!t.round.escrow);
    const r = t.round!;
    await t.deposit(humans[0].userId, r.id);
    await until(() => r.phase === "cancelled");
    assert.equal(await ledger.balance(humans[0].wallet), 1000_000_000n);
    assert.equal(ledger.houseBalance(), 0n);
    assert.ok(ledger.audit().ok);
    assert.equal(t.seatOf(humans[1].userId), -1, "non-staker loses their seat");
    assert.ok(t.seatOf(humans[0].userId) >= 0, "staker keeps their seat");
  });

  it("auto-stands a player whose turn timer runs out", async () => {
    const { t, humans } = await setup(2, 1);
    await until(() => t.round?.phase === "funding" && !!t.round.escrow);
    const r = t.round!;
    await t.deposit(humans[0].userId, r.id);
    await until(() => r.phase === "done", 4000);
    const s = r.seats[t.seatOf(humans[0].userId)];
    assert.ok(["timedout", "blackjack"].includes(s.status), `status was ${s.status}`);
  });

  it("rejects out-of-turn moves and hides opponents' hole cards", async () => {
    const { t, humans } = await setup(2, 0);
    await until(() => t.round?.phase === "funding" && !!t.round.escrow);
    const r = t.round!;
    await t.deposit(humans[0].userId, r.id);
    await t.deposit(humans[1].userId, r.id);
    assert.equal(r.phase, "playing");
    const first = r.order[r.turnPos];
    const waiting = first === 0 ? 1 : 0;
    const waitingUser = t.seated[waiting]!.userId;
    if (r.seats[first].status === "playing") {
      assert.throws(() => t.act(waitingUser, r.id, "hit"), /not your turn/);
    }
    const v: TableView = t.view(t.seated[first]!.userId);
    const theirs = v.seated[waiting]!;
    if (!r.seats[waiting].revealed) assert.equal(theirs.cards[0], null);
    assert.notEqual(v.seated[first]!.cards[0], null, "you always see your own cards");
  });

  it("won't take a stake twice or from a stranger", async () => {
    const { t, humans } = await setup(2, 1);
    await until(() => t.round?.phase === "funding" && !!t.round.escrow);
    const r = t.round!;
    await t.deposit(humans[0].userId, r.id);
    await assert.rejects(t.deposit("nobody", r.id), /not seated/);
  });
});

describe("hub over the wire protocol", () => {
  it("logs in, sits with bots, stakes, plays and gets paid", async () => {
    const ledger = new MockLedger();
    const hub = new Hub(ledger, { allowBots: true, allowDevLogin: true, starterBalance: 1000_000_000n, minStake: 1_000_000n, maxStake: 10_000_000_000n, table: FAST });
    const inbox: ServerMsg[] = [];
    const conn: Conn = { userId: null, send: d => inbox.push(JSON.parse(d)) };
    hub.connect(conn);
    let n = 0;
    const call = async (type: string, payload: unknown = {}) => {
      const id = ++n;
      await hub.handle(conn, JSON.stringify({ id, type, payload }));
      const reply = inbox.find(m => "id" in m && m.id === id) as any;
      if (!reply.ok) throw new Error(reply.error);
      return reply.result;
    };
    await assert.rejects(call("lobby:list"), /Log in first/);
    const { session } = await call("auth", { handle: "@alexinthewoods" });
    assert.equal(session.handle, "@alexinthewoods");
    assert.equal(await ledger.balance(session.wallet), 1000_000_000n);
    await assert.rejects(call("table:create", { seats: 9, stake: "25", clientSeed: "my-seed-123" }), /2–6 seats/);
    await assert.rejects(call("table:create", { seats: 3, stake: "5000", clientSeed: "my-seed-123" }), /enough for this stake/);
    await call("table:create", { seats: 3, stake: "25", bots: 2, clientSeed: "my-seed-123" });
    await assert.rejects(call("table:create", { seats: 3, stake: "25", clientSeed: "my-seed-123" }), /Leave your current table/);
    const latest = () => [...inbox].reverse().find(m => "event" in m && m.event === "table:state") as { data: TableView } | undefined;
    await until(() => !!latest()?.data?.round?.escrow);
    const roundId = latest()!.data.round!.id;
    await call("round:deposit", { roundId });
    await until(() => {
      const v = latest()!.data;
      if (v.round?.phase === "playing" && v.round.turnSeat === v.yourSeat) void call("round:action", { roundId, action: "stand" }).catch(() => {});
      return v.round?.phase === "done";
    });
    const v = latest()!.data;
    assert.equal(v.round!.fee, "1500000"); // 2% of 75
    assert.ok(v.round!.serverSeed, "seed revealed after the hand");
    const r = v.round!;
    assert.deepEqual(verifyRound({ serverSeed: r.serverSeed!, commit: r.commit, roundId: r.id, clientSeeds: r.clientSeeds, order: r.order, hands: v.seated.map(s => s!.cards as any) }), { ok: true }, "client-side verify works from the wire view");
    assert.ok(inbox.some(m => "event" in m && m.event === "wallet:tx"));
    assert.ok(ledger.audit().ok);
    const total = handTotal(v.seated[v.yourSeat!]!.cards.filter(Boolean) as any);
    assert.ok(total > 0);
    hub.shutdown();
  });
});
