import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync, sign } from "node:crypto";
import { base58, type ServerMsg } from "@pot21/shared";
import { MockLedger } from "../src/ledger/mock.ts";
import { Hub, type Conn } from "../src/hub.ts";

/** A stand-in for Phantom: an Ed25519 keypair that signs messages. */
function fakePhantom() {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const raw = Buffer.from(publicKey.export({ format: "jwk" }).x!, "base64url");
  return { address: base58(raw), signMessage: (m: string) => base58(sign(null, Buffer.from(m), privateKey)) };
}

function client(hub: Hub) {
  const inbox: ServerMsg[] = [];
  const conn: Conn = { userId: null, send: d => inbox.push(JSON.parse(d)) };
  hub.connect(conn);
  let n = 0;
  const call = async (type: string, payload: unknown = {}) => {
    const id = ++n;
    await hub.handle(conn, JSON.stringify({ id, type, payload }));
    const reply = inbox.find(m => "id" in m && m.id === id) as any;
    if (!reply.ok) throw new Error(reply.error);
    return reply.result;
  };
  const last = (event: string) => ([...inbox].reverse().find(m => "event" in m && m.event === event) as any)?.data;
  return { call, last, inbox };
}

const newHub = () => {
  const ledger = new MockLedger();
  const hub = new Hub(ledger, { allowBots: true, allowDevLogin: false, starterBalance: 1000_000_000n, minStake: 1_000_000n, maxStake: 10_000_000_000n, demoPhantomBalance: 1000_000_000n });
  return { ledger, hub };
};

describe("Phantom sign-in", () => {
  it("signs in with a valid signature and links a separate game wallet", async () => {
    const { hub } = newHub();
    const ph = fakePhantom();
    const c = client(hub);
    const { message } = await c.call("auth:challenge", { wallet: ph.address });
    assert.match(message, /does not send a transaction/);
    const { session } = await c.call("auth", { phantom: { wallet: ph.address, signature: ph.signMessage(message) } });
    assert.equal(session.linked, ph.address);
    assert.notEqual(session.wallet, ph.address);
    assert.deepEqual(session.fees, { potBps: 200, depositBps: 200, withdrawBps: 200 });
  });

  it("rejects a wrong signature, a reused challenge and handle-only login", async () => {
    const { hub } = newHub();
    const ph = fakePhantom(), other = fakePhantom();
    const c = client(hub);
    const { message } = await c.call("auth:challenge", { wallet: ph.address });
    await assert.rejects(c.call("auth", { phantom: { wallet: ph.address, signature: other.signMessage(message) } }), /didn't match/);
    await assert.rejects(c.call("auth", { phantom: { wallet: ph.address, signature: ph.signMessage(message) } }), /expired/, "challenge is single-use");
    await assert.rejects(c.call("auth", { handle: "someone" }), /Sign in with Phantom/);
    await assert.rejects(c.call("auth:challenge", { wallet: "notanaddress" }), /isn't a Solana/);
  });

  it("returns the same account and game wallet on the next sign-in", async () => {
    const { hub } = newHub();
    const ph = fakePhantom();
    const login = async () => {
      const c = client(hub);
      const { message } = await c.call("auth:challenge", { wallet: ph.address });
      return (await c.call("auth", { phantom: { wallet: ph.address, signature: ph.signMessage(message) } })).session;
    };
    const a = await login(), b = await login();
    assert.equal(a.userId, b.userId);
    assert.equal(a.wallet, b.wallet);
  });
});

describe("deposit and withdraw", () => {
  it("moves tokens between Phantom and the game wallet with a 2% fee each way", async () => {
    const { hub, ledger } = newHub();
    const ph = fakePhantom();
    const c = client(hub);
    const { message } = await c.call("auth:challenge", { wallet: ph.address });
    const { session } = await c.call("auth", { phantom: { wallet: ph.address, signature: ph.signMessage(message) } });
    assert.equal(await ledger.balance(ph.address), 1000_000_000n, "demo Phantom funds");
    assert.equal(await ledger.balance(session.wallet), 0n, "game wallet starts empty");

    await c.call("wallet:deposit", { amount: "500" });
    assert.equal(await ledger.balance(ph.address), 500_000_000n);
    assert.equal(await ledger.balance(session.wallet), 490_000_000n); // 500 - 2%
    assert.equal(ledger.houseBalance(), 10_000_000n);

    await c.call("wallet:withdraw", { amount: "100" });
    assert.equal(await ledger.balance(session.wallet), 390_000_000n);
    assert.equal(await ledger.balance(ph.address), 598_000_000n); // +100 - 2%
    assert.equal(ledger.houseBalance(), 12_000_000n);
    assert.ok(ledger.audit().ok);

    await assert.rejects(c.call("wallet:withdraw", { amount: "1000" }), /Not enough/);
    await assert.rejects(c.call("wallet:deposit", { amount: "-5" }), /amount/);
    await assert.rejects(c.call("wallet:deposit", { amount: "0" }), /above zero/);
    assert.ok(c.inbox.some(m => "event" in m && m.event === "wallet:linked"), "Phantom balance pushed to the browser");
  });

  it("lets a deposited player stake and play", async () => {
    const { hub, ledger } = newHub();
    const ph = fakePhantom();
    const c = client(hub);
    const { message } = await c.call("auth:challenge", { wallet: ph.address });
    const { session } = await c.call("auth", { phantom: { wallet: ph.address, signature: ph.signMessage(message) } });
    await assert.rejects(c.call("table:create", { seats: 2, stake: "25", bots: 1, clientSeed: "seed-abcdefgh" }), /enough for this stake/, "can't sit with an empty game wallet");
    await c.call("wallet:deposit", { amount: "100" });
    await c.call("table:create", { seats: 2, stake: "25", bots: 1, clientSeed: "seed-abcdefgh" });
    for (let i = 0; i < 100 && !c.last("table:state")?.round?.escrow; i++) await new Promise(r => setTimeout(r, 10));
    await c.call("round:deposit", { roundId: c.last("table:state").round.id });
    assert.equal(await ledger.balance(session.wallet), 98_000_000n - 25_000_000n);
    hub.shutdown();
  });
});

describe("quick play", () => {
  it("seats you at a waiting table with the same stake, otherwise opens one", async () => {
    const { hub, ledger } = newHub();
    const mk = async () => {
      const ph = fakePhantom(), c = client(hub);
      const { message } = await c.call("auth:challenge", { wallet: ph.address });
      await c.call("auth", { phantom: { wallet: ph.address, signature: ph.signMessage(message) } });
      await c.call("wallet:deposit", { amount: "500" });
      return c;
    };
    const a = await mk(), b = await mk(), c = await mk();
    const ra = await a.call("table:quick", { stake: "25", seats: 3, clientSeed: "seed-aaaaaaaa" });
    assert.equal(ra.joined, false, "nobody waiting, so a table opens");
    const lobby = b.last("lobby:update");
    assert.equal(lobby[0].players.length, 1);
    assert.equal(lobby[0].occupied, 1);
    const rb = await b.call("table:quick", { stake: "10", clientSeed: "seed-bbbbbbbb" });
    assert.equal(rb.joined, false, "different stake opens its own table");
    const rc = await c.call("table:quick", { stake: "25", clientSeed: "seed-cccccccc" });
    assert.deepEqual(rc, { tableId: ra.tableId, joined: true });
    assert.ok(ledger.audit().ok);
    hub.shutdown();
  });
});
