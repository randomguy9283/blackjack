import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync, sign } from "node:crypto";
import { base58, type ServerMsg } from "@pot21/shared";
import { PrivyVerifier } from "../src/privy.ts";
import { MockLedger } from "../src/ledger/mock.ts";
import { Hub, type Conn } from "../src/hub.ts";

const APP = "app_test123";
const { publicKey, privateKey } = generateKeyPairSync("ec", { namedCurve: "P-256" });
const PEM = publicKey.export({ type: "spki", format: "pem" }).toString();
const b64 = (o: unknown) => Buffer.from(JSON.stringify(o)).toString("base64url");

function token(claims: Record<string, unknown>, key = privateKey) {
  const head = b64({ alg: "ES256", typ: "JWT" });
  const body = b64({ iss: "privy.io", aud: APP, exp: Math.floor(Date.now() / 1000) + 3600, iat: Math.floor(Date.now() / 1000), ...claims });
  const sig = sign("sha256", Buffer.from(`${head}.${body}`), { key, dsaEncoding: "ieee-p1363" }).toString("base64url");
  return `${head}.${body}.${sig}`;
}

const WALLET = base58(Uint8Array.from({ length: 32 }, (_, i) => i + 1));
const users: Record<string, unknown> = {
  "did:privy:alex": { id: "did:privy:alex", linked_accounts: [
    { type: "twitter_oauth", username: "alexinthewoods", subject: "1" },
    { type: "wallet", chain_type: "solana", wallet_client_type: "privy", address: WALLET },
  ] },
  "did:privy:nowallet": { id: "did:privy:nowallet", linked_accounts: [
    { type: "twitter_oauth", username: "late_wallet", subject: "2" },
    { type: "wallet", chain_type: "solana", wallet_client_type: "phantom", address: base58(new Uint8Array(32).fill(9)) },
  ] },
  "did:privy:nox": { id: "did:privy:nox", linked_accounts: [{ type: "email", address: "a@b.c" }] },
};
let calls = 0;
const fakeFetch = (async (url: string, init?: RequestInit) => {
  calls++;
  const h = init?.headers as Record<string, string>;
  assert.equal(h["privy-app-id"], APP);
  assert.equal(h.authorization, "Basic " + Buffer.from(`${APP}:secret`).toString("base64"));
  const did = decodeURIComponent(url.split("/").pop()!);
  const u = users[did];
  return { ok: !!u, status: u ? 200 : 404, json: async () => u } as Response;
}) as unknown as typeof fetch;

const verifier = () => new PrivyVerifier({ appId: APP, appSecret: "secret", verificationKey: PEM, fetch: fakeFetch, apiBase: "https://api.test" });

describe("Privy token verification", () => {
  it("accepts a valid token and reads the X handle and Privy wallet", async () => {
    const id = await verifier().signIn(token({ sub: "did:privy:alex" }));
    assert.deepEqual(id, { did: "did:privy:alex", xUsername: "alexinthewoods", wallet: WALLET });
  });
  it("accepts the key pasted on one line", () => {
    const oneLine = PEM.replace(/\n/g, "");
    const v = new PrivyVerifier({ appId: APP, appSecret: "secret", verificationKey: oneLine, fetch: fakeFetch });
    assert.equal(v.verifyAccessToken(token({ sub: "did:privy:alex" })), "did:privy:alex");
  });
  it("rejects bad tokens", () => {
    const v = verifier();
    const other = generateKeyPairSync("ec", { namedCurve: "P-256" }).privateKey;
    assert.throws(() => v.verifyAccessToken(token({ sub: "did:privy:alex" }, other)), /isn't valid/);
    assert.throws(() => v.verifyAccessToken(token({ sub: "did:privy:alex", aud: "someone_else" })), /different app/);
    assert.throws(() => v.verifyAccessToken(token({ sub: "did:privy:alex", iss: "evil" })), /wasn't issued by Privy/);
    assert.throws(() => v.verifyAccessToken(token({ sub: "did:privy:alex", exp: Math.floor(Date.now() / 1000) - 600 })), /expired/);
    assert.throws(() => v.verifyAccessToken("not.a.token"), /malformed/);
    const t = token({ sub: "did:privy:alex" }).split(".");
    const forged = [t[0], b64({ iss: "privy.io", aud: APP, sub: "did:privy:victim", exp: 9e9 }), t[2]].join(".");
    assert.throws(() => v.verifyAccessToken(forged), /isn't valid/, "changing the claims breaks the signature");
  });
  it("explains missing X or a wallet still being created", async () => {
    await assert.rejects(verifier().signIn(token({ sub: "did:privy:nox" })), /no X account/);
    await assert.rejects(verifier().signIn(token({ sub: "did:privy:nowallet" })), /still being created/, "an external wallet isn't used as the game wallet");
  });
  it("caches the user lookup", async () => {
    const v = verifier();
    const before = calls;
    await v.signIn(token({ sub: "did:privy:alex" }));
    await v.signIn(token({ sub: "did:privy:alex" }));
    assert.equal(calls - before, 1);
  });
});

function client(hub: Hub) {
  const inbox: ServerMsg[] = [];
  const conn: Conn = { userId: null, send: d => inbox.push(JSON.parse(d)) };
  hub.connect(conn);
  let n = 0;
  const call = async (type: string, payload: unknown = {}) => {
    const id = ++n;
    await hub.handle(conn, JSON.stringify({ id, type, payload }));
    const reply = inbox.find(m => "id" in m && m.id === id) as any;
    if (!reply.ok) throw new Error(reply.error);
    return reply.result;
  };
  return { call, inbox };
}

function fakePhantom() {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const raw = Buffer.from(publicKey.export({ format: "jwk" }).x!, "base64url");
  return { address: base58(raw), sign: (m: string) => base58(sign(null, Buffer.from(m), privateKey)) };
}

describe("signing in with X through the hub", () => {
  const make = (privy: PrivyVerifier | null = verifier()) => {
    const ledger = new MockLedger();
    const hub = new Hub(ledger, { allowBots: true, allowDevLogin: false, privy, starterBalance: 1000_000_000n, minStake: 1_000_000n, maxStake: 10_000_000_000n, demoPhantomBalance: 500_000_000n });
    return { ledger, hub };
  };

  it("creates the account with the X handle and the Privy wallet as the game wallet", async () => {
    const { hub, ledger } = make();
    const c = client(hub);
    const { session } = await c.call("auth", { privyToken: token({ sub: "did:privy:alex" }) });
    assert.equal(session.handle, "@alexinthewoods");
    assert.equal(session.wallet, WALLET);
    assert.equal(session.login, "privy");
    assert.equal(session.linked, null);
    assert.equal(await ledger.balance(WALLET), 1000_000_000n, "demo starter tokens");
    const again = await client(hub).call("auth", { privyToken: token({ sub: "did:privy:alex" }) });
    assert.equal(again.session.userId, session.userId, "same Privy user, same account");
    assert.equal(await ledger.balance(WALLET), 1000_000_000n, "starter tokens only once");
  });

  it("refuses X sign-in when Privy isn't configured, and refuses dev login when disabled", async () => {
    const { hub } = make(null);
    const c = client(hub);
    await assert.rejects(c.call("auth", { privyToken: token({ sub: "did:privy:alex" }) }), /isn't set up/);
    await assert.rejects(c.call("auth", { handle: "anyone" }), /Sign in with Phantom/);
  });

  it("links Phantom for deposits and withdrawals", async () => {
    const { hub, ledger } = make();
    const c = client(hub);
    await c.call("auth", { privyToken: token({ sub: "did:privy:alex" }) });
    await assert.rejects(c.call("wallet:deposit", { amount: "10" }), /Phantom/);
    const ph = fakePhantom();
    const { message } = await c.call("auth:challenge", { wallet: ph.address });
    const { session } = await c.call("wallet:link", { wallet: ph.address, signature: ph.sign(message) });
    assert.equal(session.linked, ph.address);
    await c.call("wallet:deposit", { amount: "100" });
    assert.equal(await ledger.balance(WALLET), 1098_000_000n);
    await c.call("wallet:withdraw", { amount: "50" });
    assert.equal(await ledger.balance(ph.address), 449_000_000n); // 500 - 100 + 49
    assert.ok(ledger.audit().ok);

    // The same Phantom can't be linked to a second account.
    users["did:privy:bob"] = { id: "did:privy:bob", linked_accounts: [{ type: "twitter_oauth", username: "bob" }, { type: "wallet", chain_type: "solana", wallet_client_type: "privy", address: base58(new Uint8Array(32).fill(7)) }] };
    const b = client(hub);
    await b.call("auth", { privyToken: token({ sub: "did:privy:bob" }) });
    const ch2 = await b.call("auth:challenge", { wallet: ph.address });
    await assert.rejects(b.call("wallet:link", { wallet: ph.address, signature: ph.sign(ch2.message) }), /already linked/);
  });
});

describe("saved accounts", () => {
  it("keeps accounts, linked Phantom and sign-ins across a restart, and stores no usable tokens", async () => {
    const { mkdtempSync, readFileSync } = await import("node:fs");
    const { join } = await import("node:path");
    const { tmpdir } = await import("node:os");
    const file = join(mkdtempSync(join(tmpdir(), "pot21-")), "accounts.json");
    const opts = { allowBots: true, allowDevLogin: false, privy: verifier(), accountsFile: file, starterBalance: 1000_000_000n, minStake: 1_000_000n, maxStake: 10_000_000_000n, demoPhantomBalance: 500_000_000n };

    const hub1 = new Hub(new MockLedger(), opts);
    const c = client(hub1);
    const { session, sessionToken } = await c.call("auth", { privyToken: token({ sub: "did:privy:alex" }) });
    const ph = fakePhantom();
    const { message } = await c.call("auth:challenge", { wallet: ph.address });
    await c.call("wallet:link", { wallet: ph.address, signature: ph.sign(message) });
    await c.call("table:create", { seats: 2, stake: "25", bots: 1, clientSeed: "seed-abcdefgh" });
    hub1.shutdown();

    const saved = readFileSync(file, "utf8");
    assert.ok(!saved.includes(sessionToken), "the sign-in token itself is never written to disk");
    assert.ok(!saved.includes("_bot"), "practice bots aren't saved");

    const hub2 = new Hub(new MockLedger(), opts);
    const r = await client(hub2).call("auth", { sessionToken });
    assert.equal(r.session.userId, session.userId);
    assert.equal(r.session.handle, "@alexinthewoods");
    assert.equal(r.session.linked, ph.address);
    hub2.shutdown();
  });

  it("expires sign-ins after 30 days without a visit", async () => {
    const { Auth, SESSION_MS } = await import("../src/auth.ts");
    let now = Date.now();
    const auth = new Auth({ now: () => now });
    const { token: t } = auth.loginDev("alex");
    now += SESSION_MS - 1000;
    assert.ok(auth.resume(t), "still signed in just before 30 days");
    now += SESSION_MS - 1000;
    assert.ok(auth.resume(t), "each visit extends it");
    now += SESSION_MS + 1;
    assert.equal(auth.resume(t), null, "expired after 30 days away");
  });
});

describe("signing out", () => {
  it("ends the saved session on the server", async () => {
    const hub = new Hub(new MockLedger(), { allowBots: true, allowDevLogin: true, starterBalance: 1n, minStake: 1n, maxStake: 10n });
    const c = client(hub);
    const { sessionToken } = await c.call("auth", { handle: "alex" });
    await c.call("auth:logout", { sessionToken });
    await assert.rejects(client(hub).call("auth", { sessionToken }), /expired/);
  });
});
