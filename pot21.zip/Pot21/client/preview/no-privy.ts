// The preview has no Privy app id, so the real Privy bridge is never loaded.
export function mountPrivy(): never { throw new Error("Privy isn't available in the preview."); }
