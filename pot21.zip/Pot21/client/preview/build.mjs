// Builds a single self-contained HTML page: client + in-page demo server.
//   node preview/build.mjs  ->  preview/dist/pot21-preview.html
import { build } from "esbuild";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const here = fileURLToPath(new URL(".", import.meta.url));
const shim = here + "crypto-shim.ts";
const sigShim = here + "sig-shim.ts";
const noPrivy = here + "no-privy.ts";
const noFs = here + "no-fs.ts";
const out = await build({
  entryPoints: [here + "entry.ts"], bundle: true, format: "iife", write: false, minify: true, target: "es2022",
  platform: "browser", external: ["@solana/web3.js", "@solana/spl-token", "@pot21/shared/escrow"],
  plugins: [{ name: "browser-shims", setup(b) {
    b.onResolve({ filter: /^node:crypto$/ }, () => ({ path: shim }));
    b.onResolve({ filter: /react-bridge\.ts$/ }, () => ({ path: noPrivy }));
    b.onResolve({ filter: /^node:(fs|path)$/ }, () => ({ path: noFs }));
    b.onResolve({ filter: /\/sig\.ts$/ }, a => a.importer.includes("/server/") ? { path: sigShim } : undefined);
  } }],
  logLevel: "warning",
});
const js = out.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
const css = await readFile(here + "../src/styles.css", "utf8");
const html = `<title>Pot 21</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap">
<style>${css}</style>
<div id="app"></div>
<div id="drawerRoot"></div>
<div id="toasts" aria-live="polite"></div>
<script>${js}</script>`;
await mkdir(here + "dist", { recursive: true });
await writeFile(here + "dist/pot21-preview.html", html);
console.log(`preview/dist/pot21-preview.html (${(html.length / 1024).toFixed(0)} KB)`);
