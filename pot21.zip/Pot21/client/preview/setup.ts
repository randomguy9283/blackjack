// Runs the real server (Hub + Table + MockLedger) inside the page, so the
// game can be previewed without a backend. Opponents are bots.
import { Hub, type Conn } from "../../server/src/hub.ts";
import { MockLedger } from "../../server/src/ledger/mock.ts";

const ledger = new MockLedger();
const hub = new Hub(ledger, { allowBots: true, allowDevLogin: true, starterBalance: 1000_000_000n, minStake: 1_000_000n, maxStake: 10_000_000_000n, demoPhantomBalance: 1000_000_000n });

class LocalNet {
  private seq = 0;
  private pending = new Map<number, { resolve: (v: any) => void; reject: (e: Error) => void }>();
  private listeners = new Map<string, Set<(d: any) => void>>();
  onOpen: () => void = () => {};
  onStatus: (s: string) => void = () => {};
  private conn: Conn = {
    userId: null,
    send: (raw: string) => {
      const msg = JSON.parse(raw);
      if ("event" in msg) { for (const fn of this.listeners.get(msg.event) ?? []) fn(msg.data); return; }
      const p = this.pending.get(msg.id);
      if (!p) return;
      this.pending.delete(msg.id);
      msg.ok ? p.resolve(msg.result) : p.reject(new Error(msg.error));
    },
  };
  constructor() { hub.connect(this.conn); setTimeout(() => { this.onStatus("open"); this.onOpen(); }, 0); }
  request(type: string, payload: unknown) {
    return new Promise((resolve, reject) => {
      const id = ++this.seq;
      this.pending.set(id, { resolve, reject });
      void hub.handle(this.conn, JSON.stringify({ id, type, payload }));
    });
  }
  on(event: string, fn: (d: any) => void) {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event)!.add(fn);
  }
}

(globalThis as any).__pot21 = { net: new LocalNet(), info: { mode: "mock", token: ledger.token, bots: true, devLogin: true } };
