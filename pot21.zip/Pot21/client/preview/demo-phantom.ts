// A stand-in Phantom wallet for the preview (and browser tests), used only
// when the real extension isn't present. It holds an Ed25519 key in memory
// and signs messages the same way Phantom does.
import { base58 } from "@pot21/shared";

if (!(globalThis as any).phantom?.solana) {
  let keys: CryptoKeyPair | null = null;
  let pub: { toString(): string } | null = null;
  const provider = {
    isPhantom: true,
    isDemo: true,
    publicKey: null as { toString(): string } | null,
    async connect() {
      if (!keys) {
        keys = (await crypto.subtle.generateKey({ name: "Ed25519" }, false, ["sign", "verify"])) as CryptoKeyPair;
        const raw = new Uint8Array(await crypto.subtle.exportKey("raw", keys.publicKey));
        const addr = base58(raw);
        pub = { toString: () => addr };
      }
      provider.publicKey = pub;
      return { publicKey: pub! };
    },
    async disconnect() { provider.publicKey = null; },
    async signMessage(message: Uint8Array) {
      if (!keys) throw new Error("not connected");
      return { signature: new Uint8Array(await crypto.subtle.sign({ name: "Ed25519" }, keys.privateKey, message)) };
    },
  };
  (globalThis as any).phantom = { solana: provider };
}
