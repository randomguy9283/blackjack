import "./demo-phantom.ts";
import "./setup.ts";
import "../src/main.ts";
