// The preview keeps accounts in memory, so file saving is never called.
const no = () => { throw new Error("Not available in the preview."); };
export const readFileSync = no, writeFileSync = no, renameSync = no, mkdirSync = no;
export const dirname = (p: string) => p;
