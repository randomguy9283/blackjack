// Browser stand-in for the bits of node:crypto the server uses.
class Bytes extends Uint8Array {
  toString(enc?: string): string {
    if (enc === "hex") return Array.from(this, b => b.toString(16).padStart(2, "0")).join("");
    if (enc === "base64url") return btoa(String.fromCharCode(...this)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    return super.toString();
  }
}
export function randomBytes(n: number): Bytes { return crypto.getRandomValues(new Bytes(n)); }

import { sha256 } from "../../shared/src/sha256.ts";
/** Just enough of createHash for hashing session tokens in the preview. */
export function createHash(_alg: "sha256") {
  let data = "";
  const h = {
    update(s: string) { data += s; return h; },
    digest(enc: "base64url") {
      const b = sha256(new TextEncoder().encode(data));
      return enc === "base64url" ? btoa(String.fromCharCode(...b)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") : "";
    },
  };
  return h;
}
