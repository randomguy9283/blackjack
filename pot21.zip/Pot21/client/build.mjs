// Bundles the client into dist/. `node build.mjs --watch` rebuilds on change.
import { build, context } from "esbuild";
import { copyFile, mkdir } from "node:fs/promises";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const has = m => { try { require.resolve(m); return true; } catch { return false; } };
// Solana libraries are only loaded in solana mode. If they aren't installed,
// leave them out so the demo still builds.
const external = ["@solana/web3.js", "@solana/spl-token"].filter(m => !has(m));
if (external.length) {
  console.log(`[client] ${external.join(", ")} not installed: solana mode disabled in this build`);
  external.push("@pot21/shared/escrow");
}
// Privy (React SDK) is only loaded when the server has a Privy app id.
const privyDeps = ["react", "react-dom", "react-dom/client", "@privy-io/react-auth", "@privy-io/react-auth/solana"];
if (!has("@privy-io/react-auth")) {
  console.log("[client] @privy-io/react-auth not installed: X sign-in falls back to demo mode in this build");
  external.push(...privyDeps);
}

await mkdir("dist", { recursive: true });
await Promise.all([copyFile("index.html", "dist/index.html"), copyFile("src/styles.css", "dist/styles.css")]);
const opts = {
  entryPoints: ["src/main.ts"], bundle: true, format: "esm", splitting: true, outdir: "dist",
  target: "es2022", sourcemap: true, minify: !process.argv.includes("--watch"), external, logLevel: "info",
  define: { "process.env.NODE_ENV": '"production"' },
};
if (process.argv.includes("--watch")) (await context(opts)).watch();
else await build(opts);
