/**
 * Phantom browser extension (window.phantom.solana).
 * Docs: https://docs.phantom.com/solana/integrating-phantom
 */
import { base58 } from "@pot21/shared";

export interface PhantomProvider {
  isPhantom?: boolean;
  publicKey: { toString(): string } | null;
  connect(opts?: { onlyIfTrusted?: boolean }): Promise<{ publicKey: { toString(): string } }>;
  disconnect(): Promise<void>;
  signMessage(message: Uint8Array, display?: "utf8" | "hex"): Promise<{ signature: Uint8Array }>;
  /** Only used in solana mode: sign and send a web3.js Transaction. */
  signAndSendTransaction?(tx: unknown): Promise<{ signature: string }>;
  on?(event: "accountChanged" | "disconnect", fn: (arg: unknown) => void): void;
}

export const PHANTOM_DOWNLOAD = "https://phantom.com/download";

export function getPhantom(): PhantomProvider | null {
  const w = globalThis as { phantom?: { solana?: PhantomProvider }; solana?: PhantomProvider };
  const p = w.phantom?.solana ?? w.solana;
  return p?.isPhantom ? p : null;
}

/** Ask Phantom to connect, then sign the server's sign-in message. */
export async function signInWithPhantom(getMessage: (wallet: string) => Promise<string>) {
  const provider = getPhantom();
  if (!provider) throw new Error("Phantom isn't installed in this browser.");
  let wallet: string;
  try { wallet = (await provider.connect()).publicKey.toString(); }
  catch { throw new Error("Phantom connection was cancelled."); }
  const message = await getMessage(wallet);
  let signature: Uint8Array;
  try { ({ signature } = await provider.signMessage(new TextEncoder().encode(message), "utf8")); }
  catch { throw new Error("You declined the sign-in request in Phantom."); }
  return { wallet, signature: base58(signature) };
}
