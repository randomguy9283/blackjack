import type { Events, EventType, Requests, RequestType, ServerMsg } from "@pot21/shared";

type Listener<E extends EventType> = (data: Events[E]) => void;

/** Request/response + push events over one WebSocket, with auto-reconnect. */
export class Net {
  private ws: WebSocket | null = null;
  private seq = 0;
  private pending = new Map<number, { resolve: (v: any) => void; reject: (e: Error) => void }>();
  private listeners = new Map<EventType, Set<Listener<any>>>();
  private backoff = 500;
  onOpen: () => void = () => {};
  onStatus: (s: "connecting" | "open" | "closed") => void = () => {};

  constructor(private url: string) { this.open(); }

  private open() {
    this.onStatus("connecting");
    const ws = new WebSocket(this.url);
    this.ws = ws;
    ws.onopen = () => { this.backoff = 500; this.onStatus("open"); this.onOpen(); };
    ws.onmessage = ev => {
      let msg: ServerMsg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if ("event" in msg) { for (const fn of this.listeners.get(msg.event) ?? []) fn(msg.data); return; }
      const p = this.pending.get(msg.id);
      if (!p) return;
      this.pending.delete(msg.id);
      if (msg.ok) p.resolve(msg.result); else p.reject(new Error(msg.error));
    };
    ws.onclose = () => {
      this.onStatus("closed");
      for (const p of this.pending.values()) p.reject(new Error("Connection lost. Reconnecting…"));
      this.pending.clear();
      setTimeout(() => this.open(), this.backoff);
      this.backoff = Math.min(this.backoff * 2, 8000);
    };
  }

  request<K extends RequestType>(type: K, payload: Requests[K]["req"]): Promise<Requests[K]["res"]> {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return reject(new Error("Not connected yet. Try again in a moment."));
      const id = ++this.seq;
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, type, payload }));
    });
  }

  on<E extends EventType>(event: E, fn: Listener<E>) {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event)!.add(fn);
  }
}
