/**
 * Hosts the Privy React SDK for a site that isn't otherwise built with React.
 * A hidden React root renders <PrivyProvider> and a tiny component that
 * copies Privy's state out to the vanilla app through the PrivyBridge API.
 *
 * Needs: npm i react react-dom @privy-io/react-auth @solana/kit
 * Docs:  https://docs.privy.io/basics/react/setup
 *        https://docs.privy.io/authentication/user-authentication/login-methods/oauth
 *        https://docs.privy.io/wallets/using-wallets/solana/sign-a-transaction
 */
import { createElement as h, useEffect } from "react";
import { createRoot } from "react-dom/client";
import { PrivyProvider, usePrivy, useLoginWithOAuth, getAccessToken } from "@privy-io/react-auth";
import { useWallets, useSignTransaction } from "@privy-io/react-auth/solana";
import type { PrivyBridge, PrivyState } from "./types.ts";

// The Privy SDK's own types are rich; this file only touches a few fields, so
// keep the boundary loose rather than pinning to one SDK minor version.
/* eslint-disable @typescript-eslint/no-explicit-any */

export function mountPrivy(appId: string): PrivyBridge {
  let state: PrivyState = { ready: false, authenticated: false, handle: null, wallet: null, error: null };
  const listeners = new Set<(s: PrivyState) => void>();
  const set = (patch: Partial<PrivyState>) => {
    state = { ...state, ...patch };
    for (const fn of listeners) fn(state);
  };
  let api: { initOAuth: (o: { provider: "twitter" }) => Promise<void>; logout: () => Promise<void>; signTransaction: any; wallets: any[] } | null = null;
  let readyResolve!: () => void;
  const whenReady = new Promise<void>(r => (readyResolve = r));

  function Sync() {
    const { ready, authenticated, user, logout } = usePrivy() as any;
    const { initOAuth } = useLoginWithOAuth({
      onError: (e: unknown) => set({ error: e instanceof Error ? e.message : "X sign-in didn't complete. Try again." }),
    } as any) as any;
    const { wallets } = useWallets() as any;
    const { signTransaction } = useSignTransaction() as any;
    useEffect(() => {
      api = { initOAuth, logout, signTransaction, wallets: wallets ?? [] };
      const sol = (user?.linkedAccounts ?? []).find((a: any) => a.type === "wallet" && a.chainType === "solana" && a.walletClientType === "privy");
      set({ ready: !!ready, authenticated: !!authenticated, handle: user?.twitter?.username ?? null, wallet: sol?.address ?? null });
      if (ready) readyResolve();
    }, [ready, authenticated, user, wallets, initOAuth, logout, signTransaction]);
    return null;
  }

  const host = document.createElement("div");
  host.id = "privy-root";
  document.body.appendChild(host);
  createRoot(host).render(
    h(PrivyProvider as any, {
      appId,
      config: {
        loginMethods: ["twitter"],
        appearance: { theme: "dark", accentColor: "#F2B544", walletChainType: "solana-only" },
        // Every new player gets a Solana wallet the moment they sign in.
        embeddedWallets: { solana: { createOnLogin: "users-without-wallets" } },
      },
    }, h(Sync)),
  );

  return {
    kind: "privy",
    state: () => state,
    subscribe: fn => { listeners.add(fn); },
    async login() {
      set({ error: null });
      await whenReady;
      await api!.initOAuth({ provider: "twitter" });
    },
    async logout() { await whenReady; await api?.logout(); },
    async getAccessToken() { return (await getAccessToken()) ?? null; },
    async signTransaction(tx) {
      await whenReady;
      const wallet = api!.wallets.find((w: any) => w.address === state.wallet) ?? api!.wallets[0];
      if (!wallet) throw new Error("Your Privy wallet isn't ready yet. Try again in a moment.");
      const { signedTransaction } = await api!.signTransaction({ transaction: tx, wallet });
      return signedTransaction as Uint8Array;
    },
  };
}
