/**
 * Stand-in for Privy when no Privy app id is configured (local demo mode and
 * the preview). "Sign in with X" asks for a handle and uses the server's
 * developer login. Clearly labelled in the UI; never used with real tokens.
 */
import type { PrivyBridge, PrivyState } from "./types.ts";

export function demoBridge(promptHandle: () => Promise<string | null>): PrivyBridge {
  let state: PrivyState = { ready: true, authenticated: false, handle: null, wallet: null, error: null };
  const listeners = new Set<(s: PrivyState) => void>();
  const set = (p: Partial<PrivyState>) => { state = { ...state, ...p }; for (const fn of listeners) fn(state); };
  return {
    kind: "demo",
    state: () => state,
    subscribe: fn => { listeners.add(fn); },
    async login() {
      const handle = await promptHandle();
      if (handle) set({ authenticated: true, handle: handle.replace(/^@/, "") });
    },
    async logout() { set({ authenticated: false, handle: null }); },
    async getAccessToken() { return null; },
    async signTransaction() { throw new Error("Demo sign-in can't sign real transactions."); },
  };
}
