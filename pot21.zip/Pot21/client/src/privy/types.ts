/**
 * What the rest of the site needs from Privy. Two implementations:
 *   react-bridge.ts: the real Privy React SDK, mounted in a hidden React root
 *   demo-bridge.ts:  a stand-in for local demo mode and the preview, when no
 *                    Privy app id is configured
 */
export interface PrivyState {
  ready: boolean;
  authenticated: boolean;
  /** X username, without @ */
  handle: string | null;
  /** Solana wallet Privy created for this user */
  wallet: string | null;
  error: string | null;
}

export interface PrivyBridge {
  kind: "privy" | "demo";
  state(): PrivyState;
  subscribe(fn: (s: PrivyState) => void): void;
  /** Start "Sign in with X". The real one redirects to X and back. */
  login(): Promise<void>;
  logout(): Promise<void>;
  getAccessToken(): Promise<string | null>;
  /** Sign a serialized Solana transaction with the Privy wallet. */
  signTransaction(tx: Uint8Array): Promise<Uint8Array>;
}
