/**
 * Browser-side signing for solana mode.
 *
 * The game wallet is the Solana wallet Privy creates when a player signs in
 * with X; Privy signs its transactions. Players who sign in with Phantom
 * instead get a game wallet whose key is kept in this browser (with a
 * backup-key export). Phantom itself only funds deposits and receives
 * withdrawals.
 */
import type { SessionInfo } from "@pot21/shared";

const KEY = "pot21.burner";

/* ---------------- who signs for the game wallet ---------------- */

type TxSigner = (serialized: Uint8Array) => Promise<Uint8Array>;
let privySigner: TxSigner | null = null;
/** Called once Privy is mounted: the game wallet is then Privy's embedded wallet. */
export function setPrivySigner(fn: TxSigner) { privySigner = fn; }

/**
 * Sign a transaction from the game wallet and send it. With Privy signed in,
 * Privy signs (and may show its own confirmation). Otherwise the browser key does.
 */
async function sendFromGameWallet(session: SessionInfo, tx: import("@solana/web3.js").Transaction): Promise<string> {
  const web3 = await import("@solana/web3.js");
  const conn = new web3.Connection(session.chain!.rpcUrl, "confirmed");
  const payer = new web3.PublicKey(session.wallet);
  tx.feePayer = payer;
  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
  tx.recentBlockhash = blockhash;
  let signature: string;
  if (session.login === "privy") {
    if (!privySigner) throw new Error("Privy isn't ready yet. Try again in a moment.");
    const signed = await privySigner(tx.serialize({ requireAllSignatures: false, verifySignatures: false }));
    signature = await conn.sendRawTransaction(signed);
  } else {
    const signer = loadBurner(web3.Keypair);
    if (!signer.publicKey.equals(payer)) throw new Error("This browser doesn't hold your game wallet key. Restore its backup first.");
    tx.sign(signer);
    signature = await conn.sendRawTransaction(tx.serialize());
  }
  await conn.confirmTransaction({ signature, blockhash, lastValidBlockHeight }, "confirmed");
  return signature;
}

export async function burnerAddress(): Promise<string> {
  const { Keypair } = await import("@solana/web3.js");
  return loadBurner(Keypair).publicKey.toBase58();
}

function loadBurner(Keypair: typeof import("@solana/web3.js").Keypair) {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return Keypair.fromSecretKey(Uint8Array.from(JSON.parse(raw)));
  } catch { /* fall through and make a new one */ }
  const kp = Keypair.generate();
  try { localStorage.setItem(KEY, JSON.stringify(Array.from(kp.secretKey))); } catch { /* private window: lives for this tab only */ }
  return kp;
}

/** Sign and send the escrow `join` for this seat. Returns the signature. */
export async function stakeOnChain(session: SessionInfo, roundId: string, seat: number): Promise<string> {
  if (!session.chain || !session.token.mint) throw new Error("This server isn't in solana mode.");
  const web3 = await import("@solana/web3.js");
  const { getAssociatedTokenAddressSync } = await import("@solana/spl-token");
  const { ixJoin } = await import("@pot21/shared/escrow");
  const player = new web3.PublicKey(session.wallet);
  const mint = new web3.PublicKey(session.token.mint);
  const playerToken = getAssociatedTokenAddressSync(mint, player);
  const ix = ixJoin({ programId: new web3.PublicKey(session.chain.programId), mint, roundId: BigInt(roundId), player, playerToken, seat });
  return sendFromGameWallet(session, new web3.Transaction().add(ix));
}

/* ---------------- deposits & withdrawals (solana mode) ---------------- */

/** SOL kept in the game wallet for transaction fees. */
const GAS_TARGET_LAMPORTS = 10_000_000; // 0.01 SOL
const GAS_MIN_LAMPORTS = 3_000_000;

async function feeSplit(amount: bigint, bps: number) {
  const { transferFee } = await import("@pot21/shared");
  return transferFee(amount, bps);
}

/**
 * Phantom -> game wallet. One transaction, signed in Phantom:
 *   net to the game wallet, fee to the house, and a little SOL for gas if the
 *   game wallet is running low.
 */
export async function depositFromPhantom(session: SessionInfo, amount: bigint, provider: import("./phantom.ts").PhantomProvider): Promise<string> {
  if (!session.chain || !session.token.mint || !session.linked) throw new Error("This server isn't in solana mode.");
  if (!provider.signAndSendTransaction) throw new Error("This Phantom version can't send transactions.");
  const web3 = await import("@solana/web3.js");
  const spl = await import("@solana/spl-token");
  const conn = new web3.Connection(session.chain.rpcUrl, "confirmed");
  const mint = new web3.PublicKey(session.token.mint);
  const from = new web3.PublicKey(session.linked);
  const game = new web3.PublicKey(session.wallet);
  const house = new web3.PublicKey(session.chain.house);
  const { fee, net } = await feeSplit(amount, session.fees.depositBps);
  const fromAta = spl.getAssociatedTokenAddressSync(mint, from);
  const gameAta = spl.getAssociatedTokenAddressSync(mint, game);
  const houseAta = spl.getAssociatedTokenAddressSync(mint, house, true);
  const tx = new web3.Transaction().add(
    spl.createAssociatedTokenAccountIdempotentInstruction(from, gameAta, game, mint),
    spl.createTransferCheckedInstruction(fromAta, mint, gameAta, from, net, session.token.decimals),
  );
  if (fee > 0n) tx.add(
    spl.createAssociatedTokenAccountIdempotentInstruction(from, houseAta, house, mint),
    spl.createTransferCheckedInstruction(fromAta, mint, houseAta, from, fee, session.token.decimals),
  );
  const gas = await conn.getBalance(game);
  if (gas < GAS_MIN_LAMPORTS) tx.add(web3.SystemProgram.transfer({ fromPubkey: from, toPubkey: game, lamports: GAS_TARGET_LAMPORTS - gas }));
  tx.feePayer = from;
  tx.recentBlockhash = (await conn.getLatestBlockhash()).blockhash;
  const { signature } = await provider.signAndSendTransaction(tx);
  await conn.confirmTransaction(signature, "confirmed");
  return signature;
}

/** Game wallet -> Phantom. Signed by the game wallet held in this browser. */
export async function withdrawToPhantom(session: SessionInfo, amount: bigint): Promise<string> {
  if (!session.chain || !session.token.mint || !session.linked) throw new Error("This server isn't in solana mode.");
  const web3 = await import("@solana/web3.js");
  const spl = await import("@solana/spl-token");
  const game = new web3.PublicKey(session.wallet);
  const mint = new web3.PublicKey(session.token.mint);
  const to = new web3.PublicKey(session.linked);
  const house = new web3.PublicKey(session.chain.house);
  const { fee, net } = await feeSplit(amount, session.fees.withdrawBps);
  const gameAta = spl.getAssociatedTokenAddressSync(mint, game);
  const toAta = spl.getAssociatedTokenAddressSync(mint, to);
  const houseAta = spl.getAssociatedTokenAddressSync(mint, house, true);
  const tx = new web3.Transaction().add(
    spl.createAssociatedTokenAccountIdempotentInstruction(game, toAta, to, mint),
    spl.createTransferCheckedInstruction(gameAta, mint, toAta, game, net, session.token.decimals),
  );
  if (fee > 0n) tx.add(spl.createTransferCheckedInstruction(gameAta, mint, houseAta, game, fee, session.token.decimals));
  return sendFromGameWallet(session, tx);
}

/** Token balance of any wallet, read from chain. */
export async function tokenBalance(session: SessionInfo, owner: string): Promise<bigint> {
  if (!session.chain || !session.token.mint) return 0n;
  const web3 = await import("@solana/web3.js");
  const spl = await import("@solana/spl-token");
  const conn = new web3.Connection(session.chain.rpcUrl, "confirmed");
  try {
    const ata = spl.getAssociatedTokenAddressSync(new web3.PublicKey(session.token.mint), new web3.PublicKey(owner));
    return BigInt((await conn.getTokenAccountBalance(ata)).value.amount);
  } catch { return 0n; }
}

/** Backup: the game wallet's secret key as base58, for restoring in another browser. */
export async function exportBurner(): Promise<string> {
  const web3 = await import("@solana/web3.js");
  const { base58 } = await import("@pot21/shared");
  return base58(loadBurner(web3.Keypair).secretKey);
}

export async function importBurner(secretB58: string): Promise<string> {
  const web3 = await import("@solana/web3.js");
  const { base58Decode } = await import("@pot21/shared");
  const kp = web3.Keypair.fromSecretKey(base58Decode(secretB58.trim()));
  localStorage.setItem(KEY, JSON.stringify(Array.from(kp.secretKey)));
  return kp.publicKey.toBase58();
}
