import {
  formatUnits, parseUnits, potPreview, transferFee, verifyRound, handTotal, TURN_MS, FUNDING_MS, MIN_SEATS, MAX_SEATS,
  type Card, type LedgerTx, type SessionInfo, type TableSummary, type TableView, type SeatView,
} from "@pot21/shared";
import { Net } from "./net.ts";
import { getPhantom, signInWithPhantom, PHANTOM_DOWNLOAD } from "./phantom.ts";
import type { PrivyBridge } from "./privy/types.ts";
import { demoBridge } from "./privy/demo-bridge.ts";

/* ================= state ================= */

interface Info { mode: "mock" | "solana"; token: SessionInfo["token"]; bots: boolean; devLogin?: boolean; privyAppId?: string | null }
type Sheet = null | "wallet" | "rules" | "fair";

const S = {
  info: null as Info | null,
  session: null as SessionInfo | null,
  view: null as TableView | null,
  lobby: [] as TableSummary[],
  balance: null as string | null,
  linkedBalance: null as string | null,
  txs: [] as LedgerTx[],
  create: { seats: 2, stake: "25", bots: 0 },
  verify: null as { roundId: string; text: string; ok: boolean } | null,
  screen: "" as "" | "login" | "lobby" | "table",
  sheet: null as Sheet,
  walletTab: "deposit" as "deposit" | "withdraw",
};

const store = {
  get: (k: string) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
  del: (k: string) => { try { localStorage.removeItem(k); } catch { /* private mode */ } },
};

function clientSeed() {
  let s = store.get("pot21.seed");
  if (!s) {
    s = Array.from(crypto.getRandomValues(new Uint8Array(12)), b => b.toString(16).padStart(2, "0")).join("");
    store.set("pot21.seed", s);
  }
  return s;
}

/* ================= helpers ================= */

const $ = <T extends HTMLElement = HTMLElement>(sel: string) => document.querySelector(sel) as T | null;
const esc = (s: string) => s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const short = (a: string) => a.length > 12 ? a.slice(0, 4) + "…" + a.slice(-4) : a;
const dec = () => S.session?.token.decimals ?? S.info?.token.decimals ?? 6;
const sym = () => S.session?.token.symbol ?? S.info?.token.symbol ?? "CHIP";
const fmt = (u: string | bigint) => formatUnits(u, dec());
/** Whole amounts without a trailing .00, for friendlier copy. */
const nice = (u: string | bigint) => fmt(u).replace(/\.00$/, "");
const range = (a: number, b: number) => Array.from({ length: Math.max(0, b - a + 1) }, (_, i) => a + i);
const plural = (n: number, one: string, many = one + "s") => `${n} ${n === 1 ? one : many}`;

const AVATAR_COLORS = ["#5B6CF0", "#E0705A", "#2FA37A", "#B061D6", "#D4973A", "#3C9BD6", "#C4507F", "#6E8F3A"];
function avatar(handle: string) {
  let h = 0;
  for (const ch of handle) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const letter = handle.replace(/^@/, "").slice(0, 1).toUpperCase() || "?";
  return `<span class="avatar" style="background:${AVATAR_COLORS[h % AVATAR_COLORS.length]}" aria-hidden="true">${esc(letter)}</span>`;
}

function toast(text: string, kind: "info" | "error" = "info") {
  const el = document.createElement("div");
  el.className = `toast ${kind === "error" ? "error" : ""}`;
  el.textContent = text;
  $("#toasts")!.appendChild(el);
  setTimeout(() => el.remove(), kind === "error" ? 6000 : 2800);
}

async function act<T>(fn: () => Promise<T>, btn?: HTMLButtonElement | null): Promise<T | undefined> {
  if (btn) btn.disabled = true;
  try { return await fn(); }
  catch (e) { toast((e as Error).message, "error"); return undefined; }
  finally { if (btn && btn.isConnected) btn.disabled = false; }
}

/* ================= network ================= */

// The standalone preview injects an in-page server here (see preview/).
const injected = (globalThis as { __pot21?: { net: Net; info: Info } }).__pot21;
const net: Net = injected?.net ?? new Net(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`);
let wasClosed = false;
net.onStatus = s => {
  if (s === "closed" && !wasClosed) { wasClosed = true; toast("Connection lost. Reconnecting…", "error"); }
  if (s === "open" && wasClosed) { wasClosed = false; toast("Reconnected."); }
};
net.onOpen = async () => {
  const token = store.get("pot21.session");
  if (token) {
    try { await login({ sessionToken: token }); return; } catch { store.del("pot21.session"); }
  }
  S.session = null;
  route();
};
net.on("table:state", v => {
  const prev = S.view?.round;
  S.view = v;
  if (v?.round && S.verify && S.verify.roundId !== v.round.id) S.verify = null;
  const myTurnNow = v?.round?.phase === "playing" && v.round.turnSeat === v.yourSeat;
  const myTurnBefore = prev?.phase === "playing" && prev.turnSeat === S.view?.yourSeat && prev.id === v?.round?.id;
  route();
  if (myTurnNow && !myTurnBefore) {
    try { navigator.vibrate?.(30); } catch { /* unsupported */ }
    // Make sure your own cards are visible above the action bar.
    $(".seat.you")?.scrollIntoView({ block: "center", behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  }
});
net.on("lobby:update", t => { S.lobby = t; if (S.screen === "lobby") renderWaiting(); });
net.on("wallet:balance", b => { S.balance = b.balance; updateBalances(); });
net.on("wallet:linked", b => { S.linkedBalance = b.balance; updateBalances(); });
net.on("wallet:tx", tx => { S.txs.unshift(tx); S.txs = S.txs.slice(0, 60); if (S.sheet === "wallet") renderHistory(); });

async function login(p: { privyToken?: string; handle?: string; sessionToken?: string; phantom?: { wallet: string; signature: string } }) {
  // Without Privy, solana mode keeps the game wallet's key in this browser.
  let wallet: string | undefined;
  if (S.info?.mode === "solana" && !p.sessionToken && !p.privyToken) wallet = await (await import("./solana.ts")).burnerAddress();
  const r = await net.request("auth", { ...p, wallet });
  S.session = r.session;
  store.set("pot21.session", r.sessionToken);
  route();
  void refreshChainBalances();
}

/** Solana mode: read the Phantom wallet's token balance from chain. */
async function refreshChainBalances() {
  const ses = S.session;
  if (!ses || ses.mode !== "solana" || !ses.linked) return;
  try {
    const sol = await import("./solana.ts");
    S.linkedBalance = (await sol.tokenBalance(ses, ses.linked)).toString();
    updateBalances();
  } catch { /* the next action refreshes it */ }
}

/* ================= Privy (Sign in with X) ================= */

let privy: PrivyBridge | null = null;
let privyBusy = false;

async function initPrivy() {
  if (privy || !S.info) return;
  if (S.info.privyAppId) {
    try {
      const { mountPrivy } = await import("./privy/react-bridge.ts");
      privy = mountPrivy(S.info.privyAppId);
      const sol = await import("./solana.ts").catch(() => null);
      sol?.setPrivySigner(tx => privy!.signTransaction(tx));
    } catch (e) {
      console.error(e);
      toast("X sign-in couldn't load. Refresh the page to try again.", "error");
      return;
    }
  } else if (S.info.devLogin) {
    privy = demoBridge(askDemoHandle);
  }
  privy?.subscribe(s => {
    if (s.error) { setSignInError(s.error); }
    void finishPrivyLogin();
    if (S.screen === "login") syncSignInButton();
  });
  void finishPrivyLogin();
  syncSignInButton();
}

/** Once Privy says we're signed in (and the wallet exists), sign in to the game server. */
async function finishPrivyLogin() {
  const st = privy?.state();
  if (!privy || !st?.authenticated || S.session || privyBusy) return;
  if (privy.kind === "privy" && !st.wallet) return; // wallet is still being created
  privyBusy = true;
  syncSignInButton();
  try {
    if (privy.kind === "demo") await login({ handle: st.handle! });
    else {
      for (let attempt = 0; ; attempt++) {
        const privyToken = await privy.getAccessToken();
        if (!privyToken) throw new Error("X sign-in didn't complete. Try again.");
        try { await login({ privyToken }); break; }
        catch (e) {
          if (attempt < 5 && /still being created/.test((e as Error).message)) { await new Promise(r => setTimeout(r, 1500)); continue; }
          throw e;
        }
      }
    }
  } catch (e) {
    setSignInError((e as Error).message);
    await privy.logout().catch(() => {});
  } finally {
    privyBusy = false;
    syncSignInButton();
  }
}

function setSignInError(msg: string) {
  const el = $("#loginErr");
  if (el) el.textContent = msg;
}

/** Demo stand-in for X: ask for a handle inline on the sign-in card. */
function askDemoHandle(): Promise<string | null> {
  return new Promise(resolve => {
    const box = $("#xBox");
    if (!box) return resolve(null);
    box.innerHTML = `<form id="demoX" class="demo-x">
      <label class="field-label" for="demoHandle">Your X handle</label>
      <div class="amount-row"><input class="input" id="demoHandle" placeholder="@yourname" autocomplete="off" maxlength="16" required><button class="btn gold" type="submit">Continue</button></div>
      <p class="note">Demo sign-in: X isn't connected here, so type any handle.</p></form>`;
    const input = $<HTMLInputElement>("#demoHandle")!;
    input.focus();
    syncSignInButton();
    $("#demoX")!.addEventListener("submit", ev => { ev.preventDefault(); resolve(input.value.trim() || null); });
  });
}

/* ================= routing ================= */

function route() {
  const screen = !S.session ? "login" : S.view ? "table" : "lobby";
  if (screen !== S.screen) {
    S.screen = screen;
    if (screen === "login") renderSignIn();
    else {
      $("#app")!.innerHTML = topbarHTML() + `<main class="page" id="page"></main>`;
      wireTopbar();
      if (screen === "lobby") renderLobby();
    }
    window.scrollTo(0, 0);
  }
  if (screen === "table") renderTable();
  updateBalances();
  if (S.sheet === "fair") renderSheet();
}

/* ================= top bar ================= */

function topbarHTML() {
  const ses = S.session!;
  return `
  <header class="topbar"><div class="topbar-in">
    <div class="brand"><span class="mark">21</span><span class="word">Pot 21</span></div>
    ${ses.mode === "mock" ? `<span class="demo-tag" title="Tokens here are for testing and have no value">Demo tokens</span>` : ""}
    <div class="balance">
      <span><span class="amt num" id="topBal">…</span> <span class="sym">${esc(sym())}</span></span>
      <button class="btn gold sm" id="topDeposit">Deposit</button>
    </div>
    <button class="acct" id="acctBtn" aria-label="Open your wallet">${avatar(ses.handle)}<span class="name">${esc(ses.handle)}</span></button>
  </div></header>`;
}

function wireTopbar() {
  $("#acctBtn")!.onclick = () => openSheet("wallet");
  const d = $("#topDeposit");
  if (d) d.onclick = () => { S.walletTab = "deposit"; openSheet("wallet"); };
  const f = $<HTMLButtonElement>("#topFaucet");
  if (f) f.onclick = () => act(() => net.request("wallet:faucet", {}), f);
}

function updateBalances() {
  const top = $("#topBal");
  if (top) top.textContent = S.balance == null ? "…" : fmt(S.balance);
  const g = $("#sheetGameBal");
  if (g) g.textContent = S.balance == null ? "…" : fmt(S.balance);
  const l = $("#sheetLinkedBal");
  if (l) l.textContent = S.linkedBalance == null ? "…" : `${fmt(S.linkedBalance)} ${sym()}`;
  if (S.sheet === "wallet") updateBreakdown();
  if (S.screen === "lobby") syncPlay();
}

/* ================= sign in ================= */

function renderSignIn() {
  $("#app")!.innerHTML = `
  <main class="page">
    <div class="brand"><span class="mark">21</span><span class="word">Pot 21</span></div>
    <section class="signin">
      <div>
        <h1>Blackjack against real players. Best hand takes the pot.</h1>
        <p class="lede">Everyone at the table stakes the same amount. Get closer to 21 than the others and the whole pot goes straight to your wallet.</p>
        <div class="cta">
          <div id="xBox" class="xbox"><button class="btn lg xbtn block" id="xBtn">Sign in with X</button></div>
          <p class="note" id="xNote"></p>
          <p class="err" id="loginErr" role="alert"></p>
          <details class="other"><summary>Other ways to sign in</summary>
            <button class="btn" id="phantomBtn">Sign in with Phantom</button>
          </details>
        </div>
        <div class="facts">
          <div><b>A wallet is made for you</b>Signing in with X creates your own Solana wallet. No seed phrase to set up.</div>
          <div><b>Stakes held in escrow</b>Your stake sits in an on-chain account until the hand ends.</div>
          <div><b>Check every deal</b>Each shuffle can be verified once the hand is over.</div>
        </div>
      </div>
      <div class="hero-table" aria-hidden="true">
        <div class="felt"></div>
        <div class="fan">${cardHTML({ r: "A", s: "S" })}${cardHTML({ r: "K", s: "H" })}</div>
        <div class="badge21">21</div>
      </div>
    </section>
  </main>`;
  $("#xBtn")!.onclick = () => {
    setSignInError("");
    if (!privy) { setSignInError(S.info ? "X sign-in isn't set up on this server yet." : "Still connecting. Try again in a moment."); return; }
    privy.login().catch(e => setSignInError((e as Error).message));
  };
  $("#phantomBtn")!.onclick = async () => {
    const pb = $<HTMLButtonElement>("#phantomBtn")!;
    if (!getPhantom()) { window.open(PHANTOM_DOWNLOAD, "_blank", "noopener"); setSignInError("Phantom isn't installed in this browser."); return; }
    pb.disabled = true;
    setSignInError("");
    try {
      const phantom = await signInWithPhantom(async wallet => (await net.request("auth:challenge", { wallet })).message);
      await login({ phantom });
    } catch (e) { setSignInError((e as Error).message); pb.disabled = false; }
  };
  syncSignInButton();
}


function syncSignInButton() {
  const btn = $<HTMLButtonElement>("#xBtn");
  const note = $("#xNote");
  if (!btn || !note) return;
  const st = privy?.state();
  const working = privyBusy || (!!st?.authenticated && !S.session);
  btn.disabled = working || (privy?.kind === "privy" && !st?.ready);
  btn.innerHTML = working ? "Signing you in…" : `Sign in with X`;
  note.textContent = privy?.kind === "demo"
    ? ($("#demoX") ? "" : "Demo mode: X isn't connected here, so you'll type a handle instead.")
    : st?.authenticated && !st.wallet ? "Creating your wallet…" : "You'll approve the sign-in on X. New players get a Solana wallet automatically.";
}

/* ================= lobby ================= */

const STAKES = ["5", "10", "25", "50", "100", "250"];

function renderLobby() {
  const c = S.create;
  $("#page")!.innerHTML = `
  <div class="lobby">
    <div class="lobby-main">
      <section class="panel playnow">
        <h2>Play now</h2>
        <p class="sub">Choose how much to play for. You'll join people already waiting at that amount, or open a table for others to join.</p>
        <div class="stake-label">Stake per player</div>
        <div class="chips" role="group" aria-label="Stake per player">${STAKES.map(v => `<button class="chip" data-stake="${v}" aria-pressed="${v === c.stake}" aria-label="${v} ${esc(sym())}">${v}</button>`).join("")}</div>
        <div class="play-row"><button class="btn gold lg" id="playBtn"></button></div>
        <p class="play-hint" id="playHint"></p>
        <details class="more">
          <summary>Table options</summary>
          <div class="more-body">
            <div><span class="field-label">Players per table</span>
              <div class="seg">${range(MIN_SEATS, MAX_SEATS).map(n => `<button data-seats="${n}" aria-pressed="${n === c.seats}">${n}</button>`).join("")}</div></div>
            ${S.info?.bots ? `<div><span class="field-label">Practice bots</span><div class="seg" id="botSeg"></div></div>` : ""}
            <button class="btn" id="createBtn">Open a new table</button>
          </div>
        </details>
      </section>
      <section class="panel">
        <div class="section-head"><h2>Players waiting<span class="count" id="waitCount" hidden></span></h2></div>
        <ul class="waiting" id="waitList"></ul>
        <p class="inplay" id="inPlay"></p>
      </section>
    </div>
    <aside class="panel howto">
      <h2>How to play</h2>
      <ol>
        <li><div><b>Pick a stake</b><span>Everyone at the table puts in the same amount. That's the pot.</span></div></li>
        <li><div><b>Get closest to 21</b><span>On your turn, Hit to take a card or Stand to keep your total. Go over 21 and you're out.</span></div></li>
        <li><div><b>Best hand wins the pot</b><span>Paid straight to your wallet, minus a 2% house fee. Ties share it.</span></div></li>
      </ol>
      <div class="values">
        <div><b>2–10</b>face value</div>
        <div><b>J Q K</b>count as 10</div>
        <div><b>A</b>1 or 11</div>
      </div>
      <button class="linkbtn" id="rulesLink">Read the full rules</button>
    </aside>
  </div>`;

  $("#page")!.addEventListener("click", ev => {
    const b = (ev.target as HTMLElement).closest("button") as HTMLButtonElement | null;
    if (!b) return;
    const stake = () => parseUnits(S.create.stake, dec());
    if (b.dataset.stake) { S.create.stake = b.dataset.stake; syncPlay(); }
    else if (b.dataset.seats) { S.create.seats = +b.dataset.seats; syncPlay(); }
    else if (b.dataset.bots) { S.create.bots = +b.dataset.bots; syncPlay(); }
    else if (b.id === "rulesLink") openSheet("rules");
    else if (b.id === "playBtn") {
      if (needsDeposit(stake())) return openDeposit();
      // The preview has no other people, so it fills the table with bots.
      if (injected && !matchFor(stake())) {
        void act(() => net.request("table:create", { seats: S.create.seats, stake: S.create.stake, bots: S.create.seats - 1, clientSeed: clientSeed() }), b);
      } else void act(() => net.request("table:quick", { stake: S.create.stake, seats: S.create.seats, clientSeed: clientSeed() }), b);
    } else if (b.id === "createBtn") {
      if (needsDeposit(stake())) return openDeposit();
      void act(() => net.request("table:create", { ...S.create, clientSeed: clientSeed() }), b);
    } else if (b.dataset.join) {
      const t = S.lobby.find(x => x.id === b.dataset.join);
      if (t && needsDeposit(BigInt(t.stake))) return openDeposit();
      void act(() => net.request("table:join", { tableId: b.dataset.join!, clientSeed: clientSeed() }), b);
    }
  });
  renderWaiting();
}

/** Tables with free seats, closest to starting first (same order the server uses). */
function waitingTables() {
  return S.lobby
    .filter(t => t.phase === "open" && t.occupied < t.seats)
    .sort((a, b) => (b.occupied / b.seats - a.occupied / a.seats) || a.openedAt - b.openedAt);
}
const matchFor = (stake: bigint) => waitingTables().find(t => BigInt(t.stake) === stake);
const needsDeposit = (stake: bigint) => !!S.session?.linked && S.balance != null && BigInt(S.balance) < stake;
function openDeposit() { S.walletTab = "deposit"; openSheet("wallet"); }

function syncPlay() {
  const btn = $<HTMLButtonElement>("#playBtn");
  if (!btn) return;
  const c = S.create;
  c.bots = Math.min(c.bots, c.seats - 1);
  document.querySelectorAll<HTMLButtonElement>("[data-stake]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.stake === c.stake)));
  document.querySelectorAll<HTMLButtonElement>("[data-seats]").forEach(b => b.setAttribute("aria-pressed", String(+b.dataset.seats! === c.seats)));
  const bs = $("#botSeg");
  if (bs) bs.innerHTML = range(0, c.seats - 1).map(n => `<button data-bots="${n}" aria-pressed="${n === c.bots}">${n}</button>`).join("");

  const stake = parseUnits(c.stake, dec());
  const match = matchFor(stake);
  const winTxt = (seats: number) => `The winner gets ${nice(potPreview(stake, seats).net)} ${sym()}.`;
  const hint = $("#playHint")!;
  if (needsDeposit(stake)) {
    btn.textContent = `Deposit to play for ${c.stake}`;
    hint.textContent = `Your wallet has ${nice(S.balance!)} ${sym()}. Add tokens from Phantom to take a seat.`;
  } else if (match) {
    const host = match.players.find(p => !p.isBot)?.handle ?? "a player";
    const left = match.seats - match.occupied;
    btn.textContent = `Join ${host} for ${c.stake} ${sym()}`;
    hint.textContent = `${host} is waiting. ${left === 1 ? "You'll fill the last seat, so the hand starts right away." : `${plural(left - 1, "more player")} needed after you.`} ${winTxt(match.seats)}`;
  } else if (injected) {
    btn.textContent = `Play for ${c.stake} ${sym()}`;
    hint.textContent = `Preview: nobody else is here, so practice bots take the other ${c.seats - 1 === 1 ? "seat" : "seats"}. ${winTxt(c.seats)}`;
  } else {
    btn.textContent = `Play for ${c.stake} ${sym()}`;
    hint.textContent = `Nobody is waiting at ${c.stake} ${sym()} yet. You'll open a table, and the hand starts when ${c.seats === 2 ? "one more player joins" : `${c.seats - 1} more players join`}. ${winTxt(c.seats)}`;
  }
}

const ago = (ms: number) => {
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  return s < 45 ? "just now" : s < 3600 ? `${Math.max(1, Math.round(s / 60))} min` : `${Math.round(s / 3600)} h`;
};

function renderWaiting() {
  const list = $("#waitList");
  if (!list) return;
  const waiting = waitingTables();
  const inPlay = S.lobby.length - waiting.length;
  const count = $("#waitCount")!;
  count.hidden = !waiting.length;
  count.textContent = String(waiting.length);
  $("#inPlay")!.textContent = inPlay ? `${plural(inPlay, "table")} playing a hand right now.` : "";
  list.innerHTML = waiting.length ? waiting.map(t => {
    const left = t.seats - t.occupied;
    const humans = t.players.filter(p => !p.isBot);
    const names = humans.map(p => p.handle).join(", ") + (t.players.length > humans.length ? ` + ${plural(t.players.length - humans.length, "bot")}` : "");
    return `<li>
      <div class="stack">${t.players.map(p => avatar(p.handle)).join("")}${range(1, left).map(() => `<span class="avatar open"></span>`).join("")}</div>
      <div class="who"><b>${esc(names)}</b><span>${left === 1 ? "1 seat left" : `${left} seats left`}, waiting ${ago(t.openedAt)}</span></div>
      <div class="money"><b class="num">${nice(t.stake)} ${esc(sym())}</b><span>winner gets ${nice(potPreview(BigInt(t.stake), t.seats).net)}</span></div>
      <button class="btn gold" data-join="${esc(t.id)}">Join</button>
    </li>`;
  }).join("") : `<li class="empty-state">Nobody is waiting right now. Press Play and your table will show up here for others.</li>`;
  syncPlay();
}
setInterval(() => { if (S.screen === "lobby") renderWaiting(); }, 15_000);

/* ================= table ================= */

const SUIT: Record<Card["s"], string> = { S: "♠", H: "♥", D: "♦", C: "♣" };
const SUIT_NAME: Record<Card["s"], string> = { S: "spades", H: "hearts", D: "diamonds", C: "clubs" };
function cardHTML(c: Card | null, fresh = false) {
  if (!c) return `<div class="card back ${fresh ? "deal" : ""}" aria-label="Face-down card"></div>`;
  const red = c.s === "H" || c.s === "D";
  return `<div class="card ${red ? "red" : ""} ${fresh ? "deal" : ""}" aria-label="${c.r} of ${SUIT_NAME[c.s]}"><span>${c.r}</span><span class="c-mid">${SUIT[c.s]}</span><span class="c-bot">${c.r}</span></div>`;
}

/** Cards already on screen, so only newly dealt ones animate. */
const shown = new Map<string, number>();
function handHTML(s: SeatView, roundId: string | undefined) {
  const key = `${roundId}:${s.seat}`;
  const before = shown.get(key) ?? 0;
  shown.set(key, s.cards.length);
  return s.cards.map((c, i) => cardHTML(c, i >= before)).join("");
}

function pillFor(s: SeatView, v: TableView, you: boolean) {
  const r = v.round;
  if (!r || r.phase === "cancelled") return { text: you ? "Seated" : "Seated", cls: "" };
  if (r.phase === "funding") return s.status === "deposited" ? { text: "Staked", cls: "" } : { text: "Not staked yet", cls: "" };
  if (r.phase === "done" && s.payout && !r.allBust) return { text: `+${nice(s.payout)} ${sym()}`, cls: "win" };
  if (r.phase === "playing" && r.turnSeat === s.seat) return { text: you ? "Your turn" : "Playing", cls: "turn" };
  switch (s.status) {
    case "bust": return { text: "Bust", cls: "bust" };
    case "blackjack": return { text: "Blackjack", cls: "bj" };
    case "stood": return { text: "Stands", cls: "" };
    case "timedout": return { text: "Out of time", cls: "" };
    default: return { text: "Waiting", cls: "" };
  }
}

function seatHTML(s: SeatView | null, v: TableView, you = false) {
  if (!s) return `<div class="seat open"><div class="hand"></div><div class="head"><span class="ring"><span class="avatar open" style="border:2px dashed var(--faint)"></span></span><span class="name muted">Open seat</span></div><span class="pill">Waiting for a player</span></div>`;
  const r = v.round;
  const turn = r?.phase === "playing" && r.turnSeat === s.seat;
  const won = r?.phase === "done" && !!s.payout && !r.allBust;
  const pill = pillFor(s, v, you);
  const total = s.total != null && s.cards.length ? `<span class="total ${s.status === "bust" ? "bust" : s.status === "blackjack" ? "bj" : ""}">${s.total}</span>` : "";
  return `<div class="seat ${you ? "you" : ""} ${turn ? "turn" : ""} ${won ? "won" : ""} ${s.connected ? "" : "off"}">
    <div class="hand">${handHTML(s, r?.id)}${total}</div>
    <div class="head">
      <span class="ring ${turn ? "timing" : ""}" ${turn ? `data-ring="${r!.turnEndsAt}"` : ""}>${avatar(s.handle)}</span>
      <span class="name">${you ? "You" : esc(s.handle)}</span>${s.isBot ? `<span class="bot">bot</span>` : ""}
    </div>
    <span class="pill ${pill.cls}">${esc(pill.text)}</span>
  </div>`;
}

/** Best finished hand among the other players, for coaching. 22 = blackjack. */
function bestSoFar(v: TableView) {
  let best = -1, who = "";
  v.seated.forEach((s, i) => {
    if (!s || i === v.yourSeat || s.total == null) return;
    if (!["stood", "blackjack", "timedout"].includes(s.status)) return;
    const strength = s.status === "blackjack" ? 22 : s.total;
    if (strength > best) { best = strength; who = s.handle; }
  });
  return best < 0 ? null : { strength: best, who };
}

function coach(v: TableView, me: SeatView): { say: string; help: string } {
  const total = me.total ?? handTotal(me.cards.filter(Boolean) as Card[]);
  const best = bestSoFar(v);
  const r = v.round!;
  const myPos = r.order.indexOf(v.yourSeat!);
  const after = r.order.slice(myPos + 1).filter(seat => v.seated[seat]?.status === "playing").length;
  const later = after ? ` ${plural(after, "player")} still to play after you.` : "";
  const say = `Your turn. You have ${total}.`;
  if (best?.strength === 22) return { say, help: `${best.who} has blackjack, which beats any other hand. Stand to finish the hand.` };
  if (best && total > best.strength) return { say, help: `You're ahead: the best hand so far is ${best.strength}. Standing keeps you in front.${later}` };
  if (best && total === best.strength) return { say, help: `You're tied with ${best.who} on ${best.strength}. Stand to share the pot, or hit to try to beat it.${later}` };
  if (best) return { say, help: `${best.who} has ${best.strength}, so you need more to win. Hit to take a card.${later}` };
  if (total <= 11) return { say, help: `No card can take you over 21 from here, so hitting is safe.${later}` };
  if (total <= 16) return { say, help: `A 10, J, Q or K would put you over 21. Hit to try for more, or stand to keep ${total}.${later}` };
  return { say, help: `That's a strong hand. Most players stand on 17 or more.${later}` };
}

function dockHTML(v: TableView): string {
  const r = v.round;
  const me = v.yourSeat != null ? v.seated[v.yourSeat] : null;
  const stakeTxt = `${nice(v.stake)} ${sym()}`;
  const empty = v.seated.filter(s => !s).length;
  const leave = `<button class="btn ghost" id="leaveBtn">Leave table</button>`;
  const check = `<button class="btn" id="fairBtn2">Check this deal</button>`;
  const fundingBar = r?.fundingEndsAt ? `<div class="bar" title="Time left to stake"><i data-ends="${r.fundingEndsAt}" data-total="${FUNDING_MS}"></i></div>` : "";

  if (!r) {
    return `<div class="dock"><div><p class="say">Waiting for ${plural(empty, "more player")}</p>
      <p class="help">The hand starts as soon as every seat is filled. You'll be asked to stake ${stakeTxt} then.</p></div>
      <div class="acts">${leave}</div></div>`;
  }
  if (r.phase === "funding") {
    const staked = v.seated.filter(s => s?.status === "deposited").length;
    if (me?.status !== "deposited") {
      return `<div class="dock"><div><p class="say">Table's full. Stake ${stakeTxt} to start.</p>
        <p class="help">Your stake is held in escrow until the hand ends, and the best hand wins ${nice(r.net)} ${sym()}. If anyone doesn't stake in time, everyone is refunded.</p></div>
        <div class="acts">${leave}<button class="btn gold lg" id="stakeBtn">Stake ${stakeTxt}</button></div>${fundingBar}</div>`;
    }
    return `<div class="dock"><div><p class="say">You're in. Waiting for the others to stake.</p>
      <p class="help">${staked} of ${v.seats} staked. Cards are dealt as soon as everyone has.</p></div>${fundingBar}</div>`;
  }
  if (r.phase === "playing") {
    if (me && r.turnSeat === v.yourSeat) {
      const c = coach(v, me);
      return `<div class="dock"><div><p class="say">${esc(c.say)}</p><p class="help">${esc(c.help)}</p></div>
        <div class="acts"><button class="btn lg" id="standBtn">Stand<span class="kbd">S</span></button><button class="btn gold lg" id="hitBtn">Hit<span class="kbd">H</span></button></div>
        <div class="bar" title="Time left for your move"><i data-ends="${r.turnEndsAt}" data-total="${TURN_MS}"></i></div></div>`;
    }
    const current = r.turnSeat != null ? v.seated[r.turnSeat] : null;
    const mine = me?.status === "bust" ? `You went over 21 with ${me.total}.`
      : me?.status === "blackjack" ? "You have blackjack."
      : me && ["stood", "timedout"].includes(me.status) ? `You're standing on ${me.total}.`
      : "Your turn is coming up.";
    return `<div class="dock"><div><p class="say">${current ? `${esc(current.handle)} is playing…` : "Dealing…"}</p>
      <p class="help">${esc(mine)}</p></div></div>`;
  }
  if (r.phase === "settling") {
    return `<div class="dock"><div><p class="say">Paying out the pot…</p><p class="help">Winnings are on their way to the winner's wallet.</p></div></div>`;
  }
  if (r.phase === "cancelled") {
    return `<div class="dock result"><div><p class="big">Hand cancelled</p>
      <p class="help">Not everyone staked in time. Every stake was refunded in full, with no fee.</p></div><div class="acts">${leave}</div></div>`;
  }
  // Hand finished.
  const winners = (r.winners ?? []).map(w => v.seated[w]).filter(Boolean) as SeatView[];
  const mineWon = me?.payout ? BigInt(me.payout) : 0n;
  const next = "The next hand starts in a few seconds if everyone stays.";
  if (r.allBust) {
    return `<div class="dock result"><div><p class="big">Everyone went over 21</p>
      <p class="help">Nobody wins, so the pot was shared out. You got back ${nice(mineWon)} ${sym()}: your stake minus the 2% fee. ${next}</p></div>
      <div class="acts">${leave}${check}</div></div>`;
  }
  if (mineWon > 0n) {
    const split = winners.length > 1;
    const others = winners.filter(w => w.seat !== v.yourSeat).map(w => w.handle).join(", ");
    return `<div class="dock result win"><div><p class="big">${split ? `You split the pot: +${nice(mineWon)} ${sym()}` : `You won ${nice(mineWon)} ${sym()}`}</p>
      <p class="help">${split ? `Tied with ${esc(others)}. ` : ""}It's already in your wallet. ${next}</p></div>
      <div class="acts">${leave}${check}</div></div>`;
  }
  const top = winners[0];
  const why = me?.status === "bust" ? "You went over 21." : me?.total != null ? `You had ${me.total}.` : "";
  const with_ = top?.status === "blackjack" ? "blackjack" : String(top?.total ?? "the best hand");
  const headline = winners.length > 1
    ? `${winners.map(w => w.handle).join(" and ")} split the pot with ${with_}`
    : `${top?.handle ?? "Another player"} won with ${with_}`;
  return `<div class="dock result"><div><p class="big">${esc(headline)}</p>
    <p class="help">${esc(why)} Your ${stakeTxt} stake went to the pot. ${next}</p></div>
    <div class="acts">${leave}${check}</div></div>`;
}

function renderTable() {
  const v = S.view!;
  const page = $("#page");
  if (!page) return;
  const r = v.round;
  const me = v.yourSeat != null ? v.seated[v.yourSeat] : null;
  // Opponents in play order, starting from the seat after yours.
  const others = v.seated.map((s, i) => ({ s, i })).filter(x => x.i !== v.yourSeat)
    .sort((a, b) => ((a.i - (v.yourSeat ?? 0) + v.seats) % v.seats) - ((b.i - (v.yourSeat ?? 0) + v.seats) % v.seats));
  const preview = potPreview(BigInt(v.stake), v.seats);
  const live = r && r.phase !== "cancelled";
  const winAmt = live ? r.net : preview.net.toString();
  const total = live ? r.total : preview.total.toString();
  const fee = live ? r.fee : preview.fee.toString();
  const staked = live ? v.seated.filter(s => s && s.status !== "waiting").length : 0;

  page.innerHTML = `
  <div class="table-wrap">
    <div class="table-bar">
      <div class="title"><h2>${nice(v.stake)} ${esc(sym())} table</h2><span>${v.seats} players, winner takes ${nice(winAmt)}</span></div>
      <button class="btn sm ghost" id="rulesBtn">Rules</button>
      <button class="btn sm ghost" id="fairBtn">Fair play</button>
    </div>
    <div class="felt">
      <div class="opps">${others.map(x => seatHTML(x.s, v)).join("")}</div>
      <div class="pot">
        ${staked ? `<div class="pot-chips">${range(1, Math.min(8, staked * 2)).map(() => "<i></i>").join("")}</div>` : ""}
        <span class="lbl">${live ? "Winner takes" : "Winner takes, once the table is full"}</span>
        <span class="amt num">${nice(winAmt)} ${esc(sym())}</span>
        <span class="sub">${nice(total)} staked, ${nice(fee)} house fee (2%)</span>
      </div>
      ${me ? seatHTML(me, v, true) : ""}
    </div>
    ${dockHTML(v)}
  </div>`;

  $("#rulesBtn")!.onclick = () => openSheet("rules");
  $("#fairBtn")!.onclick = () => openSheet("fair");
  const f2 = $("#fairBtn2");
  if (f2) f2.onclick = () => openSheet("fair");
  const leave = $<HTMLButtonElement>("#leaveBtn");
  if (leave) leave.onclick = () => act(() => net.request("table:leave", {}), leave);
  const stake = $<HTMLButtonElement>("#stakeBtn");
  if (stake) stake.onclick = () => {
    if (needsDeposit(BigInt(v.stake))) return openDeposit();
    void act(async () => {
      let signature: string | undefined;
      if (S.session!.mode === "solana") {
        stake.textContent = "Confirm in wallet…";
        signature = await (await import("./solana.ts")).stakeOnChain(S.session!, r!.id, v.yourSeat!);
      }
      await net.request("round:deposit", { roundId: r!.id, signature });
    }, stake);
  };
  const hit = $<HTMLButtonElement>("#hitBtn"), stand = $<HTMLButtonElement>("#standBtn");
  if (hit) hit.onclick = () => move("hit");
  if (stand) stand.onclick = () => move("stand");
}

function move(action: "hit" | "stand") {
  const r = S.view?.round;
  if (!r || r.phase !== "playing" || r.turnSeat !== S.view?.yourSeat) return;
  document.querySelectorAll<HTMLButtonElement>("#hitBtn,#standBtn").forEach(b => (b.disabled = true));
  void act(() => net.request("round:action", { roundId: r.id, action }));
}

document.addEventListener("keydown", ev => {
  if (S.screen !== "table" || S.sheet || ev.metaKey || ev.ctrlKey || ev.altKey) return;
  if ((ev.target as HTMLElement).closest("input,textarea")) return;
  if (ev.key === "h" || ev.key === "H") move("hit");
  if (ev.key === "s" || ev.key === "S") move("stand");
});

/* ================= sheets ================= */

function openSheet(which: Exclude<Sheet, null>) { S.sheet = which; renderSheet(); }
function closeSheet() { S.sheet = null; $("#drawerRoot")!.innerHTML = ""; }
document.addEventListener("keydown", ev => { if (ev.key === "Escape" && S.sheet) closeSheet(); });

function renderSheet() {
  const root = $("#drawerRoot")!;
  if (!S.sheet || !S.session) { root.innerHTML = ""; return; }
  const title = S.sheet === "wallet" ? "Your wallet" : S.sheet === "rules" ? "How Pot 21 works" : "Fair play";
  const body = S.sheet === "wallet" ? walletHTML() : S.sheet === "rules" ? rulesHTML() : fairHTML();
  root.innerHTML = `<div class="scrim" id="scrim"></div>
    <aside class="sheet" role="dialog" aria-modal="true" aria-label="${title}">
      <div class="sheet-head"><h2>${title}</h2><button class="x" id="sheetClose" aria-label="Close">✕</button></div>
      <div class="sheet-body">${body}</div>
    </aside>`;
  $("#scrim")!.onclick = closeSheet;
  $("#sheetClose")!.onclick = closeSheet;
  if (S.sheet === "wallet") wireWallet();
  if (S.sheet === "fair") wireFair();
  ($("#moveAmt") ?? $("#sheetClose"))?.focus();
}

/* ---- wallet ---- */

function walletHTML() {
  const ses = S.session!;
  const linked = !!ses.linked;
  return `
    <div class="wallet-hero">
      <div class="lbl">Game wallet balance</div>
      <div class="amt num"><span id="sheetGameBal">${S.balance == null ? "…" : fmt(S.balance)}</span><small>${esc(sym())}</small></div>
      <div class="addr-row"><span class="addr" title="${esc(ses.wallet)}">${esc(short(ses.wallet))}</span><button class="btn sm" id="copyAddr">Copy address</button></div>
      ${ses.login === "privy" ? `<p class="muted small" style="margin:10px 0 0">Created for you by Privy when you signed in with X.</p>` : ""}
    </div>
    ${linked ? `
      <div class="linked-row"><span class="muted">Phantom ${esc(short(ses.linked!))}</span><b class="num" id="sheetLinkedBal">${S.linkedBalance == null ? "…" : `${fmt(S.linkedBalance)} ${esc(sym())}`}</b></div>
      <div class="tabs" role="tablist">
        <button role="tab" data-tab="deposit" aria-selected="${S.walletTab === "deposit"}">Deposit</button>
        <button role="tab" data-tab="withdraw" aria-selected="${S.walletTab === "withdraw"}">Withdraw</button>
      </div>
      <form class="move" id="moveForm">
        <label class="field-label" for="moveAmt" id="moveLabel"></label>
        <div class="amount-row"><input class="input num" id="moveAmt" inputmode="decimal" autocomplete="off" placeholder="0"><button type="button" class="btn" id="maxBtn">Max</button></div>
        <div class="breakdown" id="breakdown"></div>
        <button class="btn gold lg block" type="submit" id="moveGo"></button>
      </form>` : `
      <section class="connect">
        <h3>Deposit and withdraw with Phantom</h3>
        <p class="muted">Connect your Phantom wallet to move tokens in and out of your game wallet. You'll sign a free message to prove it's yours.</p>
        <button class="btn gold block" id="linkBtn">Connect Phantom</button>
        <p class="muted small">Or send ${esc(sym())} to your game wallet address from any Solana wallet.</p>
        ${ses.mode === "mock" ? `<button class="btn sm" id="sheetFaucet">Add demo tokens</button>` : ""}
      </section>`}
    <section>
      <h3 style="margin-bottom:6px">History</h3>
      <ul class="history" id="history"></ul>
    </section>
    ${ses.mode === "solana" && ses.login !== "privy" ? `<details class="backup"><summary>Back up your game wallet</summary>
      <p class="muted" style="font-size:.88rem">Your game wallet's key is stored in this browser. Save the backup key somewhere safe to use the wallet elsewhere. Anyone with the key can spend your tokens.</p>
      <button class="btn sm" id="exportBtn">Show backup key</button>
      <div class="hash" id="exportOut" hidden></div>
      <label class="field-label" for="importKey" style="margin-top:12px">Restore from a backup key</label>
      <div class="amount-row"><input class="input" id="importKey" autocomplete="off" spellcheck="false"><button class="btn" id="importBtn">Restore</button></div>
    </details>` : ""}
    <button class="btn ghost" id="logoutBtn">Sign out</button>`;
}

function wireWallet() {
  const ses = S.session!;
  $("#copyAddr")!.onclick = () => {
    navigator.clipboard?.writeText(ses.wallet).then(() => toast("Address copied.")).catch(() => toast(ses.wallet));
  };
  $("#logoutBtn")!.onclick = async () => {
    const token = store.get("pot21.session");
    if (token) await net.request("auth:logout", { sessionToken: token }).catch(() => {});
    store.del("pot21.session");
    await privy?.logout().catch(() => {});
    await getPhantom()?.disconnect().catch(() => {});
    location.reload();
  };
  const lb = $<HTMLButtonElement>("#linkBtn");
  if (lb) lb.onclick = () => void act(async () => {
    if (!getPhantom()) { window.open(PHANTOM_DOWNLOAD, "_blank", "noopener"); throw new Error("Install Phantom, then come back and connect it."); }
    const signed = await signInWithPhantom(async wallet => (await net.request("auth:challenge", { wallet })).message);
    const { session } = await net.request("wallet:link", signed);
    S.session = session;
    toast("Phantom connected.");
    renderSheet();
    void refreshChainBalances();
  }, lb);
  const sf = $<HTMLButtonElement>("#sheetFaucet");
  if (sf) sf.onclick = () => act(() => net.request("wallet:faucet", {}), sf);
  document.querySelectorAll<HTMLButtonElement>("[data-tab]").forEach(b => b.onclick = () => {
    S.walletTab = b.dataset.tab as "deposit" | "withdraw";
    document.querySelectorAll<HTMLButtonElement>("[data-tab]").forEach(x => x.setAttribute("aria-selected", String(x === b)));
    syncMoveForm();
  });
  const input = $<HTMLInputElement>("#moveAmt");
  if (input) {
    input.oninput = updateBreakdown;
    $("#maxBtn")!.onclick = () => {
      const max = S.walletTab === "deposit" ? S.linkedBalance : S.balance;
      if (max) { input.value = formatUnits(max, dec(), dec()).replace(/,/g, "").replace(/\.?0+$/, ""); updateBreakdown(); }
    };
    $("#moveForm")!.addEventListener("submit", ev => { ev.preventDefault(); void submitMove(); });
    syncMoveForm();
  }
  const ex = $<HTMLButtonElement>("#exportBtn");
  if (ex) ex.onclick = () => act(async () => { const out = $("#exportOut")!; out.textContent = await (await import("./solana.ts")).exportBurner(); out.hidden = false; }, ex);
  const im = $<HTMLButtonElement>("#importBtn");
  if (im) im.onclick = () => act(async () => {
    const addr = await (await import("./solana.ts")).importBurner($<HTMLInputElement>("#importKey")!.value);
    toast(`Restored game wallet ${short(addr)}. Sign in again to use it.`);
  }, im);
  renderHistory();
}

function syncMoveForm() {
  const label = $("#moveLabel");
  if (!label) return;
  const dep = S.walletTab === "deposit";
  label.textContent = dep ? "Amount to send from Phantom" : "Amount to withdraw to Phantom";
  $("#moveGo")!.textContent = dep ? "Deposit" : "Withdraw";
  updateBreakdown();
}

function updateBreakdown() {
  const out = $("#breakdown"), input = $<HTMLInputElement>("#moveAmt");
  if (!out || !input || !S.session) return;
  const dep = S.walletTab === "deposit";
  const bps = dep ? S.session.fees.depositBps : S.session.fees.withdrawBps;
  const go = $<HTMLButtonElement>("#moveGo");
  let amount = 0n;
  try { amount = parseUnits(input.value || "0", dec()); }
  catch { out.innerHTML = `<div class="warn">Enter a number, like 100 or 12.5.</div>`; if (go) go.disabled = true; return; }
  const { fee, net: arrives } = amount > 0n ? transferFee(amount, bps) : { fee: 0n, net: 0n };
  const have = BigInt((dep ? S.linkedBalance : S.balance) ?? "0");
  out.innerHTML = `
    <div><span>${dep ? "From Phantom" : "From your game wallet"}</span><span class="num">${fmt(amount)}</span></div>
    <div class="muted"><span>House fee (${bps / 100}%)</span><span class="num">−${fmt(fee)}</span></div>
    <div class="tot"><span>${dep ? "Arrives in your game wallet" : "Arrives in Phantom"}</span><span class="num">${fmt(arrives)} ${esc(sym())}</span></div>
    ${amount > have ? `<div class="warn">You have ${fmt(have)} ${esc(sym())} ${dep ? "in Phantom" : "in your game wallet"}.</div>` : ""}`;
  if (go) go.disabled = amount <= 0n || amount > have;
}

async function submitMove() {
  const go = $<HTMLButtonElement>("#moveGo");
  const input = $<HTMLInputElement>("#moveAmt")!;
  const dep = S.walletTab === "deposit";
  const done = await act(async () => {
    const ses = S.session!;
    const amount = parseUnits(input.value, dec());
    let signature: string | undefined;
    if (ses.mode === "solana") {
      const sol = await import("./solana.ts");
      go!.textContent = dep ? "Approve in Phantom…" : "Sending…";
      signature = dep ? await sol.depositFromPhantom(ses, amount, getPhantom()!) : await sol.withdrawToPhantom(ses, amount);
    }
    await net.request(dep ? "wallet:deposit" : "wallet:withdraw", { amount: input.value.trim(), signature });
    return transferFee(amount, dep ? ses.fees.depositBps : ses.fees.withdrawBps);
  }, go);
  if (go?.isConnected) go.textContent = dep ? "Deposit" : "Withdraw";
  if (!done) return;
  toast(dep ? `Deposited. ${nice(done.net)} ${sym()} added to your game wallet.` : `Withdrawn. ${nice(done.net)} ${sym()} sent to Phantom.`);
  input.value = "";
  updateBreakdown();
  void refreshChainBalances();
  if (dep && S.screen === "lobby") closeSheet();
}

function renderHistory() {
  const el = $("#history");
  if (!el) return;
  el.innerHTML = S.txs.length ? S.txs.map(t => `<li>
      <span>${esc(t.label)}</span><span class="a num ${t.kind}">${t.kind === "in" ? "+" : t.kind === "out" ? "−" : ""}${fmt(t.amount)}</span>
      <span class="t">${esc(t.route)}</span><span class="t">${new Date(t.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
    </li>`).join("")
    : `<li><span class="muted">Deposits, stakes and winnings will show up here.</span></li>`;
}

/* ---- rules ---- */

function rulesHTML() {
  const feeTxt = `${(S.session?.fees.depositBps ?? 200) / 100}%`;
  return `<div class="rules">
    <section><h3>The goal</h3><p>Finish with a hand closer to 21 than every other player at the table, without going over. You play against the other players, not a dealer.</p></section>
    <section><h3>Card values</h3><ul><li>2 to 10 are worth their number.</li><li>J, Q and K are worth 10.</li><li>An ace is worth 11, or 1 if 11 would take you over 21.</li></ul></section>
    <section><h3>A hand, start to finish</h3><ul>
      <li>When the table is full, everyone stakes the same amount. That's the pot.</li>
      <li>Everyone gets two cards. You always see your own. Other players' first card stays face down until their turn.</li>
      <li>Players take turns. Hit to take another card, or Stand to keep your total. You have ${TURN_MS / 1000} seconds; if time runs out you stand.</li>
      <li>Go over 21 and you're bust, which means you're out of this hand.</li>
      <li>Who goes first moves round one seat each hand, so nobody always goes first.</li></ul></section>
    <section><h3>Who wins</h3><ul>
      <li>The highest total of 21 or under takes the pot.</li>
      <li>Blackjack (an ace plus a 10, J, Q or K as your first two cards) beats any other 21.</li>
      <li>Tied players share the pot equally.</li>
      <li>If everyone goes bust, the pot is shared out equally.</li></ul></section>
    <section><h3>Money</h3><ul>
      <li>The house keeps 2% of each pot. The rest goes to the winner's wallet as soon as the hand ends.</li>
      <li>Deposits and withdrawals have a ${feeTxt} fee, shown before you confirm.</li>
      <li>If anyone doesn't stake within ${FUNDING_MS / 1000} seconds, every stake is refunded in full with no fee.</li></ul></section>
    <section><h3>Fair dealing</h3><p>Before each hand the shuffle is locked in and its fingerprint is published. When the hand ends, anyone can check the cards dealt match it. Open Fair play at any table to check a hand.</p></section>
  </div>`;
}

/* ---- fairness ---- */

function fairHTML() {
  const r = S.view?.round;
  if (!r) return `<div class="rules"><p>Every shuffle is locked in before anyone stakes, and your own random seed is mixed in, so nobody, including the site, can choose the cards. When a hand ends, the secret is revealed and you can check every card dealt.</p><p class="muted">Your seed: <span class="addr">${esc(clientSeed())}</span></p></div>`;
  const done = !!r.serverSeed;
  const v = S.verify && S.verify.roundId === r.id ? S.verify : null;
  return `<div class="rules">
    <p>${done ? "This hand is over, so you can check it now." : "You can check this hand once it ends."}</p>
    ${done ? `<button class="btn gold" id="verifyBtn">Check this deal</button>` : ""}
    ${v ? `<p class="${v.ok ? "ok" : "bad"}">${esc(v.text)}</p>` : ""}
    <section><h3>Shuffle fingerprint</h3><div class="hash">${esc(r.commit)}</div><p class="muted" style="font-size:.85rem">Published before anyone staked.</p></section>
    <section><h3>Player seeds</h3><div class="hash">${r.clientSeeds.map(esc).join("<br>")}</div></section>
    ${done ? `<section><h3>Revealed shuffle secret</h3><div class="hash">${esc(r.serverSeed!)}</div></section>` : ""}
    ${r.escrow ? `<section><h3>Escrow account</h3><div class="hash">${esc(r.escrow)}</div></section>` : ""}
  </div>`;
}

function wireFair() {
  const b = $<HTMLButtonElement>("#verifyBtn");
  if (!b) return;
  b.onclick = () => {
    const v = S.view!, r = v.round!;
    const hands = v.seated.map(s => (s?.cards ?? []) as Card[]);
    if (hands.some(h => h.some(c => !c))) S.verify = { roundId: r.id, ok: false, text: "Some cards are still hidden." };
    else {
      const res = verifyRound({ serverSeed: r.serverSeed!, commit: r.commit, roundId: r.id, clientSeeds: r.clientSeeds, order: r.order, hands });
      S.verify = { roundId: r.id, ok: res.ok, text: res.ok ? `Verified. The secret matches the fingerprint, and all ${hands.flat().length} cards match the shuffle.` : res.reason };
    }
    renderSheet();
  };
}

/* ================= timers ================= */

function tick() {
  const now = Date.now();
  document.querySelectorAll<HTMLElement>("[data-ends]").forEach(el => {
    const left = Math.max(0, +el.dataset.ends! - now);
    el.style.width = `${Math.min(100, (left / +el.dataset.total!) * 100)}%`;
  });
  document.querySelectorAll<HTMLElement>("[data-ring]").forEach(el => {
    const left = Math.max(0, +el.dataset.ring! - now);
    el.style.setProperty("--p", String(Math.min(1, left / TURN_MS)));
  });
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

/* ================= boot ================= */

if (injected) { S.info = injected.info; route(); void initPrivy(); }
else fetch("/api/info").then(r => r.json()).then((info: Info) => {
  S.info = info;
  void initPrivy();
  if (!S.session) { S.screen = ""; route(); }
}).catch(() => toast("Can't reach the game server.", "error"));
