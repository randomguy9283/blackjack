export const SUITS = ["S", "H", "D", "C"] as const;
export const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"] as const;
export type Suit = (typeof SUITS)[number];
export type Rank = (typeof RANKS)[number];
export interface Card { r: Rank; s: Suit }

/** Ordered 52-card deck, before shuffling. Order is part of the fairness spec. */
export function orderedDeck(): Card[] {
  const d: Card[] = [];
  for (const s of SUITS) for (const r of RANKS) d.push({ r, s });
  return d;
}

export function handTotal(hand: Card[]): number {
  let total = 0, aces = 0;
  for (const c of hand) {
    if (c.r === "A") { aces++; total += 11; }
    else if (c.r === "J" || c.r === "Q" || c.r === "K") total += 10;
    else total += Number(c.r);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

export const isNatural = (hand: Card[]) => hand.length === 2 && handTotal(hand) === 21;
export const isBust = (hand: Card[]) => handTotal(hand) > 21;

/**
 * Strength used to pick the winner. Bust = -1, natural blackjack = 22
 * (beats any other 21), otherwise the hand total.
 */
export function handStrength(hand: Card[]): number {
  if (isBust(hand)) return -1;
  return isNatural(hand) ? 22 : handTotal(hand);
}

/**
 * Seats that take the pot. If every hand busts, every seat is returned
 * so the net pot is refunded evenly.
 */
export function winningSeats(hands: Card[][]): { seats: number[]; allBust: boolean } {
  const strengths = hands.map(handStrength);
  const best = Math.max(...strengths);
  if (best < 0) return { seats: hands.map((_, i) => i), allBust: true };
  return { seats: strengths.flatMap((v, i) => (v === best ? [i] : [])), allBust: false };
}
