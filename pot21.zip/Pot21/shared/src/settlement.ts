/**
 * Pot settlement math. The on-chain escrow program implements exactly the
 * same rules (programs/pot21_escrow/src/lib.rs `settle`), so keep them in sync.
 *
 *   total  = stake * seats
 *   fee    = floor(total * feeBps / 10_000)      -> house wallet
 *   net    = total - fee
 *   share  = floor(net / winners.length)         -> each winner
 *   the indivisible remainder goes to the first winner in the list
 */
export const HOUSE_FEE_BPS = 200; // 2%

export interface Settlement {
  total: bigint;
  fee: bigint;
  net: bigint;
  payouts: { seat: number; amount: bigint }[];
}

export function computeSettlement(stake: bigint, seats: number, winners: number[], feeBps = HOUSE_FEE_BPS): Settlement {
  if (stake <= 0n) throw new Error("stake must be positive");
  if (seats < 2) throw new Error("need at least 2 seats");
  if (winners.length === 0) throw new Error("need at least one winner");
  const uniq = new Set(winners);
  if (uniq.size !== winners.length) throw new Error("duplicate winner seat");
  for (const w of winners) if (w < 0 || w >= seats) throw new Error(`winner seat ${w} out of range`);

  const total = stake * BigInt(seats);
  const fee = (total * BigInt(feeBps)) / 10_000n;
  const net = total - fee;
  const n = BigInt(winners.length);
  const share = net / n;
  const remainder = net - share * n;
  const payouts = winners.map((seat, i) => ({ seat, amount: share + (i === 0 ? remainder : 0n) }));
  return { total, fee, net, payouts };
}

/** Fee and pot preview for a table before anyone stakes. */
export function potPreview(stake: bigint, seats: number, feeBps = HOUSE_FEE_BPS) {
  const total = stake * BigInt(seats);
  const fee = (total * BigInt(feeBps)) / 10_000n;
  return { total, fee, net: total - fee };
}

/** Fee on a deposit or withdrawal: the house keeps `fee`, the player moves `net`. */
export function transferFee(amount: bigint, feeBps: number) {
  if (amount <= 0n) throw new Error("amount must be positive");
  const fee = (amount * BigInt(feeBps)) / 10_000n;
  return { fee, net: amount - fee };
}

/** The message a wallet signs to log in. Signing costs nothing and moves no tokens. */
export function signInMessage(wallet: string, nonce: string, issuedAt: string) {
  return `Sign in to Pot 21\n\nThis only proves you own this wallet. It does not send a transaction or cost anything.\n\nWallet: ${wallet}\nNonce: ${nonce}\nIssued: ${issuedAt}`;
}
