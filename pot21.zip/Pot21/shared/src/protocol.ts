import type { Card } from "./cards.ts";

/** Amounts travel as decimal strings of token base units (bigint-safe). */
export type Units = string;

export type LedgerMode = "mock" | "solana";

export interface SessionInfo {
  userId: string;
  handle: string;
  wallet: string;
  mode: LedgerMode;
  token: { symbol: string; decimals: number; mint: string | null };
  /** How this account signed in. "privy" means the game wallet is Privy's embedded wallet. */
  login: "privy" | "phantom" | "dev";
  /** The Phantom wallet linked to this account. Deposits come from it and withdrawals go back to it. */
  linked: string | null;
  fees: { potBps: number; depositBps: number; withdrawBps: number };
  /** Present in solana mode so the client can build and sign deposit transactions. */
  chain?: { rpcUrl: string; programId: string; house: string };
}

export type RoundPhase = "funding" | "playing" | "settling" | "done" | "cancelled";
export type SeatStatus = "waiting" | "deposited" | "playing" | "stood" | "bust" | "blackjack" | "timedout";

export interface SeatView {
  seat: number;
  handle: string;
  wallet: string;
  isBot: boolean;
  connected: boolean;
  /** null = face-down card */
  cards: (Card | null)[];
  total: number | null;
  status: SeatStatus;
  payout: Units | null;
}

export interface RoundView {
  id: string;
  phase: RoundPhase;
  /** sha256(serverSeed), published before stakes */
  commit: string;
  /** Revealed only once the round is done or cancelled */
  serverSeed: string | null;
  clientSeeds: string[];
  escrow: string | null;
  fundingEndsAt: number | null;
  /** Seat order for this hand (deal and play), needed to re-check the shuffle. */
  order: number[];
  turnSeat: number | null;
  turnEndsAt: number | null;
  total: Units;
  fee: Units;
  net: Units;
  winners: number[] | null;
  allBust: boolean;
  settleSig: string | null;
  note: string;
}

export interface TableView {
  id: string;
  seats: number;
  stake: Units;
  seated: (SeatView | null)[];
  yourSeat: number | null;
  round: RoundView | null;
}

export interface TableSummary {
  id: string;
  seats: number;
  stake: Units;
  occupied: number;
  phase: RoundPhase | "open";
  /** Who is sitting there, in seat order. */
  players: { handle: string; isBot: boolean }[];
  /** When the table was opened (ms since epoch). */
  openedAt: number;
}

/**
 * Wire protocol over a plain WebSocket, JSON-encoded.
 *   client -> server  { id, type, payload }      (a request)
 *   server -> client  { id, ok, result | error } (its reply)
 *   server -> client  { event, data }            (a push)
 */
export interface Requests {
  /** Dev login by handle, or resume with a session token. Privy replaces the handle path later. */
  /** Step 1 of Phantom sign-in: get a one-time message to sign. */
  "auth:challenge": { req: { wallet: string }; res: { message: string } };
  /**
   * Step 2: send the signature (base58). Or dev login by handle, or resume a session.
   * `wallet` is the game wallet the browser holds (solana mode, until Privy).
   */
  auth: { req: { privyToken?: string; handle?: string; sessionToken?: string; wallet?: string; phantom?: { wallet: string; signature: string } }; res: { session: SessionInfo; sessionToken: string } };
  /** Sign out: the saved session stops working. */
  "auth:logout": { req: { sessionToken: string }; res: {} };
  "lobby:list": { req: {}; res: { tables: TableSummary[] } };
  "table:create": { req: { seats: number; stake: Units; bots?: number; clientSeed: string }; res: { tableId: string } };
  /** Seat me at a waiting table with this stake, or open one if there isn't one. */
  "table:quick": { req: { stake: Units; seats?: number; clientSeed: string }; res: { tableId: string; joined: boolean } };
  "table:join": { req: { tableId: string; clientSeed: string }; res: {} };
  "table:leave": { req: {}; res: {} };
  "round:deposit": { req: { roundId: string; signature?: string }; res: {} };
  "round:action": { req: { roundId: string; action: "hit" | "stand" }; res: {} };
  "wallet:faucet": { req: {}; res: {} };
  /** Link a Phantom wallet for deposits and withdrawals. Uses the same signed challenge as Phantom sign-in. */
  "wallet:link": { req: { wallet: string; signature: string }; res: { session: SessionInfo } };
  /** Mock: moves tokens. Solana: `signature` is the player's already-sent transfer; the server records it. */
  "wallet:deposit": { req: { amount: Units; signature?: string }; res: {} };
  "wallet:withdraw": { req: { amount: Units; signature?: string }; res: {} };
}
export type RequestType = keyof Requests;

export interface Events {
  "table:state": TableView | null;
  "lobby:update": TableSummary[];
  "wallet:balance": { balance: Units };
  "wallet:tx": LedgerTx;
  /** Balance of the linked Phantom wallet (demo mode only; in solana mode the browser reads it from chain). */
  "wallet:linked": { balance: Units };
}
export type EventType = keyof Events;

export type ClientMsg = { [K in RequestType]: { id: number; type: K; payload: Requests[K]["req"] } }[RequestType];
export type ServerMsg =
  | { id: number; ok: true; result: unknown }
  | { id: number; ok: false; error: string }
  | { [K in EventType]: { event: K; data: Events[K] } }[EventType];

export interface LedgerTx {
  kind: "in" | "out" | "fee";
  label: string;
  amount: Units;
  route: string;
  sig: string;
  at: number;
}

export const TURN_MS = 20_000;
export const FUNDING_MS = 60_000;
export const MIN_SEATS = 2;
export const MAX_SEATS = 6;
