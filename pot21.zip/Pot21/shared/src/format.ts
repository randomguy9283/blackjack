/** Format token base units for display, e.g. 1_250_000n @ 6 decimals -> "1.25" */
export function formatUnits(units: bigint | string, decimals: number, maxFrac = 2): string {
  const v = BigInt(units);
  const neg = v < 0n;
  const abs = neg ? -v : v;
  const base = 10n ** BigInt(decimals);
  const whole = abs / base;
  let frac = (abs % base).toString().padStart(decimals, "0").slice(0, maxFrac);
  frac = frac.padEnd(Math.min(2, maxFrac), "0");
  const w = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (neg ? "-" : "") + (frac ? `${w}.${frac}` : w);
}

/** Parse a human amount like "25" or "0.5" into base units. */
export function parseUnits(amount: string, decimals: number): bigint {
  const m = /^(\d+)(?:\.(\d+))?$/.exec(amount.trim());
  if (!m) throw new Error(`invalid amount "${amount}"`);
  const frac = (m[2] ?? "").padEnd(decimals, "0");
  if (frac.length > decimals) throw new Error(`too many decimals in "${amount}"`);
  return BigInt(m[1]) * 10n ** BigInt(decimals) + BigInt(frac || "0");
}
