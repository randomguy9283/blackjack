/**
 * Provably fair shuffle (commit-reveal).
 *
 * 1. When a round opens the server picks a random 32-byte serverSeed and
 *    publishes commit = sha256(serverSeed) before anyone stakes.
 * 2. Every player sends their own clientSeed when they sit down.
 * 3. The deck is a Fisher-Yates shuffle of orderedDeck() driven by
 *    HMAC-SHA256(key = serverSeed, msg = `${roundId}:${clientSeeds.join(":")}:${counter}`).
 * 4. After settlement the server reveals serverSeed. Anyone can check
 *    sha256(serverSeed) === commit and re-run shuffleDeck to get the same deck.
 *
 * The server can't steer the deck after committing, and no single player's
 * seed decides it either.
 */
import { sha256, hmacSha256, toHex as bytesToHex, fromHex as hexToBytes, utf8 as utf8ToBytes } from "./sha256.ts";
import { orderedDeck, type Card } from "./cards.ts";

export function commitFor(serverSeedHex: string): string {
  return bytesToHex(sha256(hexToBytes(serverSeedHex)));
}

export function verifyCommit(serverSeedHex: string, commitHex: string): boolean {
  return commitFor(serverSeedHex) === commitHex.toLowerCase();
}

/** Deterministic stream of uniform 32-bit integers. */
function* uint32Stream(serverSeedHex: string, roundId: string, clientSeeds: string[]) {
  const key = hexToBytes(serverSeedHex);
  for (let counter = 0; ; counter++) {
    const block = hmacSha256(key, utf8ToBytes(`${roundId}:${clientSeeds.join(":")}:${counter}`));
    const view = new DataView(block.buffer, block.byteOffset, block.byteLength);
    for (let i = 0; i < 32; i += 4) yield view.getUint32(i, false);
  }
}

/** Unbiased integer in [0, n) via rejection sampling. */
function uniform(stream: Generator<number>, n: number): number {
  const limit = Math.floor(0x1_0000_0000 / n) * n;
  for (;;) {
    const v = stream.next().value as number;
    if (v < limit) return v % n;
  }
}

export function shuffleDeck(serverSeedHex: string, roundId: string, clientSeeds: string[]): Card[] {
  const deck = orderedDeck();
  const stream = uint32Stream(serverSeedHex, roundId, clientSeeds);
  for (let i = deck.length - 1; i > 0; i--) {
    const j = uniform(stream, i + 1);
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

/**
 * Re-deal a finished round from its revealed seed and check it matches the
 * cards that were shown. `hands[seat]` are the cards each seat ended with.
 * Deal order: two passes round `order`, then each seat's hits in `order`.
 */
export function verifyRound(args: {
  serverSeed: string; commit: string; roundId: string; clientSeeds: string[]; order: number[]; hands: Card[][];
}): { ok: true } | { ok: false; reason: string } {
  if (!verifyCommit(args.serverSeed, args.commit)) return { ok: false, reason: "Revealed seed doesn't match the commitment published before the hand." };
  const deck = shuffleDeck(args.serverSeed, args.roundId, args.clientSeeds);
  let next = 0;
  const same = (a: Card, b: Card) => a.r === b.r && a.s === b.s;
  for (let pass = 0; pass < 2; pass++) for (const seat of args.order) {
    if (!same(args.hands[seat][pass], deck[next++])) return { ok: false, reason: `Seat ${seat + 1}'s card ${pass + 1} doesn't match the shuffle.` };
  }
  for (const seat of args.order) for (let i = 2; i < args.hands[seat].length; i++) {
    if (!same(args.hands[seat][i], deck[next++])) return { ok: false, reason: `Seat ${seat + 1}'s card ${i + 1} doesn't match the shuffle.` };
  }
  return { ok: true };
}
