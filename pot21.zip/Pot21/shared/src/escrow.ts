/**
 * Instruction builders for the pot21_escrow Anchor program, used by the
 * server (open/settle/cancel) and the browser (join).
 *
 * Hand-encoded so neither side needs Anchor's TS client. If you change the
 * program's accounts or arguments, update the matching builder here.
 * Requires @solana/web3.js (install it to use solana mode).
 */
import { Buffer } from "buffer"; // web3.js dependency; browsers have no global Buffer
import { PublicKey, SystemProgram, TransactionInstruction, type AccountMeta } from "@solana/web3.js";
import { sha256, utf8 } from "./sha256.ts";

export const TOKEN_PROGRAM_ID = new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
export const MAX_SEATS = 6;

const disc = (name: string) => sha256(utf8(`global:${name}`)).slice(0, 8);
const u8 = (n: number) => Uint8Array.of(n);
function u64(n: bigint) { const b = new Uint8Array(8); new DataView(b.buffer).setBigUint64(0, n, true); return b; }
function cat(...parts: Uint8Array[]) {
  const out = new Uint8Array(parts.reduce((a, p) => a + p.length, 0));
  let o = 0; for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}
const w = (pubkey: PublicKey, isSigner = false): AccountMeta => ({ pubkey, isSigner, isWritable: true });
const r = (pubkey: PublicKey, isSigner = false): AccountMeta => ({ pubkey, isSigner, isWritable: false });

export function pdas(programId: PublicKey, roundId: bigint) {
  const [config] = PublicKey.findProgramAddressSync([utf8("config")], programId);
  const [round] = PublicKey.findProgramAddressSync([utf8("round"), u64(roundId)], programId);
  const [vault] = PublicKey.findProgramAddressSync([utf8("vault"), round.toBytes()], programId);
  return { config, round, vault };
}

/** One-time program setup: fee (200 = 2%), the server's authority key and the house token account. */
export function ixInitialize(a: { programId: PublicKey; admin: PublicKey; mint: PublicKey; houseToken: PublicKey; authority: PublicKey; feeBps: number }) {
  const { config } = pdas(a.programId, 0n);
  const fee = new Uint8Array(2); new DataView(fee.buffer).setUint16(0, a.feeBps, true);
  return new TransactionInstruction({
    programId: a.programId,
    keys: [w(a.admin, true), w(config), r(a.mint), r(a.houseToken), r(SystemProgram.programId)],
    data: Buffer.from(cat(disc("initialize"), fee, a.authority.toBytes())),
  });
}

interface Base { programId: PublicKey; mint: PublicKey; roundId: bigint; tokenProgram?: PublicKey }

export function ixOpenRound(a: Base & { authority: PublicKey; seats: number; stake: bigint }) {
  const p = pdas(a.programId, a.roundId);
  return new TransactionInstruction({
    programId: a.programId,
    keys: [w(a.authority, true), r(p.config), w(p.round), w(p.vault), r(a.mint), r(a.tokenProgram ?? TOKEN_PROGRAM_ID), r(SystemProgram.programId)],
    data: Buffer.from(cat(disc("open_round"), u64(a.roundId), u8(a.seats), u64(a.stake))),
  });
}

export function ixJoin(a: Base & { player: PublicKey; playerToken: PublicKey; seat: number }) {
  const p = pdas(a.programId, a.roundId);
  return new TransactionInstruction({
    programId: a.programId,
    keys: [r(a.player, true), r(p.config), w(p.round), w(p.vault), r(a.mint), w(a.playerToken), r(a.tokenProgram ?? TOKEN_PROGRAM_ID)],
    data: Buffer.from(cat(disc("join"), u8(a.seat))),
  });
}

/** winnerTokens must be in the same order as winners. */
export function ixSettle(a: Base & { authority: PublicKey; houseToken: PublicKey; winners: number[]; winnerTokens: PublicKey[] }) {
  const p = pdas(a.programId, a.roundId);
  const vec = cat(new Uint8Array(new Uint32Array([a.winners.length]).buffer), Uint8Array.from(a.winners));
  return new TransactionInstruction({
    programId: a.programId,
    keys: [w(a.authority, true), r(p.config), w(p.round), w(p.vault), r(a.mint), w(a.houseToken), r(a.tokenProgram ?? TOKEN_PROGRAM_ID), ...a.winnerTokens.map(t => w(t))],
    data: Buffer.from(cat(disc("settle"), vec)),
  });
}

/** refundTokens: one per deposited seat, in seat order. */
export function ixCancel(a: Base & { caller: PublicKey; rentReceiver: PublicKey; refundTokens: PublicKey[] }) {
  const p = pdas(a.programId, a.roundId);
  return new TransactionInstruction({
    programId: a.programId,
    keys: [r(a.caller, true), r(p.config), w(a.rentReceiver), w(p.round), w(p.vault), r(a.mint), r(a.tokenProgram ?? TOKEN_PROGRAM_ID), ...a.refundTokens.map(t => w(t))],
    data: Buffer.from(cat(disc("cancel"))),
  });
}

export interface RoundAccount {
  roundId: bigint; seats: number; stake: bigint; feeBps: number;
  players: PublicKey[]; deposited: number; status: "open" | "locked"; openedAt: bigint;
}

export function decodeRound(data: Uint8Array): RoundAccount {
  // Anchor account discriminator = sha256("account:Round")[..8]
  const acctDisc = sha256(utf8("account:Round")).slice(0, 8);
  for (let i = 0; i < 8; i++) if (data[i] !== acctDisc[i]) throw new Error("not a Round account");
  const dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let o = 8;
  const roundId = dv.getBigUint64(o, true); o += 8;
  const seats = dv.getUint8(o); o += 1;
  const stake = dv.getBigUint64(o, true); o += 8;
  const feeBps = dv.getUint16(o, true); o += 2;
  const players: PublicKey[] = [];
  for (let i = 0; i < MAX_SEATS; i++) { players.push(new PublicKey(data.slice(o, o + 32))); o += 32; }
  const deposited = dv.getUint8(o); o += 1;
  const status = dv.getUint8(o) === 0 ? "open" : "locked"; o += 1;
  const openedAt = dv.getBigInt64(o, true);
  return { roundId, seats, stake, feeBps, players, deposited, status, openedAt };
}
