import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash, createHmac } from "node:crypto";
import { sha256, hmacSha256, toHex, utf8 } from "../src/sha256.ts";
const expect = (a: unknown) => ({
  toBe: (b: unknown) => assert.equal(a, b),
  toEqual: (b: unknown) => assert.deepEqual(a, b),
  toBeGreaterThan: (b: number) => assert.ok((a as number) > b),
  toThrow: () => assert.throws(a as () => void),
  not: { toEqual: (b: unknown) => assert.notDeepEqual(a, b) },
});
import {
  handTotal, handStrength, winningSeats, computeSettlement, shuffleDeck, commitFor, verifyCommit,
  formatUnits, parseUnits, type Card,
} from "../src/index.ts";

const h = (...rs: string[]): Card[] => rs.map(r => ({ r: r as Card["r"], s: "S" }));

describe("hands", () => {
  it("counts soft aces", () => {
    expect(handTotal(h("A", "K"))).toBe(21);
    expect(handTotal(h("A", "A", "9"))).toBe(21);
    expect(handTotal(h("A", "9", "5"))).toBe(15);
    expect(handTotal(h("K", "Q", "5"))).toBe(25);
  });
  it("natural beats a drawn 21", () => {
    expect(handStrength(h("A", "K"))).toBeGreaterThan(handStrength(h("7", "7", "7")));
  });
  it("picks winners, ties and all-bust", () => {
    expect(winningSeats([h("10", "9"), h("10", "8")])).toEqual({ seats: [0], allBust: false });
    expect(winningSeats([h("10", "9"), h("9", "10"), h("2", "3")])).toEqual({ seats: [0, 1], allBust: false });
    expect(winningSeats([h("K", "Q", "5"), h("K", "9", "8")])).toEqual({ seats: [0, 1], allBust: true });
  });
});

describe("settlement", () => {
  it("takes exactly 2% of the pot", () => {
    const s = computeSettlement(25_000_000n, 4, [2]);
    expect(s.total).toBe(100_000_000n);
    expect(s.fee).toBe(2_000_000n);
    expect(s.payouts).toEqual([{ seat: 2, amount: 98_000_000n }]);
  });
  it("splits and never loses a unit", () => {
    const s = computeSettlement(10n, 3, [0, 1, 2]); // total 30, fee 0, net 30
    const s2 = computeSettlement(333n, 3, [1, 2]); // total 999, fee 19, net 980
    expect(s.payouts.reduce((a, p) => a + p.amount, 0n) + s.fee).toBe(s.total);
    expect(s2.fee).toBe(19n);
    expect(s2.payouts).toEqual([{ seat: 1, amount: 490n }, { seat: 2, amount: 490n }]);
    const s3 = computeSettlement(1_000_001n, 3, [0, 2]);
    expect(s3.payouts.reduce((a, p) => a + p.amount, 0n) + s3.fee).toBe(s3.total);
  });
  it("rejects bad winners", () => {
    expect(() => computeSettlement(10n, 2, [])).toThrow();
    expect(() => computeSettlement(10n, 2, [2])).toThrow();
    expect(() => computeSettlement(10n, 2, [0, 0])).toThrow();
  });
});

describe("fairness", () => {
  const seed = "aa".repeat(32);
  it("is deterministic and a real permutation", () => {
    const a = shuffleDeck(seed, "r1", ["x", "y"]);
    const b = shuffleDeck(seed, "r1", ["x", "y"]);
    expect(a).toEqual(b);
    expect(new Set(a.map(c => c.r + c.s)).size).toBe(52);
  });
  it("changes with any client seed", () => {
    expect(shuffleDeck(seed, "r1", ["x", "y"])).not.toEqual(shuffleDeck(seed, "r1", ["x", "z"]));
  });
  it("verifies commits", () => {
    expect(verifyCommit(seed, commitFor(seed))).toBe(true);
    expect(verifyCommit("bb".repeat(32), commitFor(seed))).toBe(false);
  });
});

describe("format", () => {
  it("round-trips", () => {
    expect(parseUnits("25", 6)).toBe(25_000_000n);
    expect(parseUnits("0.5", 6)).toBe(500_000n);
    expect(formatUnits(1_234_567_890n, 6)).toBe("1,234.56");
    expect(formatUnits(500_000n, 6)).toBe("0.50");
  });
});

describe("sha256", () => {
  it("matches node:crypto", () => {
    for (const len of [0, 1, 55, 56, 63, 64, 65, 200]) {
      const m = new Uint8Array(len).map((_, i) => (i * 7) & 255);
      assert.equal(toHex(sha256(m)), createHash("sha256").update(m).digest("hex"));
      const k = new Uint8Array(len + 3).map((_, i) => i & 255);
      assert.equal(toHex(hmacSha256(k, m)), createHmac("sha256", k).update(m).digest("hex"));
    }
    assert.equal(toHex(sha256(utf8("abc"))), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
});
