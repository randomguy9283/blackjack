//! Pot 21 escrow.
//!
//! Holds every player's stake for one round, then either
//!   * `settle`: pays the house fee (fee_bps of the pot, 200 = 2%) to the
//!     house token account and splits the rest between the winning seats, or
//!   * `cancel`: refunds every stake in full.
//!
//! Safety properties:
//!   * Tokens can only ever leave the vault to a seated player's own token
//!     account or to the configured house account. The game server
//!     (`authority`) picks the winners but cannot redirect funds.
//!   * If the server disappears, anyone can call `cancel` once
//!     REFUND_AFTER_SECS have passed since the round opened, and every
//!     player gets their stake back.
//!
//! The settlement maths matches shared/src/settlement.ts exactly.

use anchor_lang::prelude::*;
use anchor_spl::token_interface::{self, CloseAccount, Mint, TokenAccount, TokenInterface, TransferChecked};

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

pub const MAX_SEATS: usize = 6;
pub const MIN_SEATS: u8 = 2;
pub const MAX_FEE_BPS: u16 = 1_000; // hard cap 10%
pub const REFUND_AFTER_SECS: i64 = 60 * 60;

#[program]
pub mod pot21_escrow {
    use super::*;

    /// One-time setup by the admin.
    pub fn initialize(ctx: Context<Initialize>, fee_bps: u16, authority: Pubkey) -> Result<()> {
        require!(fee_bps <= MAX_FEE_BPS, EscrowError::FeeTooHigh);
        let c = &mut ctx.accounts.config;
        c.admin = ctx.accounts.admin.key();
        c.authority = authority;
        c.mint = ctx.accounts.mint.key();
        c.house_token = ctx.accounts.house_token.key();
        c.fee_bps = fee_bps;
        c.bump = ctx.bumps.config;
        Ok(())
    }

    /// Admin can rotate the server key, change the fee (within the cap) or move the house account.
    pub fn update_config(ctx: Context<UpdateConfig>, fee_bps: Option<u16>, authority: Option<Pubkey>) -> Result<()> {
        let c = &mut ctx.accounts.config;
        if let Some(f) = fee_bps {
            require!(f <= MAX_FEE_BPS, EscrowError::FeeTooHigh);
            c.fee_bps = f;
        }
        if let Some(a) = authority {
            c.authority = a;
        }
        if let Some(h) = &ctx.accounts.new_house_token {
            c.house_token = h.key();
        }
        Ok(())
    }

    /// Game server opens a round for a full table.
    pub fn open_round(ctx: Context<OpenRound>, round_id: u64, seats: u8, stake: u64) -> Result<()> {
        require!(seats >= MIN_SEATS && seats as usize <= MAX_SEATS, EscrowError::BadSeatCount);
        require!(stake > 0, EscrowError::ZeroStake);
        stake.checked_mul(seats as u64).ok_or(EscrowError::Overflow)?;
        let r = &mut ctx.accounts.round;
        r.round_id = round_id;
        r.seats = seats;
        r.stake = stake;
        r.fee_bps = ctx.accounts.config.fee_bps;
        r.players = [Pubkey::default(); MAX_SEATS];
        r.deposited = 0;
        r.status = RoundStatus::Open;
        r.opened_at = Clock::get()?.unix_timestamp;
        r.bump = ctx.bumps.round;
        emit!(RoundOpened { round_id, seats, stake });
        Ok(())
    }

    /// A player stakes into their seat. Signed by the player's own wallet.
    pub fn join(ctx: Context<Join>, seat: u8) -> Result<()> {
        let player = ctx.accounts.player.key();
        let r = &mut ctx.accounts.round;
        require!(r.status == RoundStatus::Open, EscrowError::NotOpen);
        require!(seat < r.seats, EscrowError::BadSeat);
        require!(r.deposited & (1 << seat) == 0, EscrowError::SeatTaken);
        for i in 0..r.seats as usize {
            if r.deposited & (1 << i) != 0 {
                require!(r.players[i] != player, EscrowError::AlreadySeated);
            }
        }

        token_interface::transfer_checked(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.player_token.to_account_info(),
                    mint: ctx.accounts.mint.to_account_info(),
                    to: ctx.accounts.vault.to_account_info(),
                    authority: ctx.accounts.player.to_account_info(),
                },
            ),
            r.stake,
            ctx.accounts.mint.decimals,
        )?;

        r.players[seat as usize] = player;
        r.deposited |= 1 << seat;
        if r.deposited.count_ones() == r.seats as u32 {
            r.status = RoundStatus::Locked;
        }
        emit!(PlayerJoined { round_id: r.round_id, seat, player });
        Ok(())
    }

    /// Game server reports the winners. `remaining_accounts` must be the
    /// winners' token accounts, in the same order as `winners`.
    pub fn settle<'info>(ctx: Context<'_, '_, 'info, 'info, Settle<'info>>, winners: Vec<u8>) -> Result<()> {
        let r = &ctx.accounts.round;
        require!(r.status == RoundStatus::Locked, EscrowError::NotLocked);
        require!(!winners.is_empty(), EscrowError::NoWinners);
        require!(winners.len() == ctx.remaining_accounts.len(), EscrowError::AccountMismatch);
        let mut seen: u8 = 0;
        for &w in &winners {
            require!(w < r.seats, EscrowError::BadSeat);
            require!(seen & (1 << w) == 0, EscrowError::DuplicateWinner);
            seen |= 1 << w;
        }

        let s = compute_settlement(r.stake, r.seats, winners.len() as u64, r.fee_bps)?;
        require!(ctx.accounts.vault.amount >= s.total, EscrowError::VaultShort);

        let round_id = r.round_id.to_le_bytes();
        let bump = [r.bump];
        let seeds: &[&[u8]] = &[b"round", &round_id, &bump];
        let signer = &[seeds];

        // House fee.
        pay(&ctx.accounts.token_program, &ctx.accounts.vault, ctx.accounts.house_token.to_account_info(), &ctx.accounts.mint, ctx.accounts.round.to_account_info(), signer, s.fee)?;

        // Winners. First winner also gets the indivisible remainder.
        for (i, (&w, acc)) in winners.iter().zip(ctx.remaining_accounts.iter()).enumerate() {
            check_player_account(acc, &ctx.accounts.round.players[w as usize], &ctx.accounts.mint.key())?;
            let amount = s.share + if i == 0 { s.remainder } else { 0 };
            pay(&ctx.accounts.token_program, &ctx.accounts.vault, acc.clone(), &ctx.accounts.mint, ctx.accounts.round.to_account_info(), signer, amount)?;
        }

        close_vault(&ctx.accounts.token_program, &ctx.accounts.vault, ctx.accounts.authority.to_account_info(), ctx.accounts.round.to_account_info(), signer)?;
        emit!(RoundSettled { round_id: r.round_id, winners, fee: s.fee, share: s.share, remainder: s.remainder });
        Ok(())
    }

    /// Refund every stake in full. The server can cancel any unsettled
    /// round; anyone can cancel once REFUND_AFTER_SECS have passed.
    /// `remaining_accounts`: one token account per deposited seat, in seat order.
    pub fn cancel<'info>(ctx: Context<'_, '_, 'info, 'info, Cancel<'info>>) -> Result<()> {
        let r = &ctx.accounts.round;
        let now = Clock::get()?.unix_timestamp;
        let is_server = ctx.accounts.caller.key() == ctx.accounts.config.authority;
        require!(is_server || now >= r.opened_at + REFUND_AFTER_SECS, EscrowError::TooEarlyToRefund);

        let deposited: Vec<usize> = (0..r.seats as usize).filter(|&i| r.deposited & (1 << i) != 0).collect();
        require!(deposited.len() == ctx.remaining_accounts.len(), EscrowError::AccountMismatch);

        let round_id = r.round_id.to_le_bytes();
        let bump = [r.bump];
        let seeds: &[&[u8]] = &[b"round", &round_id, &bump];
        let signer = &[seeds];

        for (&seat, acc) in deposited.iter().zip(ctx.remaining_accounts.iter()) {
            check_player_account(acc, &ctx.accounts.round.players[seat], &ctx.accounts.mint.key())?;
            pay(&ctx.accounts.token_program, &ctx.accounts.vault, acc.clone(), &ctx.accounts.mint, ctx.accounts.round.to_account_info(), signer, ctx.accounts.round.stake)?;
        }
        close_vault(&ctx.accounts.token_program, &ctx.accounts.vault, ctx.accounts.rent_receiver.to_account_info(), ctx.accounts.round.to_account_info(), signer)?;
        emit!(RoundCancelled { round_id: r.round_id, refunded: deposited.len() as u8 });
        Ok(())
    }
}

/* ------------------------------------------------------------------ */

pub struct SettlementAmounts {
    pub total: u64,
    pub fee: u64,
    pub share: u64,
    pub remainder: u64,
}

/// total = stake*seats; fee = floor(total*fee_bps/10000); net split evenly, remainder to first winner.
pub fn compute_settlement(stake: u64, seats: u8, winners: u64, fee_bps: u16) -> Result<SettlementAmounts> {
    let total = stake.checked_mul(seats as u64).ok_or(EscrowError::Overflow)?;
    let fee = ((total as u128) * (fee_bps as u128) / 10_000u128) as u64;
    let net = total - fee;
    let share = net / winners;
    let remainder = net - share * winners;
    Ok(SettlementAmounts { total, fee, share, remainder })
}

fn check_player_account<'info>(acc: &'info AccountInfo<'info>, expected_owner: &Pubkey, mint: &Pubkey) -> Result<()> {
    let ta = InterfaceAccount::<TokenAccount>::try_from(acc)?;
    require_keys_eq!(ta.owner, *expected_owner, EscrowError::WrongRecipient);
    require_keys_eq!(ta.mint, *mint, EscrowError::WrongMint);
    Ok(())
}

fn pay<'info>(
    token_program: &Interface<'info, TokenInterface>,
    vault: &InterfaceAccount<'info, TokenAccount>,
    to: AccountInfo<'info>,
    mint: &InterfaceAccount<'info, Mint>,
    round: AccountInfo<'info>,
    signer: &[&[&[u8]]],
    amount: u64,
) -> Result<()> {
    if amount == 0 {
        return Ok(());
    }
    token_interface::transfer_checked(
        CpiContext::new_with_signer(
            token_program.to_account_info(),
            TransferChecked { from: vault.to_account_info(), mint: mint.to_account_info(), to, authority: round },
            signer,
        ),
        amount,
        mint.decimals,
    )
}

fn close_vault<'info>(
    token_program: &Interface<'info, TokenInterface>,
    vault: &InterfaceAccount<'info, TokenAccount>,
    destination: AccountInfo<'info>,
    round: AccountInfo<'info>,
    signer: &[&[&[u8]]],
) -> Result<()> {
    token_interface::close_account(CpiContext::new_with_signer(
        token_program.to_account_info(),
        CloseAccount { account: vault.to_account_info(), destination, authority: round },
        signer,
    ))
}

/* ------------------------------------------------------------------ */

#[account]
#[derive(InitSpace)]
pub struct Config {
    pub admin: Pubkey,
    /// Game server key that opens and settles rounds.
    pub authority: Pubkey,
    pub mint: Pubkey,
    pub house_token: Pubkey,
    pub fee_bps: u16,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct Round {
    pub round_id: u64,
    pub seats: u8,
    pub stake: u64,
    /// Fee locked in when the round opened, so a config change can't affect a live round.
    pub fee_bps: u16,
    pub players: [Pubkey; MAX_SEATS],
    /// Bitmask of seats that have staked.
    pub deposited: u8,
    pub status: RoundStatus,
    pub opened_at: i64,
    pub bump: u8,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq, InitSpace)]
pub enum RoundStatus {
    Open,
    Locked,
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(init, payer = admin, space = 8 + Config::INIT_SPACE, seeds = [b"config"], bump)]
    pub config: Account<'info, Config>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(token::mint = mint)]
    pub house_token: InterfaceAccount<'info, TokenAccount>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateConfig<'info> {
    pub admin: Signer<'info>,
    #[account(mut, seeds = [b"config"], bump = config.bump, has_one = admin, has_one = mint)]
    pub config: Account<'info, Config>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(token::mint = mint)]
    pub new_house_token: Option<InterfaceAccount<'info, TokenAccount>>,
}

#[derive(Accounts)]
#[instruction(round_id: u64)]
pub struct OpenRound<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(seeds = [b"config"], bump = config.bump, has_one = authority, has_one = mint)]
    pub config: Account<'info, Config>,
    #[account(init, payer = authority, space = 8 + Round::INIT_SPACE, seeds = [b"round", round_id.to_le_bytes().as_ref()], bump)]
    pub round: Account<'info, Round>,
    #[account(
        init, payer = authority, seeds = [b"vault", round.key().as_ref()], bump,
        token::mint = mint, token::authority = round, token::token_program = token_program,
    )]
    pub vault: InterfaceAccount<'info, TokenAccount>,
    pub mint: InterfaceAccount<'info, Mint>,
    pub token_program: Interface<'info, TokenInterface>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Join<'info> {
    pub player: Signer<'info>,
    #[account(seeds = [b"config"], bump = config.bump, has_one = mint)]
    pub config: Account<'info, Config>,
    #[account(mut, seeds = [b"round", round.round_id.to_le_bytes().as_ref()], bump = round.bump)]
    pub round: Account<'info, Round>,
    #[account(mut, seeds = [b"vault", round.key().as_ref()], bump)]
    pub vault: InterfaceAccount<'info, TokenAccount>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(mut, token::mint = mint, token::authority = player)]
    pub player_token: InterfaceAccount<'info, TokenAccount>,
    pub token_program: Interface<'info, TokenInterface>,
}

#[derive(Accounts)]
pub struct Settle<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(seeds = [b"config"], bump = config.bump, has_one = authority, has_one = mint, has_one = house_token)]
    pub config: Account<'info, Config>,
    #[account(mut, close = authority, seeds = [b"round", round.round_id.to_le_bytes().as_ref()], bump = round.bump)]
    pub round: Account<'info, Round>,
    #[account(mut, seeds = [b"vault", round.key().as_ref()], bump)]
    pub vault: InterfaceAccount<'info, TokenAccount>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(mut)]
    pub house_token: InterfaceAccount<'info, TokenAccount>,
    pub token_program: Interface<'info, TokenInterface>,
}

#[derive(Accounts)]
pub struct Cancel<'info> {
    pub caller: Signer<'info>,
    #[account(seeds = [b"config"], bump = config.bump, has_one = mint)]
    pub config: Account<'info, Config>,
    /// CHECK: rent from the closed accounts goes back to the server that paid it.
    #[account(mut, address = config.authority)]
    pub rent_receiver: UncheckedAccount<'info>,
    #[account(mut, close = rent_receiver, seeds = [b"round", round.round_id.to_le_bytes().as_ref()], bump = round.bump)]
    pub round: Account<'info, Round>,
    #[account(mut, seeds = [b"vault", round.key().as_ref()], bump)]
    pub vault: InterfaceAccount<'info, TokenAccount>,
    pub mint: InterfaceAccount<'info, Mint>,
    pub token_program: Interface<'info, TokenInterface>,
}

#[event]
pub struct RoundOpened { pub round_id: u64, pub seats: u8, pub stake: u64 }
#[event]
pub struct PlayerJoined { pub round_id: u64, pub seat: u8, pub player: Pubkey }
#[event]
pub struct RoundSettled { pub round_id: u64, pub winners: Vec<u8>, pub fee: u64, pub share: u64, pub remainder: u64 }
#[event]
pub struct RoundCancelled { pub round_id: u64, pub refunded: u8 }

#[error_code]
pub enum EscrowError {
    #[msg("Fee is above the 10% cap")]
    FeeTooHigh,
    #[msg("Tables have 2 to 6 seats")]
    BadSeatCount,
    #[msg("Stake must be more than zero")]
    ZeroStake,
    #[msg("Amount overflow")]
    Overflow,
    #[msg("This round is not taking stakes")]
    NotOpen,
    #[msg("Seat number is out of range")]
    BadSeat,
    #[msg("Seat already staked")]
    SeatTaken,
    #[msg("Wallet already holds a seat in this round")]
    AlreadySeated,
    #[msg("Round is not fully staked")]
    NotLocked,
    #[msg("At least one winner is required")]
    NoWinners,
    #[msg("Winner listed twice")]
    DuplicateWinner,
    #[msg("Token accounts don't match the seats")]
    AccountMismatch,
    #[msg("Payout account isn't owned by that seat's player")]
    WrongRecipient,
    #[msg("Payout account is for a different token")]
    WrongMint,
    #[msg("Vault holds less than the pot")]
    VaultShort,
    #[msg("Only the game server can cancel before the refund deadline")]
    TooEarlyToRefund,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn two_percent_of_the_pot() {
        let s = compute_settlement(25_000_000, 4, 1, 200).unwrap();
        assert_eq!(s.total, 100_000_000);
        assert_eq!(s.fee, 2_000_000);
        assert_eq!(s.share, 98_000_000);
        assert_eq!(s.remainder, 0);
    }

    #[test]
    fn matches_typescript_split() {
        // Same case as shared/test/shared.test.ts: 333 x 3 seats, 2 winners.
        let s = compute_settlement(333, 3, 2, 200).unwrap();
        assert_eq!((s.fee, s.share, s.remainder), (19, 490, 0));
        let s = compute_settlement(1_000_001, 3, 2, 200).unwrap();
        assert_eq!(s.fee + s.share * 2 + s.remainder, s.total);
    }
}
